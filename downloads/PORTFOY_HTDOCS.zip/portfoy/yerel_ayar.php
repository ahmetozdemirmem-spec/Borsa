<?php
declare(strict_types=1);
// Varsayilan: Windows'ta TEMP, Linux/macOS'ta gecici dizin altinda
// bu klasore ozel kayit alani. Kayitlar HTTP ile sunulmaz.
// Kalici ozel bir konum isterseniz, htdocs DISINDA yazilabilir tam yol girin:
// return ['kayit_dizini' => 'C:/portfoy_kayitlari'];
return ['kayit_dizini' => sys_get_temp_dir().DIRECTORY_SEPARATOR.'portfoy-'.substr(hash('sha256',__DIR__),0,16)];
