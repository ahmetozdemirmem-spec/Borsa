(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Portfoy = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const DEFAULTS = Object.freeze({rsiPeriod: 14, rsiRecovery: 30, trendPeriod: 50,
    atrPeriod: 14, minAtrPct: 0.002, maxAtrPct: 0.03, volumeRatio: 0.7,
    intervalMs: 900000, warmupBars: 60});
  const finite = v => typeof v === 'number' && Number.isFinite(v);

  function validateBars(bars) {
    if (!Array.isArray(bars)) throw new Error('Mum dizisi gerekli.');
    let prev = -Infinity;
    for (const b of bars) {
      if (!b || !['t','o','h','l','c'].every(k => finite(b[k])) || b.t <= prev ||
          !Number.isSafeInteger(b.t) || b.t < 0 || b.l <= 0 || b.h < Math.max(b.o,b.c) ||
          b.l > Math.min(b.o,b.c) || b.h < b.l ||
          (b.v !== undefined && (!finite(b.v) || b.v < 0))) throw new Error('OHLC/tarih sırası geçersiz.');
      prev = b.t;
    }
    return bars;
  }
  function ema(values, period) {
    if (values.length < period) return NaN;
    let v = values.slice(0,period).reduce((a,b)=>a+b,0)/period;
    const alpha=2/(period+1);
    for (let i=period;i<values.length;i++) v=values[i]*alpha+v*(1-alpha);
    return v;
  }
  function rsi(values, period=14) {
    if (values.length <= period) return NaN;
    let gain=0,loss=0;
    for(let i=1;i<=period;i++){ const d=values[i]-values[i-1];gain+=Math.max(d,0);loss+=Math.max(-d,0); }
    gain/=period;loss/=period;
    for(let i=period+1;i<values.length;i++){const d=values[i]-values[i-1];gain=(gain*(period-1)+Math.max(d,0))/period;loss=(loss*(period-1)+Math.max(-d,0))/period;}
    return loss===0?(gain===0?50:100):100-100/(1+gain/loss);
  }
  function atr(bars, period=14) {
    if(bars.length<=period)return NaN;
    const tr=bars.slice(1).map((b,i)=>Math.max(b.h-b.l,Math.abs(b.h-bars[i].c),Math.abs(b.l-bars[i].c)));
    let a=tr.slice(0,period).reduce((s,x)=>s+x,0)/period;
    for(let i=period;i<tr.length;i++) a=(a*(period-1)+tr[i])/period;
    return a;
  }
  function settings(config={}) {
    const c={...DEFAULTS,...config};
    for(const k of ['rsiPeriod','trendPeriod','atrPeriod','warmupBars'])
      if(!Number.isInteger(c[k])||c[k]<2||c[k]>1000)throw new Error('Geçersiz gösterge periyodu: '+k);
    if(!finite(c.rsiRecovery)||c.rsiRecovery<=0||c.rsiRecovery>=100||!finite(c.minAtrPct)||!finite(c.maxAtrPct)||c.minAtrPct<0||c.maxAtrPct<=c.minAtrPct||!Number.isInteger(c.intervalMs)||c.intervalMs<1000)throw new Error('Geçersiz strateji ayarı.');
    return c;
  }
  /** Receives ONLY closed bars. No access to a future candle or its high/low. */
  function signal(closedBars, config={}) {
    const cfg=settings(config);validateBars(closedBars);
    const required=Math.max(cfg.warmupBars,cfg.trendPeriod+1,cfg.rsiPeriod+2,cfg.atrPeriod+1);
    if(closedBars.length<required)return {buy:false,reason:'ISINMA',rsi:NaN,atr:NaN,required};
    let bars=closedBars.slice(-Math.max(required,260));
    const lastIncomplete=bars.findLastIndex(b=>b.complete===false);
    if(lastIncomplete>=0)bars=bars.slice(lastIncomplete+1);
    if(bars.length<required)return {buy:false,reason:'EKSIK_MUM',rsi:NaN,atr:NaN};
    let lastGap=0;
    for(let i=1;i<bars.length;i++) {
      // Overnight/weekend session breaks are allowed; intraday missing candles are not.
      const a=new Date(bars[i-1].t+3*3600000).toISOString().slice(0,10);
      const b=new Date(bars[i].t+3*3600000).toISOString().slice(0,10);
      if(a===b && bars[i].t-bars[i-1].t!==cfg.intervalMs)lastGap=i;
    }
    bars=bars.slice(lastGap);
    if(bars.length<required)return {buy:false,reason:'VERI_BOSLUGU',rsi:NaN,atr:NaN};
    const closes=bars.map(b=>b.c),last=bars.at(-1);
    const currentRsi=rsi(closes,cfg.rsiPeriod),previousRsi=rsi(closes.slice(0,-1),cfg.rsiPeriod);
    const currentAtr=atr(bars,cfg.atrPeriod),trend=ema(closes,cfg.trendPeriod),previousTrend=ema(closes.slice(0,-1),cfg.trendPeriod);
    let reason='RSI_TOPARLANMA_BEKLE';
    if(last.c<trend||trend<previousTrend)reason='DUSEN_TREND';
    else if(currentAtr/last.c<cfg.minAtrPct||currentAtr/last.c>cfg.maxAtrPct)reason='VOLATILITE';
    else if(bars.slice(-21).every(b=>finite(b.v)) && last.v<bars.slice(-21,-1).reduce((s,b)=>s+b.v,0)/20*cfg.volumeRatio)reason='DUSUK_HACIM';
    else if(previousRsi<=cfg.rsiRecovery && currentRsi>cfg.rsiRecovery && last.c>last.o)reason='RSI_TOPARLANMA';
    return {buy:reason==='RSI_TOPARLANMA',reason,rsi:currentRsi,previousRsi,atr:currentAtr,trend};
  }

  class CandleBook {
    constructor(intervalMs=900000,maxGapMs=60000){this.intervalMs=intervalMs;this.maxGapMs=maxGapMs;this.series=new Map();}
    ingest(symbol,price,t) {
      if(!finite(price)||price<=0||!Number.isSafeInteger(t))return null;
      const rows=this.series.get(symbol)||[];const last=rows.at(-1);const bucket=Math.floor(t/this.intervalMs)*this.intervalMs;
      if(last && t<=last.lastTick)return null;
      let closed=null;
      if(!last||last.t!==bucket){
        if(last){last.complete=last.complete && last.lastTick>=last.t+this.intervalMs-this.maxGapMs && bucket===last.t+this.intervalMs;closed={...last};}
        rows.push({t:bucket,o:price,h:price,l:price,c:price,lastTick:t,complete:t-bucket<=this.maxGapMs});
        if(rows.length>261)rows.shift();
      }else{last.complete=last.complete&&t-last.lastTick<=this.maxGapMs;last.h=Math.max(last.h,price);last.l=Math.min(last.l,price);last.c=price;last.lastTick=t;}
      this.series.set(symbol,rows);return closed;
    }
    closed(symbol){return (this.series.get(symbol)||[]).slice(0,-1).map(b=>({...b}));}
  }
  function parseCsv(text) {
    const lines=text.trim().replace(/^\uFEFF/,'').split(/\r?\n/);
    if(lines.length<3||lines.length>200001)throw new Error('CSV 2..200000 mum içermeli.');
    const header=lines.shift().trim().toLowerCase().split(',');
    const required=['timestamp','open','high','low','close'];
    if(!required.every(k=>header.includes(k)))throw new Error('Başlık: timestamp,open,high,low,close,volume (volume isteğe bağlı).');
    const rows=lines.map(line=>{
      const f=line.split(',').map(s=>s.trim());
      if(f.length!==header.length||f.some(x=>x===''))throw new Error('Boş/hatalı CSV hücresi. Ondalık ayırıcı nokta olmalı.');
      const get=k=>f[header.indexOf(k)];
      const raw=get('timestamp');
      if(!/^\d{13}$/.test(raw)&&!/(Z|[+-]\d{2}:\d{2})$/.test(raw))throw new Error('Zaman UTC/offset içeren ISO veya milisaniye olmalı.');
      const t=/^\d{13}$/.test(raw)?Number(raw):Date.parse(raw);
      const b={t,o:Number(get('open')),h:Number(get('high')),l:Number(get('low')),c:Number(get('close'))};
      if(header.includes('volume'))b.v=Number(get('volume'));
      return b;
    });
    return validateBars(rows);
  }
  return {DEFAULTS,ema,rsi,atr,signal,settings,validateBars,CandleBook,parseCsv};
});
