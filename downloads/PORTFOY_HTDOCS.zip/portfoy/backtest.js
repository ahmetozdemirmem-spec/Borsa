(function(root,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory(require('./strategy.js'));
  else root.PortfoyBacktest=factory(root.Portfoy);
})(typeof globalThis!=='undefined'?globalThis:this,function(P){
  'use strict';
  const DEFAULTS=Object.freeze({initialCapital:100000,commissionRate:0.0015,slippageRate:0.0005,spreadPct:0.002,
    riskPerTrade:0.005,maxPositionPct:0.10,maxOrderTL:9000,hardStopPct:0.02,maxStopPct:0.04,atrStopMultiple:2,
    trailActivationPct:0.02,trailDistancePct:0.006,maxHoldingHours:48,maxDailyLossPct:0.02,maxDrawdownPct:0.06,
    maxConsecutiveLosses:3,lossPauseMinutes:120,cooldownMinutes:60,sessionStart:'10:05',sessionEnd:'17:50',closedDates:[]});
  function run(input,options={}){
    P.validateBars(input);if(input.length<3)throw new Error('En az 3 mum gerekli.');
    const c={...DEFAULTS,...options};
    for(const k of Object.keys(DEFAULTS).filter(k=>typeof DEFAULTS[k]==='number'))
      if(typeof c[k]!=='number'||!Number.isFinite(c[k])||c[k]<=0)throw new Error('Geçersiz test ayarı: '+k);
    for(const k of ['commissionRate','slippageRate','spreadPct','riskPerTrade','maxPositionPct','hardStopPct','maxStopPct','trailActivationPct','trailDistancePct','maxDailyLossPct','maxDrawdownPct'])
      if(c[k]>=1)throw new Error('Test oranı 0..1 aralığında olmalı: '+k);
    const cfg=P.settings(c.strategy);
    const split=options.tradeFrom??0;
    if(!Number.isInteger(split)||split<0||split>=input.length)throw new Error('Geçersiz test başlangıcı.');
    // ASK bars in; BID approximated by spread. True bid/ask history is preferable.
    let cash=c.initialCapital,position=null,pending=null,peak=cash,maxDrawdown=0,dayStart=cash,day='',dailyBlocked=false,ddBlocked=false;
    let cooldownUntil=0,lossStreak=0,pauseUntil=0;const trades=[],curve=[];
    const bid=ask=>ask/(1+c.spreadPct);
    const equity=price=>cash+(position?position.qty*bid(price)*(1-c.slippageRate)*(1-c.commissionRate):0);
    const local=t=>new Date(t+3*3600000).toISOString();
    const session=t=>{const d=new Date(t+3*3600000),clock=local(t).slice(11,16);return d.getUTCDay()>0&&d.getUTCDay()<6&&!c.closedDates.includes(local(t).slice(0,10))&&clock>=c.sessionStart&&clock<c.sessionEnd;};
    function updateRisk(e){peak=Math.max(peak,e);maxDrawdown=Math.max(maxDrawdown,(peak-e)/peak);if(e<=peak*(1-c.maxDrawdownPct))ddBlocked=true;if(e<=dayStart*(1-c.maxDailyLossPct))dailyBlocked=true;}
    function exit(ask,t,reason){
      const sell=bid(ask)*(1-c.slippageRate),fee=position.qty*sell*c.commissionRate;
      const pnl=position.qty*(sell-position.cost)-position.fee-fee;
      cash+=position.qty*sell-fee;
      trades.push({entryTime:position.t,exitTime:t,qty:position.qty,buy:position.cost,sell,fees:position.fee+fee,netPnl:pnl,reason});
      position=null;cooldownUntil=t+c.cooldownMinutes*60000;
      lossStreak=pnl<0?lossStreak+1:0;if(lossStreak>=c.maxConsecutiveLosses){pauseUntil=t+c.lossPauseMinutes*60000;lossStreak=0;}
      updateRisk(cash);
    }
    for(let i=split;i<input.length;i++){
      const b=input[i];const currentDay=local(b.t).slice(0,10);
      if(day!==currentDay){day=currentDay;dayStart=i===split?cash:equity(input[i-1].c);dailyBlocked=false;}
      updateRisk(equity(b.o));
      // Signals are from the PREVIOUS close. Orders fill at the NEXT open, with costs.
      if(pending&&!position&&!dailyBlocked&&!ddBlocked&&b.t>=cooldownUntil&&b.t>=pauseUntil&&session(b.t)&&b.t-pending.at===cfg.intervalMs){
        const price=b.o*(1+c.slippageRate),stopPct=Math.max(c.hardStopPct,pending.atr*c.atrStopMultiple/price);
        const unitRisk=price*stopPct+price*c.commissionRate+price*(1-stopPct)*(c.commissionRate+c.slippageRate);
        const qty=stopPct<=c.maxStopPct?Math.floor(Math.min(cash*c.riskPerTrade/unitRisk,Math.min(c.maxOrderTL,cash*c.maxPositionPct)/(price*(1+c.commissionRate)))):0;
        if(qty>0){const fee=price*qty*c.commissionRate;cash-=price*qty+fee;position={cost:price,qty,fee,t:b.t,stop:price*(1-stopPct),peak:bid(b.o),armed:false};}
      }
      pending=null;
      if(position){
        // Adverse-first OHLC path: existing stop, then time exit, then peak update.
        // New trailing levels only become effective on the next bar (intrabar path unknown).
        if(bid(b.o)<=position.stop)exit(b.o,b.t,'GAP_STOP');
        else if(bid(b.l)<=position.stop)exit(position.stop*(1+c.spreadPct),b.t,'STOP');
        else if(b.t-position.t>=c.maxHoldingHours*3600000)exit(b.o,b.t,'TIME_EXIT');
        else {
          position.peak=Math.max(position.peak,bid(b.h));
          position.armed=position.armed||position.peak>=position.cost*(1+c.trailActivationPct);
          if(position.armed)position.stop=Math.max(position.stop,position.peak*(1-c.trailDistancePct),position.cost*(1+c.commissionRate)/((1-c.slippageRate)*(1-c.commissionRate)));
        }
      }
      // Also record adverse intrabar valuation, rather than hiding losses at the close.
      if(position)updateRisk(equity(b.l));
      const e=equity(b.c);updateRisk(e);curve.push({t:b.t,equity:e});
      const sig=P.signal(input.slice(Math.max(0,i-259),i+1),cfg);
      if(sig.buy&&!position&&!dailyBlocked&&!ddBlocked)pending={atr:sig.atr,at:b.t};
    }
    if(position)exit(input.at(-1).c,input.at(-1).t,'END_OF_DATA');
    const finalEquity=cash;updateRisk(finalEquity);
    if(curve.length)curve.at(-1).equity=finalEquity;
    const wins=trades.filter(t=>t.netPnl>0),losses=trades.filter(t=>t.netPnl<0);
    const grossProfit=wins.reduce((s,t)=>s+t.netPnl,0),grossLoss=-losses.reduce((s,t)=>s+t.netPnl,0);
    const start=input[split].o*(1+c.slippageRate),end=bid(input.at(-1).c)*(1-c.slippageRate);
    const buyHoldPct=(end*(1-c.commissionRate)/(start*(1+c.commissionRate))-1)*100;
    return {bars:input.length-split,tradeCount:trades.length,netPnl:finalEquity-c.initialCapital,netReturnPct:(finalEquity/c.initialCapital-1)*100,
      maxDrawdownPct:maxDrawdown*100,winRate:trades.length?wins.length/trades.length*100:null,
      profitFactor:grossLoss?grossProfit/grossLoss:null,profitFactorNote:grossLoss?'':'Kayıp işlem yok; oran hesaplanamadı.',
      fees:trades.reduce((s,t)=>s+t.fees,0),buyHoldPct,trades,curve,config:c,
      warnings:[...(trades.length<30?['30 işlemden az: istatistiksel güven yetersiz.']:[]),'Tek hisse testi; portföy/korelasyon performansı değildir.','Spread ve kayma varsayımdır; stop fiyatı garanti değildir.','Komisyon dışındaki vergi/kurum masrafları eklenmelidir.']};
  }
  function walkForward(bars,options={}){
    const folds=options.folds??3,trainBars=options.trainBars??Math.floor(bars.length/2);
    if(!Number.isInteger(folds)||folds<1||folds>20||!Number.isInteger(trainBars)||trainBars<60||trainBars>=bars.length)throw new Error('Walk-forward için daha fazla veri gerekli.');
    const size=Math.floor((bars.length-trainBars)/folds);
    if(size<30)throw new Error('Her test dilimi en az 30 mum içermeli.');
    const results=[];
    for(let k=0;k<folds;k++){
      const start=trainBars+k*size,end=k===folds-1?bars.length:start+size;
      const result=run(bars.slice(Math.max(0,start-260),end),{...options,tradeFrom:Math.min(260,start)});
      results.push({...result,from:bars[start].t,to:bars[end-1].t});
    }
    return {folds:results,method:'Sabit parametreli ardışık dönem testi; optimizasyon yapılmaz. Her dilim ayrı başlangıç sermayesiyle ölçülür.'};
  }
  return {DEFAULTS,run,walkForward};
});
