(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.PortfoyDemo=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  /** Deterministic SYNTHETIC fixture; never market history or evidence of returns. */
  function bars(count=720){
    const rows=[];let t=Date.parse('2026-06-01T07:00:00Z'),price=100;
    for(let i=0;i<count;i++){
      const phase=i%100;
      const delta=phase<65?0.38:phase<92?-0.22:0.8;
      const o=price;price=Math.max(5,o+delta+Math.sin(i*1.7)*0.025);
      rows.push({t,o,h:Math.max(o,price)+0.22,l:Math.min(o,price)-0.22,c:price,v:10000+(i%9)*300,complete:true});
      t+=900000;
      if(new Date(t).getUTCHours()>=15){const d=new Date(t);d.setUTCDate(d.getUTCDate()+1);d.setUTCHours(7,0,0,0);while([0,6].includes(d.getUTCDay()))d.setUTCDate(d.getUTCDate()+1);t=d.getTime();}
    }
    return rows;
  }
  return {bars};
});
