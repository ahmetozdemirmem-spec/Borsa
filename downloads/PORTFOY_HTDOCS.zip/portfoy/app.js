/* global Portfoy, PortfoyBacktest, PortfoyDemo */
'use strict';
const $=id=>document.getElementById(id);
const money=v=>Number.isFinite(v)?v.toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2}):'—';
const time=t=>t?new Date(t).toLocaleString('tr-TR',{timeZone:'Europe/Istanbul'}):'—';
const model={account:null,quotes:new Map(),signals:new Map(),bars:new Portfoy.CandleBook(),pending:[],universe:[],
  ws:null,timer:null,running:false,feedHealthy:false,generation:0,tradeIds:new Map(),logs:[],report:null,autoQueue:new Set()};
let chain=Promise.resolve();
function log(message){model.logs.push(`[${time(Date.now())}] ${message}`);model.logs=model.logs.slice(-200);$('log').textContent=model.logs.join('\n');}
function request(action,body){
  const task=chain.then(async()=>{
    const options={cache:'no-store',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':document.querySelector('meta[name="csrf-token"]').content}};
    if(body!==undefined){options.method='POST';options.body=JSON.stringify(body);}
    const r=await fetch('?api='+encodeURIComponent(action),options);const data=await r.json();
    if(!r.ok||!data.ok)throw new Error(data.error||'Sunucu işlemi başarısız.');
    receiveAccount(data);return data;
  });
  chain=task.catch(()=>{});return task;
}
function receiveAccount(a){
  const oldIds=new Set((model.account?.trades||[]).map(t=>t.id));
  if(model.account)for(const t of a.trades)if(!oldIds.has(t.id))log(`${t.side==='B'?'AL':'SAT'} ${t.symbol} × ${t.qty} @ ${money(t.price)} ${t.reason||''}`);
  model.account=a;$('mode').value=a.mode;render();
}
function cell(row,value,cls){const td=document.createElement('td');td.textContent=value;if(cls)td.className=cls;row.append(td);return td;}
function row(tbody){const tr=document.createElement('tr');tbody.append(tr);return tr;}
function button(td,label,action,disabled=false){const b=document.createElement('button');b.textContent=label;b.disabled=disabled;b.addEventListener('click',action);td.append(b);}
function cfg(){return {rsiRecovery:Number($('rsiRecovery').value)};}
function render(){
  const a=model.account;if(!a)return;
  for(const [id,value] of [['equity',a.equity],['cash',a.cash],['net',a.netPnl],['daily',a.dailyPnl]])$(id).textContent=money(value)+' TL';
  $('dd').textContent=money(a.drawdownPct)+'%';$('risk').textContent=a.riskStatus;$('risk').className=a.entriesBlocked?'neg':'pos';
  $('riskConfig').textContent=`Sunucu limitleri · İşlem riski %${a.config.riskPerTrade*100} · Tek hisse %${a.config.maxPositionPct*100} · En çok ${a.config.maxPositions} pozisyon · Günlük kayıp %${a.config.maxDailyLossPct*100} · Azami düşüş %${a.config.maxDrawdownPct*100} · Komisyon her yönde %${a.config.commissionRate*100} · Kayma her yönde %${a.config.slippageRate*100}`;
  $('universe').textContent=`${a.mode==='demo'?'SENTETİK DEMO':'PİYASA / PAPER'} · ${model.universe.length} sembol`;
  $('scanRows').replaceChildren();
  for(const symbol of [...model.universe].sort()){
    const q=model.quotes.get(symbol)||{},s=model.signals.get(symbol)||{reason:'ISINMA'},tr=row($('scanRows'));
    const fresh=Date.now()-(q.askAt||0)<=a.config.quoteMaxAgeMs && Date.now()-(q.bidAt||0)<=a.config.quoteMaxAgeMs;
    cell(tr,symbol);cell(tr,money(q.ask));cell(tr,money(q.bid));cell(tr,q.ask&&q.bid?money((q.ask/q.bid-1)*100):'—');cell(tr,money(s.rsi));
    cell(tr,fresh?s.reason:'FİYAT BEKLE / ESKİ');
    button(cell(tr,''),'AL',()=>trade('buy',symbol,false),!model.running||!model.feedHealthy||!fresh||a.entriesBlocked||!!a.positions[symbol]);
    cell(tr,time(Math.min(q.askAt||0,q.bidAt||0)));
  }
  $('positionRows').replaceChildren();$('positionCount').textContent=` · ${Object.keys(a.positions).length} pozisyon`;
  for(const p of Object.values(a.positions).sort((x,y)=>x.symbol.localeCompare(y.symbol))){
    const tr=row($('positionRows')),net=p.last*p.qty*(1-a.config.slippageRate)*(1-a.config.commissionRate)-p.cost*p.qty-p.entryFee;
    const stale=Date.now()-(p.lastAt||0)>a.config.quoteMaxAgeMs;
    cell(tr,p.symbol);cell(tr,p.qty);cell(tr,money(p.cost));cell(tr,money(p.last)+(stale?' (eski)':''));cell(tr,money(net),net>=0?'pos':'neg');cell(tr,money(p.stop));cell(tr,(stale?'VERİ ESKİ / ':'')+(p.armed?'TRAILING':'HARD STOP'));button(cell(tr,''),'SAT',()=>trade('sell',p.symbol,false),!model.feedHealthy);cell(tr,time(p.openedAt));
  }
  $('soldRows').replaceChildren();
  for(const t of a.trades.filter(t=>t.side==='S').slice(-150).reverse()){
    const tr=row($('soldRows'));cell(tr,t.symbol);cell(tr,t.qty);cell(tr,money(t.buy));cell(tr,money(t.price));cell(tr,money(t.fee+t.entryFee));cell(tr,money(t.netPnl),t.netPnl>=0?'pos':'neg');cell(tr,t.reason);cell(tr,time(t.buyTime));cell(tr,time(t.time));
  }
}
function quote(symbol,field,value,t=Date.now()){
  if(!model.running||!model.universe.includes(symbol)&&!model.account?.positions[symbol])return;
  const v=typeof value==='object'?value?.v??value?.value??value?.data_value:value;
  const price=Number(v);if(!Number.isFinite(price)||price<=0||!['ask','bid'].includes(field))return;
  const q=model.quotes.get(symbol)||{};if(t<(q[field+'At']||0))return;
  q[field]=price;q[field+'At']=t;model.quotes.set(symbol,q);
  // Preserve every tick, including temporary stop crossings and rebounds.
  model.pending.push({symbol,[field]:price,[field+'At']:t});
  if(model.pending.length>5000){stopFeed();log('Fiyat kuyruğu taştı. Akış ve otomasyon kapatıldı; bağlantıyı kontrol edin.');return;}
  if(field==='ask'&&model.account?.mode==='market'){
    const closed=model.bars.ingest(symbol,price,t);
    if(closed){const s=Portfoy.signal(model.bars.closed(symbol),cfg());model.signals.set(symbol,s);if(s.buy&&$('autoBuy').checked)model.autoQueue.add(symbol);}
  }
}
async function flush(){
  if(!model.pending.length)return;
  const rows=model.pending.splice(0);
  try{for(let i=0;i<rows.length;i+=250)await request('quotes',{quotes:rows.slice(i,i+250),source:model.account.mode});model.feedHealthy=true;}
  catch(e){model.feedHealthy=false;model.autoQueue.clear();$('autoBuy').checked=false;model.bars=new Portfoy.CandleBook();log('FİYAT / RİSK HATASI: '+e.message);throw e;}
}
async function trade(side,symbol,auto){
  const key=side+':'+symbol;if(model.tradeIds.has(key))return;
  if(!auto&&!confirm(`${symbol} için PAPER ${side==='buy'?'AL':'SAT'} işlemi yapılsın mı? Gerçek emir gönderilmez.`))return;
  const id=crypto.randomUUID();model.tradeIds.set(key,id);
  try{
    await flush();if(!model.feedHealthy)throw new Error('Doğrulanmış fiyat akışı yok.');
    const body={id,symbol,dry_run:true,reason:auto?'RSI_RECOVERY':'MANUAL'};
    const atr=model.signals.get(symbol)?.atr;if(side==='buy'&&Number.isFinite(atr))body.atr=atr;
    // Retry ambiguous transport errors with the SAME id, never a fresh order id.
    try{await request(side,body);}catch(e){if(e instanceof TypeError)await request(side,body);else throw e;}
  }catch(e){log(`${symbol} ${side} ENGEL: ${e.message}`);}finally{model.tradeIds.delete(key);render();}
}
function stopFeed(){
  model.running=false;model.feedHealthy=false;model.generation++;model.autoQueue.clear();$('autoBuy').checked=false;
  if(model.timer)clearInterval(model.timer);model.timer=null;
  if(model.ws){model.ws.onclose=null;model.ws.close();model.ws=null;}
  model.pending=[];$('feedStatus').textContent='Akış kapalı: strateji ve stop takibi durdu. Mevcut pozisyonlar saklanır.';render();
}
function parsePayload(payload,depth=0){
  if(depth>8||payload==null)return;
  if(Array.isArray(payload)){payload.forEach(v=>parsePayload(v,depth+1));return;}
  if(typeof payload!=='object')return;
  const key=payload.k??payload.topic??payload.channel??payload.path;
  if(key){const parts=String(key).replace(/^r\//,'').split('/');const field=parts[1]==='A'?'ask':parts[1]==='B'?'bid':null;if(field)quote(parts[0],field,payload.v??payload.value??payload.data_value);}
  const symbol=payload.code??payload.symbol??payload.o;
  if(typeof symbol==='string')for(const src of [payload,payload.v])if(src&&typeof src==='object'){
    if(src.A!==undefined||src.ask!==undefined)quote(symbol,'ask',src.A??src.ask);
    if(src.B!==undefined||src.bid!==undefined)quote(symbol,'bid',src.B??src.bid);
  }
  for(const name of ['data','rows','results','payload','message','messages','items','result'])if(payload[name]&&typeof payload[name]==='object')parsePayload(payload[name],depth+1);
}
async function startFeed(){
  if($('start').disabled)return;
  $('start').disabled=true;
  const target=$('mode').value;stopFeed();const intent=model.generation;
  try{
    if(target!==model.account.mode)await request('mode',{mode:target});
    if(intent!==model.generation)return;
    const symbols=[...new Set($('symbols').value.toUpperCase().split(',').map(s=>s.trim()).filter(Boolean))];
    if(!symbols.length||symbols.length>100||symbols.some(s=>!/^[A-Z0-9][A-Z0-9._-]{1,11}$/.test(s)))throw new Error('1..100 geçerli sembol gerekli.');
    model.universe=[...new Set([...symbols,...Object.keys(model.account.positions)])];model.quotes.clear();model.signals.clear();model.bars=new Portfoy.CandleBook();
    model.running=true;const gen=model.generation;
    if(target==='demo'){
      const samples=PortfoyDemo.bars(1200);let step=90;
      log('SENTETİK DEMO başladı. Fiyatlar ve mumlar yapaydır; geçmiş piyasa performansı değildir.');
      $('feedStatus').textContent='SENTETİK DEMO: her saniye bir yapay mum ilerler. Gerçek piyasa değildir.';
      const tick=async()=>{
        if(gen!==model.generation)return;
        try{
          for(const [i,symbol] of model.universe.entries()){
            const scale=1+i*0.6,b=samples[step%samples.length],t=Date.now();
            quote(symbol,'ask',b.c*scale,t);quote(symbol,'bid',b.c*scale/1.002,t);
            const hist=samples.slice(Math.max(0,step-259),step+1).map(x=>({...x,o:x.o*scale,h:x.h*scale,l:x.l*scale,c:x.c*scale}));
            const s=Portfoy.signal(hist,cfg());model.signals.set(symbol,s);if(s.buy&&$('autoBuy').checked)model.autoQueue.add(symbol);
          }
          await flush();await drainAuto();step++;if(step>=samples.length)step=90;
        }catch(e){log(e.message);}
      };
      let busy=false;const guarded=async()=>{if(busy)return;busy=true;try{await tick();}finally{busy=false;}};
      await guarded();model.timer=setInterval(guarded,1000);
    }else{
      const token=$('feedToken').value.trim().replace(/^Bearer\s+/i,'');if(!token)throw new Error('Yetkili Fintables veri anahtarı gerekli.');
      const ws=new WebSocket('wss://markets.fintables.com/vessel');model.ws=ws;
      ws.onopen=()=>{if(gen===model.generation)ws.send(JSON.stringify({type:'login',token}));};
      ws.onmessage=event=>{
        if(gen!==model.generation)return;
        try{const data=JSON.parse(event.data);
          if(data.type==='login_success'){
            const topics=model.universe.flatMap(s=>[s+'/A',s+'/B']);for(let i=0;i<topics.length;i+=120)ws.send(JSON.stringify({type:'subscribe',topics:topics.slice(i,i+120)}));
            $('feedToken').value='';$('feedStatus').textContent='Piyasa / PAPER: A-B akışı. Kaynak zamanı sağlanmıyorsa yalnız alım zamanı ölçülür; sağlayıcı gecikmesi doğrulanamaz.';
          }else if(/error|fail/i.test(String(data.type||''))){stopFeed();log('Veri sağlayıcısı bağlantıyı reddetti.');}
          else parsePayload(data);
        }catch(e){log('Veri paketi okunamadı.');}
      };
      ws.onerror=()=>{stopFeed();log('WebSocket bağlantı hatası. Otomasyon kapatıldı.');};
      ws.onclose=()=>{stopFeed();log('WebSocket kapandı. Anahtar doğrulanıp yeniden başlatılmalı.');};
      let busy=false;model.timer=setInterval(async()=>{if(busy||gen!==model.generation)return;busy=true;try{await flush();await drainAuto();render();}catch(e){log(e.message);}finally{busy=false;}},1000);
    }
  }catch(e){stopFeed();$('mode').value=model.account.mode;log(e.message);}finally{$('start').disabled=false;}
  render();
}
async function drainAuto(){
  const symbols=[...model.autoQueue];model.autoQueue.clear();
  if(!$('autoBuy').checked||!model.running||!model.feedHealthy)return;
  for(const symbol of symbols)await trade('buy',symbol,true);
}
function download(name,value){const url=URL.createObjectURL(new Blob([JSON.stringify(value,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function drawCurve(curve){
  const svg=$('curve');svg.replaceChildren();if(!curve.length)return;
  const values=curve.map(x=>x.equity),min=Math.min(...values),max=Math.max(...values),range=Math.max(1,max-min);
  const poly=document.createElementNS('http://www.w3.org/2000/svg','polyline');poly.setAttribute('points',curve.map((v,i)=>`${i/(curve.length-1||1)*780+10},${145-(v.equity-min)/range*130}`).join(' '));svg.append(poly);
}
async function test(sample=false){
  $('testResult').textContent='Test çalışıyor…';$('backtest').disabled=true;$('sample').disabled=true;
  try{
    let bars;
    if(sample)bars=PortfoyDemo.bars(720);
    else{const file=$('csv').files[0];if(!file)throw new Error('Önce CSV seçin.');if(file.size>8*1024*1024)throw new Error('CSV 8 MB sınırını aşıyor.');bars=Portfoy.parseCsv(await file.text());}
    if(bars.length>10000)throw new Error('Tarayıcı testi en fazla 10000 mum. Daha büyük veriyi CLI ile çalıştırın.');
    // Yield once so the busy state paints before CPU work.
    await new Promise(resolve=>setTimeout(resolve,20));
    const options={...model.account.config,spreadPct:Number($('spread').value)/100,strategy:cfg()};
    const result=PortfoyBacktest.run(bars,options);let wf;
    try{wf=PortfoyBacktest.walkForward(bars,options);}catch(e){wf={error:e.message};}
    model.report={createdAt:new Date().toISOString(),synthetic:sample,result,walkForward:wf};$('downloadReport').disabled=false;
    const lines=[sample?'SENTETİK ÖRNEK · kâr kanıtı değildir.':'Yüklenen CSV testi · veri kalitesi kullanıcı tarafından doğrulanmalıdır.',
      `${result.tradeCount} işlem · Net ${money(result.netPnl)} TL (%${money(result.netReturnPct)}) · Azami düşüş %${money(result.maxDrawdownPct)}`,
      `Komisyon ${money(result.fees)} TL · Kazanma oranı ${result.winRate===null?'hesaplanamadı':money(result.winRate)+'%'} · Kâr faktörü ${result.profitFactor===null?'hesaplanamadı':money(result.profitFactor)}`,
      `Aynı veriyle al-tut: %${money(result.buyHoldPct)} (tam sermaye; bot en çok %10 tek hisse kullanır, riskler farklıdır).`,...result.warnings];
    if(wf.folds)for(const [i,f] of wf.folds.entries())lines.push(`Dönem ${i+1}: ${f.tradeCount} işlem · %${money(f.netReturnPct)} net · %${money(f.maxDrawdownPct)} düşüş`);
    else lines.push('Dönem testi: '+wf.error);
    $('testResult').textContent=lines.join('\n');drawCurve(result.curve);
  }catch(e){$('testResult').textContent='Test tamamlanamadı: '+e.message;}finally{$('backtest').disabled=false;$('sample').disabled=false;}
}
$('start').onclick=startFeed;$('stop').onclick=stopFeed;$('refresh').onclick=()=>request('state').catch(e=>log(e.message));
$('kill').onclick=async()=>{$('autoBuy').checked=false;model.autoQueue.clear();try{await request('kill',{});log('Yeni alımlar kapatıldı; fiyat akışını açık tutun, koruyucu çıkışlar çalışmaya devam eder.');}catch(e){log(e.message);}};
$('resume').onclick=()=>request('resume',{}).then(()=>log('Acil durdurma kaldırıldı; kayıp/düşüş kilitleri korunur.')).catch(e=>log(e.message));
$('export').onclick=()=>model.account&&download('portfoy-paper-ledger.json',model.account);
$('backtest').onclick=()=>test(false);$('sample').onclick=()=>test(true);$('downloadReport').onclick=()=>download('portfoy-test-raporu.json',model.report);
$('rsiRecovery').onchange=()=>{$('autoBuy').checked=false;model.autoQueue.clear();log('Strateji ayarı değişti; Oto-AL kapatıldı.');};
window.addEventListener('beforeunload',()=>{if(model.ws)model.ws.close();});
request('state').then(()=>log('Paper hesap yüklendi. Otomasyon kapalı; canlı emir yeteneği yok.')).catch(e=>log(e.message));
