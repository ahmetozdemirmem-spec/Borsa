PORTFOY - 3Commas RSI + Trailing Take Profit

Bu sürüm, PORTFOY ASAMA7 arayüzü ve altyapısı temel alınarak hazırlanmıştır.
Ekran düzeni, Ziraat köprüsü, açılış Equity/3AY/HİSSEADET/Tedbir zinciri, WebSocket A/B/P akışı, günlük hacim, log ve tarihli Alınanlar/Satılanlar kayıt-yükleme sistemi korunmuştur.
Değiştirilen bölüm yalnız AL / SAT / Oto-AL / Oto-SAT strateji motorudur.

ZAMAN kolonu tüm tablolarda en sağdadır.
SEMBOL varsayılan A-Z sıralıdır. SEMBOL, GÜN%, KAR%, RSI14, SİNYAL ve MALİYET başlıkları ilgili tablolarda tıklanarak sıralanabilir.

Oto-AL: 15 dakikalık kapanmış Ask mumlarından RSI.
Oto-SAT: Bid üzerinden trailing.
3Commas referansı: RSI14 <= 25; Trailing Take Profit aktivasyon %2.00, sapma %0.10.

2026-09-12 ortak PORTFOY arayuz guncellemesi:
- Satilanlar basligina Aktif Pozisyon eklendi.
- A/B/P abone bilgisinde Tedbir filtresinde elenen hisse sayisi gosterilir.
- Alinanlar/Satilanlar basliginda KarTL gosterilir.
- Tum tablo ZAMAN kolonlari kronolojik/numerik siralanabilir.
- GUNLUK HACIM(TL) her manuel/otomatik AL-SAT isleminde guncellenir, gun degisince sifirlanir ve proje bazinda ayri saklanir.
- Ziraat durumu broker portfoy istegi ile dogrulanir: Giris Yapildi / Giris Yapilmadi.
- Alinanlar tablosuna ALIS TL = ADET x MALIYET eklendi.

2026-09-12 ORTAK UI GUNCELLEMESI
- GUNLUK HACIM(TL) sayfa acilisinda ve tablo yuklemelerinde Alinanlar + Satilanlar tablolarindan yeniden hesaplanir; eski localStorage hacmi tasinmaz.
- Ust satira gunluk performans ozeti eklendi: Sermaye, Islem, Kazanan/Kaybeden, Basari%, Brut KarTL, Acik KarTL, Komisyon, Net KarTL.
- GUNLUK HACIM(TL) saginda yatay ayrintili islem gunlugu eklendi.
- Alinanlar ALIS TL kolonu SUAN TL kolonunun hemen soluna tasindi.

SON DUZENLEME:
- Ustteki ayrintili islem gunlugu kaldirildi; mevcut log sistemi korunur.
- GUNLUK HACIM(TL), performans metrikleriyle ayni kutu gorunumune alindi.
- Sermaye, Islem, Kazanan/Kaybeden ve Basari% ust ozetten kaldirildi.
- Alinanlar Aktif Pozisyon sadece Alinanlar satir sayisini; Satilanlar Aktif Pozisyon sadece Satilanlar satir sayisini sayar.


=== DNA TARAMA + MANUEL HISSE GUNCELLEMESI ===
- Tarama Tablosu acilista HistGradientBoosting DNA 1+3+5 secim listesinden Top-N hisseyi alir.
- DNA modeli: son 30 islem gunu; Volatilite/RVOL/Momentum/ClosePosition/HighDistance 1-3-5 gun ozellikleri.
- Paketteki dna_top100_latest.json secim tarihi: 2026-09-11; egitim: 2026-07-31..2026-09-10.
- HİSSEADET (DNA TOP-N) varsayilan 100 yapildi.
- Kontrol Paneline MANUEL HISSE inputu ve EKLE butonu eklendi. Girilen sembol Tarama Tablosuna eklenir ve WebSocket A/B/P aboneligi baslatilir.
- Manuel ekleme DNA Top-N listesini bozmaz; ek hisse olarak calisir.
