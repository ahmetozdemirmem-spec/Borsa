# Karşılaştırmalı araştırma ve tasarım kararları

İnceleme: 29 Ekim 2026. Bu liste bütün dünyadaki botların taraması veya kârlılık sıralaması değildir. Kamuya açık resmî belgeler ve kaynak kodundaki risk/araştırma yaklaşımları karşılaştırıldı; üçüncü taraf botların getiri iddiaları doğrulanmadı, ücretli ürünlere veya hesaplara giriş yapılmadı.

| Kaynak | İncelenen yaklaşım | PORTFOY'e uygulanan karar | Aktarılmayan varsayım |
| --- | --- | --- | --- |
| 3Commas SmartTrade/DCA | Trailing kâr alımı; aktivasyon sonrası geri çekilme; piyasa emri ve likidite/kayma riski | Bid üzerinden trailing, maliyet sonrası başabaş seviyesi, Ask/Bid ayrımı | Kripto borsasında emir gerçekleşmesini BIST/Ziraat'ta çalışır saymak |
| Freqtrade protections | StoplossGuard, MaxDrawdown, CooldownPeriod | Ardışık kayıp beklemesi, günlük kayıp ve düşüş kilidi, aynı hisseye beklemeli giriş | Bu kontrollerin bir stratejiyi otomatik kârlı yapması |
| Freqtrade lookahead analysis | Tüm veri çerçevesine erişimden doğan geleceği görme yanlılığı | Ortak saf sinyal fonksiyonuna yalnız kapanmış mumlar; sonraki açılışta giriş; gelecekteki veriyi değiştirip geçmiş sonucu karşılaştıran test | Gösterge geçmişini optimizasyon/test sınırından sızdırmak |
| Freqtrade backtesting | Maliyetler, OHLC içi gerçekleşme varsayımları, test ile canlı arasındaki fark | İki yön komisyon, spread ve kayma; gap-stop; açık varsayımlar; sıfır işlemde boş başarı oranı | Varsayılan slippage'sız fill modelinin gerçek BIST likiditesi olması |
| Hummingbot PositionExecutor kaynak kodu | TripleBarrierConfig: stop_loss, take_profit, time_limit, trailing_stop ve volatilite çarpanı | Bağımsız hard stop, ATR ile stop/risk büyüklüğü, süre çıkışı | Hummingbot borsa bağlantılarının Ziraat'ı desteklediği iddiası |

## Doğrudan erişilen kaynaklar

1. [3Commas: How Take Profit Works (SmartTrade and DCA Bots): Trailing Feature Explained](https://help.3commas.io/en/articles/3108981-how-take-profit-works)
2. [Freqtrade: Plugins / Protections](https://www.freqtrade.io/en/stable/plugins/)
3. [Freqtrade: Lookahead analysis](https://www.freqtrade.io/en/stable/lookahead-analysis/)
4. [Freqtrade: Backtesting](https://www.freqtrade.io/en/stable/backtesting/)
5. [Hummingbot resmî depo: PositionExecutor / data_types.py](https://github.com/hummingbot/hummingbot/blob/master/hummingbot/strategy_v2/executors/position_executor/data_types.py) — ilgili `TripleBarrierConfig` ve `TrailingStop` tanımları raw GitHub üzerinden okundu. Web dokümantasyon yolları 404/403 döndüğünden o sayfaların içeriği incelenmiş sayılmadı. `master` değişebilir; bu bir sürüm kilidi değildir.

Kaynaklardan mimari/risk fikirleri alındı; botlar indirilip çalıştırılmadı, aralarında performans yarışı yapılmadı. PORTFOY uygulaması bağımsızdır.

## Zipteki durum ve yeni hipotez

Orijinal belge RSI(14) <=25 olduğunda alım, +%2 aktivasyon ve %0,10 trailing tarif ediyor ve hard stop içermiyor. Bu tarihsel tasarım bağlamı olarak okundu; kullanıcının güncel düşük risk hedefi doğrultusunda hard stop ve sermaye sınırlamaları eklendi.

RSI'nın düşük olması tek başına trend dönüşü değildir. Yeni hipotez: yükselen trendde bir geri çekilme sonrası RSI toparlanmasını beklemek ve yüksek volatilitede pozisyonu küçültmek/işlemi reddetmek. Bu filtre işlem sayısını azaltabilir, toparlanma fırsatlarını kaçırabilir veya performansı düşürebilir. Veriyle ölçülmeden eski stratejiden daha çok kazandırdığı söylenemez.

%0,10 trailing, işlem maliyetleri ve fiyat oynaklığı karşısında dar kalabilir. Varsayılan %0,60 yapıldı; stop hiçbir zaman gevşetilmez, maliyetleri karşılayan başabaş seviyesi aktivasyon sonrasında dikkate alınır. Bu sayılar optimize edilmedi; piyasaya göre araştırılacak başlangıç değerleridir.

DNA dosyasında güncel eğitim hattı/model artefaktı yoktur. Statik bir geçmiş Top100 listesini ileriye dönük ML sinyali gibi kullanmak seçim yanlılığı yaratır. Bu nedenle dosya tarihli örnek olarak saklandı, otomatik seçimden çıkarıldı. Model yeniden eklenecekse her tarihte yalnız geçmiş veriden seçim, survivorship-bias denetimi ve ayrı test dönemi gerekir.

## Gerçek performans araştırması için gerekenler

- Lisanslı, doğru zaman damgalı ve şirket aksiyonları düzeltilmiş Ask/Bid/tick veya yeterli çözünürlükte mum geçmişi; geçmişte işlemden kalkan hisseler de dahil uygun evren.
- Birden çok piyasa rejimi; yükseliş, düşüş, yatay dönem, likidite şoku ve taban/tavan senaryoları.
- İşlem büyüklüğüne bağlı spread/kayma, gerçek kurum ücretleri, vergiler ve emir iptal/gerçekleşme gecikmesi.
- Parametre araması yapılacaksa zaman sıralı ayrı eğitim/doğrulama/son test; son test sonucuna göre tekrar seçimin raporlanması.
- Portföy düzeyinde eşzamanlı sinyaller, sektör yoğunluğu/korelasyon, risk ayarlı kıyas ve belirsizlik aralıkları.
- Canlıya geçişten önce kesintisiz paper izleme, sağlayıcı/veri gecikmesi ve kurumla gerçek emir mutabakatı doğrulaması.

Bu sürüm bu verilerin mevcut olduğunu veya bu aşamaların tamamlandığını iddia etmez. Martingale/zarara ek alım, kaldıraç ve kontrolsüz grid eklenmedi; kaybı büyütmeden önce ölçülebilir bir taban oluşturuldu.
