# Doğrulama kaydı

29 Ekim 2026 tarihinde mevcut bulut makinesinde PHP 8.4.27, Node.js 24.19.0 ve Python 3.12 ile çalıştırıldı. Tarayıcı doğrulaması Playwright 1.62.1 ve sistem Chromium'u kullandı.

## Otomatik kontroller

- **13 strateji/backtest testi geçti:** Wilder RSI, ATR, ısınma, düşen trendde yanlış AL engeli, mum kapanışı, eksik mum, CSV doğrulaması, sonraki açılıştan fill, iki yön maliyet, gelecekteki fiyatları değiştirdiğinde geçmişin değişmemesi, maliyet hassasiyeti, fiyat boşluğunda stop ve walk-forward sınırları.
- **27 paper broker testi geçti:** idempotency/yeniden yükleme, aynı sembolde tek pozisyon, ayrı Ask/Bid yaşları, bozuk fiyat/spread, güncelliğini yitirmiş pozisyonla yeni risk engeli, maliyetli risk boyutlandırması, hard stop, sıkılaşan trailing, stop tepe değerinin kalıcılığı, cooldown, kayıp/düşüş kilitleri, acil durdurma, ATR reddi, azami pozisyon, doğrulanmış takvim, demo/piyasa ayrımı, batch içindeki stop ihlali ve bozuk ledger'da kapalı kalma.
- **8 yerel HTTP testi geçti:** gerçek PHP endpointleri; sayfa/varlıklar, güvenlik başlıkları, POST+CSRF, paper alış ve stop satışı, kalıcılık, canlı emir engeli, özel dosyaların web kökü dışında olması, acil durdurma ve 12 ayrı PHP sürecinin aynı emri eşzamanlı istemesinde yalnız bir fill.
- **Chromium uçtan uca kontrolü geçti:** demo fiyat akışı, onaylı paper AL/SAT, acil durdurma, sayfa yenilemesinde işlem geçmişi ve kilit, varsayılan kapalı otomasyon, sentetik backtest ve özsermaye eğrisi, mobil yatay taşma kontrolü, sıfır yakalanmamış JavaScript hatası.
- PHP dosyalarında sözdizimi kontrolleri geçti.

Toplam **48 otomatik test + tarayıcı uçtan uca kontrolü**. Testler sıfır testlik koşu değildir; sentetik strateji fixture'ı gerçekten işlem üretir. Sayısal sentetik getiri ekonomik performans kanıtı olarak sunulmaz.

Komutlar:

```sh
sh scripts/check.sh
node tests/browser-smoke.cjs
node scripts/backtest.cjs --demo
```

Bulutun kısıtlı yürütme bağlamı soket açmayı engelledi; HTTP/tarayıcı testleri izinli yerel yürütme bağlamında başarıyla tekrarlandı. HTTP testinin bulduğu bilinmeyen yollarda index fallback sorunu 404 kontrolüyle düzeltildi ve yeniden doğrulandı. PHP için sistem dizinine yazma izni olmadığından doğrulanan Debian paketleri çalışma alanına açıldı; paket/TLS doğrulaması kapatılmadı.

## Doğrulanmayanlar

- Gerçek/lisanslı BIST tarihsel performansı, beklenen getiri, istatistiksel anlamlılık ve eski sürüme göre üstünlük.
- Fintables bağlantısının gerçek anahtar ve abonelikle çalışması, sağlayıcı/borsa zamanı ve gecikmesi.
- Ziraat login, gerçek emir, emir kabulü, kısmi/tam gerçekleşme veya portföy mutabakatı. Bu sürümde canlı emir kod yolu bulunmaz.
- Çok kullanıcılı/Internet'e açık üretim dağıtımı ve sunucunun aracı kurumda koruyucu emir tutması.
- Yeni bir bulut görevine yayımlanmış snapshot'ın geri yüklenmesi. Hiçbir yayınlama yapılmadı.

Çalışma alanındaki yerel işlevsellik ve test sonuçları bu sınırları aşan bir “hazır canlı bot” veya kazanç garantisi değildir.
