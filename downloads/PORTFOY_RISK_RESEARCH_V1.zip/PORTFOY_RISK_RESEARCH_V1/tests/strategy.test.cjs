'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const P=require('../public/assets/strategy.js');const B=require('../public/assets/backtest.js');const demo=require('../public/assets/demo.js');
test('Wilder RSI: rising, falling, flat and insufficient inputs',()=>{
  assert.equal(P.rsi(Array.from({length:30},(_,i)=>i+1)),100);
  assert.equal(P.rsi(Array.from({length:30},(_,i)=>30-i)),0);
  assert.equal(P.rsi(Array(30).fill(10)),50);assert.ok(Number.isNaN(P.rsi([1,2])));
});
test('ATR has a known constant-range value',()=>{const b=Array.from({length:20},(_,i)=>({t:i*900000,o:10,h:11,l:9,c:10}));assert.equal(P.atr(b),2);});
test('strategy warms up, validates settings and rejects missing bars',()=>{
  const bars=demo.bars();assert.equal(P.signal(bars.slice(0,14)).reason,'ISINMA');assert.throws(()=>P.signal(bars,{rsiRecovery:NaN}));
  const sample=bars.slice(0,90).map(b=>({...b}));sample[40].complete=false;assert.equal(P.signal(sample).reason,'EKSIK_MUM');
  const gap=bars.slice(0,90).filter((_,i)=>i!==70);assert.equal(P.signal(gap).reason,'VERI_BOSLUGU');
});
test('a low RSI alone never forces a falling-trend entry',()=>{
  const bars=demo.bars(100).map((b,i)=>({...b,o:200-i,c:199.5-i,h:201-i,l:199-i}));
  const signal=P.signal(bars);assert.equal(signal.buy,false);assert.equal(signal.reason,'DUSEN_TREND');
});
test('candle rollover emits the last closed bar without the new ask',()=>{
  const book=new P.CandleBook(60000,15000);book.ingest('TEST',10,0);for(let t=10000;t<60000;t+=10000)book.ingest('TEST',10+t/10000,t);
  const closed=book.ingest('TEST',100,60000);assert.equal(closed.c,15);assert.equal(closed.complete,true);assert.equal(book.closed('TEST')[0].c,15);
  assert.equal(book.ingest('TEST',1,59999),null);
});
test('a partial initial bar and a feed gap never count as complete history',()=>{
  const book=new P.CandleBook(60000,10000);book.ingest('TEST',10,30000);book.ingest('TEST',11,59000);assert.equal(book.ingest('TEST',12,60000).complete,false);
});
test('CSV requires explicit timezone, chronological OHLC, and nonblank values',()=>{
  const head='timestamp,open,high,low,close,volume\n';
  const good=head+'2026-10-27T08:00:00Z,10,11,9,10,100\n2026-10-27T08:15:00Z,10,12,9,11,200';assert.equal(P.parseCsv(good).length,2);
  assert.throws(()=>P.parseCsv(good.replace('08:00:00Z','08:00:00')));
  assert.throws(()=>P.parseCsv(good.replace(',11,9,10,',',8,9,10,')));
  assert.throws(()=>P.parseCsv(good.replace(',10,100',',,100')));
  assert.throws(()=>P.parseCsv(good.replace('08:15:00Z','08:00:00Z')));
});
test('real strategy signals execute next open and include two-sided costs',()=>{
  const bars=demo.bars(720),result=B.run(bars);assert.ok(result.tradeCount>0,'Fixture must actually trade');
  for(const trade of result.trades){const i=bars.findIndex(b=>b.t===trade.entryTime);assert.ok(i>0);assert.equal(P.signal(bars.slice(Math.max(0,i-260),i)).buy,true);assert.ok(Math.abs(trade.buy-bars[i].o*1.0005)<1e-9);assert.ok(trade.fees>0);}
  assert.ok(result.warnings.some(w=>w.includes('Tek hisse')));
});
test('future data cannot alter prior signals or completed trades',()=>{
  const original=demo.bars(720),boundary=500;
  const altered=original.map((b,i)=>i<boundary?{...b}:{...b,o:b.o*.3,h:b.h*.3,l:b.l*.3,c:b.c*.3});
  const a=B.run(original),b=B.run(altered),t=original[boundary].t;
  assert.deepEqual(a.trades.filter(x=>x.exitTime<t),b.trades.filter(x=>x.exitTime<t));
  assert.deepEqual(a.curve.filter(x=>x.t<t),b.curve.filter(x=>x.t<t));
});
test('higher execution costs reduce results for the same trade path',()=>{
  const bars=demo.bars(),a=B.run(bars,{commissionRate:.0015}),b=B.run(bars,{commissionRate:.003});
  assert.equal(a.tradeCount,b.tradeCount);assert.ok(b.netPnl<a.netPnl);assert.ok(b.fees>a.fees);
});
test('gap stop executes at worse opening bid, not the planned stop',()=>{
  const bars=demo.bars(720),first=B.run(bars).trades[0];const i=bars.findIndex(b=>b.t===first.entryTime)+1;
  for(let j=i;j<bars.length;j++){for(const key of ['o','h','l','c'])bars[j][key]*=.6;}
  const result=B.run(bars);assert.equal(result.trades[0].reason,'GAP_STOP');assert.ok(result.trades[0].netPnl<0);assert.ok(result.maxDrawdownPct>1);
});
test('no-signal data reports zero trades without a fake win rate',()=>{
  const bars=demo.bars(100).map(b=>({...b,o:10,h:10.01,l:9.99,c:10}));const result=B.run(bars);assert.equal(result.tradeCount,0);assert.equal(result.winRate,null);assert.equal(result.netPnl,0);
});
test('walk-forward starts each fold fresh, with only prior warmup data',()=>{
  const bars=demo.bars(),wf=B.walkForward(bars);assert.equal(wf.folds.length,3);
  for(const fold of wf.folds){for(const trade of fold.trades)assert.ok(trade.entryTime>=fold.from&&trade.exitTime<=fold.to);}
  assert.throws(()=>B.walkForward(bars.slice(0,80)));
});
