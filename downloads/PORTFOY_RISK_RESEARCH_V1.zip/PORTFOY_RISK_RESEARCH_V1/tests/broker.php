<?php
declare(strict_types=1);
require __DIR__.'/../app/PaperBroker.php';
$passed=0;$failed=0;$dirs=[];
$now=strtotime('2026-10-27T08:00:00Z')*1000;
function check(bool $v,string $message='assertion'): void { if(!$v)throw new RuntimeException($message); }
function near(float $a,float $b,float $t=0.00001):void {check(abs($a-$b)<$t,"$a != $b");}
function broker(array $overrides=[]):PaperBroker {
    global $dirs;
    $dir=sys_get_temp_dir().'/portfoy-test-'.bin2hex(random_bytes(8));$dirs[]=$dir;
    return new PaperBroker($dir,array_replace(json_decode(file_get_contents(__DIR__.'/../config/risk.json'),true),$overrides));
}
function quotes(PaperBroker $b,int $t,float $bid=100,float $ask=100.2,string $sym='THYAO'):array {
    return $b->handle('quotes',['source'=>'demo','quotes'=>[['symbol'=>$sym,'bid'=>$bid,'ask'=>$ask,'bidAt'=>$t,'askAt'=>$t]]],$t);
}
function buy(PaperBroker $b,int $t,string $sym='THYAO',string $id='test-order-0001'):array{return $b->handle('buy',['symbol'=>$sym,'id'=>$id],$t);}
function rejected(callable $fn,string $text=''):void {
    try{$fn();}catch(DomainException $e){check($text===''||str_contains($e->getMessage(),$text),$e->getMessage());return;}
    throw new RuntimeException('Expected DomainException');
}
function test(string $name,callable $fn):void {
    global $passed,$failed;
    try{$fn();$passed++;echo "PASS $name\n";}catch(Throwable $e){$failed++;echo "FAIL $name: {$e->getMessage()}\n";}
}
test('offline paper fill, fees and cash conservation',function()use($now){
    $b=broker();quotes($b,$now);$s=buy($b,$now);$f=$s['fill'];check($f['qty']>0);check($f['qty']*$f['price']<=9000);
    near($s['cash'],100000-$f['qty']*$f['price']-$f['fee']);check($s['paperOnly']);
    $p=(array)$s['positions'];check($p['THYAO']['stop']<$f['price']);check($s['netPnl']<0,'Costless paper fills');
});
test('live orders unconditionally refused',function()use($now){$b=broker();quotes($b,$now);rejected(fn()=>$b->handle('buy',['symbol'=>'THYAO','id'=>'live-test-01','dry_run'=>false],$now),'canlı');});
test('idempotent accepted fill survives a new broker instance',function()use($now){
    global $dirs;$b=broker();quotes($b,$now);$s=buy($b,$now);$reloaded=new PaperBroker(end($dirs));$again=buy($reloaded,$now);
    check($again['duplicate']);check(count($again['trades'])===1);near($again['cash'],$s['cash']);
});
test('same order id cannot carry a different symbol',function()use($now){$b=broker();quotes($b,$now);buy($b,$now);rejected(fn()=>buy($b,$now,'ASELS'),'farklı');});
test('position per symbol is unique across different ids',function()use($now){$b=broker();quotes($b,$now);buy($b,$now);rejected(fn()=>buy($b,$now,'THYAO','another-id-01'),'ikinci');});
test('stale bid cannot be refreshed with an ask-only message',function()use($now){
    $b=broker();quotes($b,$now);$t=$now+16000;
    $b->handle('quotes',['source'=>'demo','quotes'=>[['symbol'=>'THYAO','ask'=>100.2,'askAt'=>$t]]],$t);
    rejected(fn()=>buy($b,$t),'Güncel');
});
test('old/out-of-order bid cannot replace a newer quote',function()use($now){
    $b=broker();quotes($b,$now);quotes($b,$now+1000,100.1,100.2);quotes($b,$now,90,90.1);
    $s=buy($b,$now+1000);check(((array)$s['positions'])['THYAO']['last']===100.1);
});
test('stale and far-future quote batches are rejected',function()use($now){
    $b=broker();rejected(fn()=>$b->handle('quotes',['source'=>'demo','quotes'=>[['symbol'=>'THYAO','bid'=>10,'bidAt'=>$now-16000]]],$now),'Eski');
    rejected(fn()=>$b->handle('quotes',['source'=>'demo','quotes'=>[['symbol'=>'THYAO','bid'=>10,'bidAt'=>$now+3000]]],$now),'gelecek');
});
test('spread and crossed market block entries',function()use($now){$b=broker();quotes($b,$now,100,102);rejected(fn()=>buy($b,$now),'Spread');quotes($b,$now+1,101,100);rejected(fn()=>buy($b,$now+1),'Spread');});
test('hard stop models gaps at actual bid with adverse slippage',function()use($now){
    $b=broker();quotes($b,$now);buy($b,$now);$s=quotes($b,$now+1000,90,90.1);check(count((array)$s['positions'])===0);$t=end($s['trades']);check($t['reason']==='HARD_STOP');near($t['price'],90*(1-.0005));check($t['netPnl']<0);
});
test('trailing stop only tightens, persists and exits',function()use($now){
    global $dirs;$b=broker();quotes($b,$now);buy($b,$now);$s=quotes($b,$now+1000,104,104.1);$p=((array)$s['positions'])['THYAO'];check($p['armed']);check($p['stop']>100.2);
    $b=new PaperBroker(end($dirs));$s=quotes($b,$now+2000,103.9,104);near(((array)$s['positions'])['THYAO']['stop'],$p['stop']);
    $s=quotes($b,$now+3000,103,103.1);check(count((array)$s['positions'])===0);check(end($s['trades'])['reason']==='TRAILING_STOP');
});
test('stale sale never falls back to cost',function()use($now){$b=broker();quotes($b,$now);buy($b,$now);rejected(fn()=>$b->handle('sell',['symbol'=>'THYAO','id'=>'stale-sale-01'],$now+16000),'Bid');check(count((array)$b->handle('state',[],$now+16000)['positions'])===1);});
test('cooldown prevents immediate re-entry',function()use($now){$b=broker();quotes($b,$now);buy($b,$now);quotes($b,$now+1000,97,97.1);rejected(fn()=>buy($b,$now+1000,'THYAO','cooldown-test-01'),'bekleme');});
test('emergency stop blocks entries, permits exits; resume preserves loss latches',function()use($now){
    $b=broker();quotes($b,$now);buy($b,$now);$b->handle('kill',[],$now);quotes($b,$now,100,100.2,'ASELS');rejected(fn()=>buy($b,$now,'ASELS','kill-order-01'),'devre');
    $s=$b->handle('sell',['symbol'=>'THYAO','id'=>'exit-when-killed'],$now);check(count((array)$s['positions'])===0);
    $s=$b->handle('resume',[],$now);check(!$s['killed']);
});
test('daily loss limit stays latched after rebound and resume',function()use($now){
    $b=broker(['maxDailyLossPct'=>.0001]);quotes($b,$now);buy($b,$now);$s=quotes($b,$now+1000,100,100.2);check($s['entriesBlocked']);
    quotes($b,$now+2000,104,104.1);$s=$b->handle('resume',[],$now+2000);check($s['riskStatus']==='GÜNLÜK KAYIP');
});
test('max drawdown survives next day and resume',function()use($now){
    $b=broker(['maxDrawdownPct'=>.0001]);quotes($b,$now);buy($b,$now);$s=$b->handle('resume',[],$now+86400000);check($s['riskStatus']==='AZAMİ DÜŞÜŞ');
});
test('loss streak pauses all symbols',function()use($now){$b=broker(['maxConsecutiveLosses'=>1]);quotes($b,$now);buy($b,$now);quotes($b,$now+1000,97,97.1);quotes($b,$now+1000,100,100.2,'ASELS');rejected(fn()=>buy($b,$now+1000,'ASELS','streak-test-01'),'devre');});
test('stale open position blocks increasing portfolio risk',function()use($now){$b=broker();quotes($b,$now);buy($b,$now);quotes($b,$now+16000,100,100.2,'ASELS');rejected(fn()=>buy($b,$now+16000,'ASELS','stale-held-01'),'pozisyonun');});
test('ATR stop rejects excessive volatility',function()use($now){$b=broker();quotes($b,$now);rejected(fn()=>$b->handle('buy',['id'=>'atr-order-01','symbol'=>'THYAO','atr'=>10],$now),'ATR');});
test('ATR and fees included in position risk budget',function()use($now){
    $b=broker(['maxPositionPct'=>.9,'maxOrderTL'=>100000,'maxGrossExposure'=>.9]);quotes($b,$now);$s=$b->handle('buy',['id'=>'risk-sized-01','symbol'=>'THYAO','atr'=>1.5],$now);$p=((array)$s['positions'])['THYAO'];
    $risk=($p['cost']-$p['stop'])*$p['qty']+$p['entryFee']+$p['stop']*$p['qty']*(.0015+.0005);check($risk<=500.00001,'Risk budget exceeded');
});
test('max positions and total exposure enforced transactionally',function()use($now){
    $b=broker(['maxPositions'=>2]);foreach(['THYAO','ASELS','TUPRS']as$i=>$sym){quotes($b,$now,100,100.2,$sym);if($i<2)buy($b,$now,$sym,'multi-order-000'.$i);else rejected(fn()=>buy($b,$now,$sym,'multi-order-0002'),'pozisyon');}
});
test('demo and market accounts cannot mix prices or histories',function()use($now){$b=broker();rejected(fn()=>$b->handle('quotes',['source'=>'market','quotes'=>[]],$now),'karıştırılamaz');quotes($b,$now);buy($b,$now);rejected(fn()=>$b->handle('mode',['mode'=>'market'],$now),'geçmişi');});
test('market session and explicit holiday calendar block entries',function()use($now){
    $b=broker(['closedDates'=>['2026-10-27']]);$b->handle('mode',['mode'=>'market'],$now);$b->handle('quotes',['source'=>'market','quotes'=>[['symbol'=>'THYAO','bid'=>100,'ask'=>100.2,'bidAt'=>$now,'askAt'=>$now]]],$now);rejected(fn()=>buy($b,$now),'saatleri');
});
test('market entries require an explicit verified session',function()use($now){
    $b=broker(['marketSessions'=>['2026-10-27'=>['open'=>'10:05','close'=>'17:50']]]);$b->handle('mode',['mode'=>'market'],$now);
    $b->handle('quotes',['source'=>'market','quotes'=>[['symbol'=>'THYAO','bid'=>100,'ask'=>100.2,'bidAt'=>$now,'askAt'=>$now]]],$now);
    check(buy($b,$now)['fill']['qty']>0);
});
test('temporary stop crossing inside a batch cannot be hidden by rebound',function()use($now){
    $b=broker();quotes($b,$now);buy($b,$now);
    $s=$b->handle('quotes',['source'=>'demo','quotes'=>[
        ['symbol'=>'THYAO','bid'=>97,'bidAt'=>$now+1000],['symbol'=>'THYAO','bid'=>102,'bidAt'=>$now+1001]
    ]],$now+1001);
    check(count((array)$s['positions'])===0);check(end($s['trades'])['price']<98);
});
test('time exit commits even when subsequent buy is rejected',function()use($now){
    $b=broker(['maxHoldingHours'=>.0001]);quotes($b,$now);buy($b,$now);rejected(fn()=>buy($b,$now+1000,'THYAO','rejected-after-exit'),'bekleme');
    $s=$b->handle('state',[],$now+1000);check(count((array)$s['positions'])===0);check(end($s['trades'])['reason']==='TIME_EXIT');
});
test('corrupt ledger fails closed without erasing existing data',function()use($now){
    global $dirs;$b=broker();$b->handle('state',[],$now);$path=end($dirs).'/ledger.json';file_put_contents($path,'broken');
    try{$b->handle('state',[],$now);throw new RuntimeException('Silently reset');}catch(JsonException $e){}check(file_get_contents($path)==='broken');
});
foreach($dirs as $dir){foreach(glob($dir.'/*') as $file)unlink($file);rmdir($dir);}
echo "Broker tests: $passed passed, $failed failed\n";
exit($failed?1:0);
