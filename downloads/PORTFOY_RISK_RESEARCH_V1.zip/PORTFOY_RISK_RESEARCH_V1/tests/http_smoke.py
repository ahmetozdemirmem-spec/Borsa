"""Local functional tests; no exchange, credentials, external network or live orders."""
import concurrent.futures
import http.cookiejar
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import tempfile
import time
import unittest
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="portfoy-http-")
        self.addCleanup(self.tmp.cleanup)
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        self.base = f"http://127.0.0.1:{port}"
        self.err = open(Path(self.tmp.name) / "server.log", "w+")
        self.addCleanup(self.err.close)
        self.proc = subprocess.Popen(
            ["sh", str(ROOT / "scripts/php.sh"), "-S", f"127.0.0.1:{port}", "-t", str(ROOT / "public")],
            env={**os.environ, "PORTFOY_STATE_DIR": self.tmp.name + "/state"},
            stdout=self.err, stderr=self.err,
        )
        self.addCleanup(self.stop)
        self.client = urllib.request.build_opener(urllib.request.ProxyHandler({}), urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        for _ in range(100):
            if self.proc.poll() is not None:
                self.err.seek(0)
                self.fail(self.err.read())
            try:
                with self.client.open(self.base, timeout=1) as response:
                    self.html = response.read().decode()
                    self.headers = response.headers
                break
            except urllib.error.URLError:
                time.sleep(.05)
        else:
            self.fail("PHP server did not start")
        self.csrf = re.search(r'name="csrf-token" content="([a-f0-9]+)"', self.html)[1]

    def stop(self):
        if self.proc.poll() is None:
            self.proc.terminate()
        self.proc.wait(timeout=5)

    def api(self, action, body=None, csrf=True):
        headers = {"Content-Type": "application/json"}
        if csrf:
            headers["X-CSRF-Token"] = self.csrf
        request = urllib.request.Request(self.base + "/?api=" + action,
                                         data=None if body is None else json.dumps(body).encode(), headers=headers)
        try:
            with self.client.open(request, timeout=5) as r:
                return r.status, json.load(r)
        except urllib.error.HTTPError as e:
            return e.code, json.load(e)

    def quotes(self, bid=100, ask=100.2):
        now = int(time.time() * 1000)
        return self.api("quotes", {"source": "demo", "quotes": [
            {"symbol": "THYAO", "bid": bid, "ask": ask, "bidAt": now, "askAt": now}]})

    def test_page_assets_and_security_headers(self):
        self.assertIn("PAPER ONLY", self.html)
        self.assertIn("frame-ancestors 'none'", self.headers["Content-Security-Policy"])
        self.assertIn("HttpOnly", self.headers["Set-Cookie"])
        for path in ["strategy.js", "backtest.js", "app.js", "demo.js", "style.css"]:
            with self.client.open(self.base + "/assets/" + path) as r:
                self.assertEqual(r.status, 200)
                self.assertGreater(len(r.read()), 100)

    def test_state_is_paper_and_broker_credentials_not_exposed(self):
        status, state = self.api("state")
        self.assertEqual(status, 200)
        self.assertTrue(state["paperOnly"])
        self.assertEqual(state["positions"], {})
        self.assertEqual(state["cash"], 100000)
        self.assertNotIn("token", json.dumps(state).lower())

    def test_mutation_requires_post_and_csrf(self):
        self.assertEqual(self.api("kill")[0], 405)
        self.assertEqual(self.api("kill", {}, csrf=False)[0], 403)
        self.assertFalse(self.api("state")[1]["killed"])

    def test_paper_roundtrip_is_idempotent_and_persistent(self):
        self.assertEqual(self.quotes()[0], 200)
        order = {"id": "http-test-order-0001", "symbol": "THYAO", "dry_run": True}
        status, state = self.api("buy", order)
        self.assertEqual(status, 200)
        self.assertEqual(len(state["positions"]), 1)
        initial_cash = state["cash"]
        status, again = self.api("buy", order)
        self.assertEqual(status, 200)
        self.assertTrue(again["duplicate"])
        self.assertEqual(again["cash"], initial_cash)
        time.sleep(.005)
        self.assertEqual(self.quotes(bid=97, ask=97.1)[0], 200)
        status, state = self.api("state")
        self.assertEqual(status, 200)
        self.assertEqual(state["positions"], {})
        self.assertEqual(len(state["trades"]), 2)
        self.assertEqual(state["trades"][-1]["reason"], "HARD_STOP")
        self.assertLess(state["trades"][-1]["netPnl"], 0)
        self.stop()
        with open(Path(self.tmp.name) / "state/ledger.json") as f:
            self.assertEqual(len(json.load(f)["trades"]), 2)

    def test_live_route_and_live_flag_are_blocked(self):
        self.assertEqual(self.api("ziraat_order", {"dry_run": False})[0], 422)
        self.assertEqual(self.api("buy", {"id": "live-test-order", "symbol": "THYAO", "dry_run": False})[0], 422)
        self.assertEqual(self.api("state")[1]["trades"], [])

    def test_private_files_are_outside_webroot(self):
        for path in ["/var/ledger.json", "/config/risk.json", "/app/PaperBroker.php", "/data/ziraat_session.json", "/.env", "/../app/PaperBroker.php"]:
            with self.assertRaises(urllib.error.HTTPError) as error:
                self.client.open(self.base + path)
            self.assertIn(error.exception.code, [400, 404])

    def test_kill_blocks_new_entries_but_not_protective_exits(self):
        self.quotes()
        self.api("buy", {"id": "kill-buy-test-0001", "symbol": "THYAO"})
        self.assertTrue(self.api("kill", {})[1]["killed"])
        time.sleep(.005)
        self.quotes(bid=97, ask=97.1)
        state = self.api("state")[1]
        self.assertEqual(state["positions"], {})
        self.assertEqual(state["riskStatus"], "ACİL DURDURMA")

    def test_atomic_ledger_with_twelve_concurrent_clients(self):
        self.quotes()
        now = str(int(time.time() * 1000))
        command = ["sh", str(ROOT / "scripts/php.sh"), str(ROOT / "tests/concurrent_worker.php"), self.tmp.name + "/state", now]
        with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
            results = list(pool.map(lambda _: subprocess.run(command, capture_output=True, text=True, check=True), range(12)))
        receipts = [json.loads(r.stdout) for r in results]
        self.assertEqual(sum(not r["duplicate"] for r in receipts), 1)
        state = self.api("state")[1]
        self.assertEqual(len(state["trades"]), 1)
        self.assertEqual(len(state["positions"]), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
