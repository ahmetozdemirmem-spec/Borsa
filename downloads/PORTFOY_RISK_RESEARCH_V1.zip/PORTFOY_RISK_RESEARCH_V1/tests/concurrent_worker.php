<?php
declare(strict_types=1);
require __DIR__.'/../app/PaperBroker.php';
try {
    $result=(new PaperBroker($argv[1]))->handle('buy',['symbol'=>'THYAO','id'=>'concurrent-order-0001'],(int)$argv[2]);
    echo json_encode(['ok'=>true,'duplicate'=>$result['duplicate']]);
} catch (Throwable $e) { fwrite(STDERR,get_class($e).': '.$e->getMessage());exit(1); }
