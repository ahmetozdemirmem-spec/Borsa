'use strict';
const {chromium}=require('playwright');
const {spawn}=require('node:child_process');const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
(async()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'portfoy-browser-'));
  const port=19000+Math.floor(Math.random()*10000),base=`http://127.0.0.1:${port}`;
  const server=spawn('sh',[path.join(root,'scripts/php.sh'),'-S',`127.0.0.1:${port}`,'-t',path.join(root,'public')],{env:{...process.env,PORTFOY_STATE_DIR:tmp+'/state'},stdio:'ignore'});
  let browser;
  try{
    for(let i=0;i<100;i++){try{const r=await fetch(base);if(r.ok)break;}catch(e){}await new Promise(r=>setTimeout(r,50));}
    const executablePath=process.env.CHROMIUM_BIN||(fs.existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined);
    browser=await chromium.launch({headless:true,executablePath});const page=await browser.newPage({viewport:{width:1440,height:1000}});
    const errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('dialog',dialog=>dialog.accept());
    await page.goto(base);await page.waitForFunction(()=>document.querySelector('#equity').textContent.includes('TL'));
    assert.equal(await page.locator('#autoBuy').isChecked(),false);
    await page.locator('#sample').click();await page.waitForFunction(()=>document.querySelector('#testResult').textContent.includes('SENTETİK ÖRNEK'));
    assert.ok(await page.locator('#curve polyline').count());
    await page.locator('#start').click();await page.waitForFunction(()=>document.querySelectorAll('#scanRows tr').length===3&&document.querySelector('#scanRows button:not(:disabled)'));
    await page.locator('#scanRows button').first().click();await page.waitForFunction(()=>document.querySelectorAll('#positionRows tr').length===1);
    await page.locator('#kill').click();await page.waitForFunction(()=>document.querySelector('#risk').textContent==='ACİL DURDURMA');
    assert.equal(await page.locator('#scanRows button:not(:disabled)').count(),0);
    await page.locator('#positionRows button').first().click();await page.waitForFunction(()=>document.querySelectorAll('#positionRows tr').length===0&&document.querySelectorAll('#soldRows tr').length===1);
    await page.reload();await page.waitForFunction(()=>document.querySelectorAll('#soldRows tr').length===1);
    assert.equal(await page.locator('#autoBuy').isChecked(),false);assert.equal(await page.locator('#risk').textContent(),'ACİL DURDURMA');
    await page.locator('#sample').click();await page.waitForFunction(()=>document.querySelector('#testResult').textContent.includes('SENTETİK ÖRNEK'));
    fs.mkdirSync(path.join(root,'artifacts'),{recursive:true});await page.screenshot({path:path.join(root,'artifacts/dashboard.png'),fullPage:true});
    await page.setViewportSize({width:390,height:844});
    assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+2),'Mobile page must not overflow horizontally');
    assert.deepEqual(errors,[]);console.log('Browser smoke PASS: demo feed, paper buy/sell, kill, persistence, backtest chart, mobile layout, no JS errors.');
  }finally{if(browser)await browser.close();server.kill();await new Promise(resolve=>{if(server.exitCode!==null)return resolve();server.once('exit',resolve);});fs.rmSync(tmp,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
