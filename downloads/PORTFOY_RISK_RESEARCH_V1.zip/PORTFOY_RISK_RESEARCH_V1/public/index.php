<?php
declare(strict_types=1);
$requestPath=parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH);
if (!in_array($requestPath,['/','/index.php'],true)) { http_response_code(404);header('Content-Type: text/plain; charset=utf-8');echo 'Bulunamadı.';exit; }
require __DIR__.'/../app/PaperBroker.php';
$stateDir=getenv('PORTFOY_STATE_DIR')?:__DIR__.'/../var';
if (!is_dir($stateDir)) mkdir($stateDir,0700,true);
if (!is_dir($stateDir.'/sessions')) mkdir($stateDir.'/sessions',0700,true);
session_save_path($stateDir.'/sessions');
session_name('portfoy');
session_set_cookie_params(['httponly'=>true,'samesite'=>'Strict','secure'=>isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off']);
session_start();
$_SESSION['csrf']??=bin2hex(random_bytes(32));
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self' wss://markets.fintables.com; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
if (isset($_GET['api'])) {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $action=(string)$_GET['api'];
        if ($action!=='state' && $_SERVER['REQUEST_METHOD']!=='POST') { http_response_code(405);throw new DomainException('POST gerekli.'); }
        if ($action!=='state' && !hash_equals($_SESSION['csrf'],$_SERVER['HTTP_X_CSRF_TOKEN']??'')) { http_response_code(403);throw new DomainException('Oturum doğrulaması başarısız; sayfayı yenileyin.'); }
        session_write_close();
        if ((int)($_SERVER['CONTENT_LENGTH']??0)>262144) { http_response_code(413);throw new DomainException('İstek çok büyük.'); }
        $raw=file_get_contents('php://input',false,null,0,262145);
        if (strlen($raw)>262144) { http_response_code(413);throw new DomainException('İstek çok büyük.'); }
        $body=$raw!==''?json_decode($raw,true,32,JSON_THROW_ON_ERROR):[];
        if (!is_array($body)) throw new DomainException('JSON nesnesi gerekli.');
        $result=(new PaperBroker($stateDir))->handle($action,$body);
        echo json_encode($result,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE);
    } catch (DomainException|JsonException $e) {
        if (http_response_code()<400) http_response_code(422);
        echo json_encode(['ok'=>false,'error'=>$e->getMessage()],JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        http_response_code(500);error_log('PORTFOY ledger error: '.get_class($e));
        echo json_encode(['ok'=>false,'error'=>'Kayıt okunamadı/yazılamadı. İşlem durduruldu; sunucu kaydını kontrol edin.'],JSON_UNESCAPED_UNICODE);
    }
    exit;
}
$csrf=htmlspecialchars($_SESSION['csrf'],ENT_QUOTES,'UTF-8');
session_write_close();
require __DIR__.'/../app/view.php';
