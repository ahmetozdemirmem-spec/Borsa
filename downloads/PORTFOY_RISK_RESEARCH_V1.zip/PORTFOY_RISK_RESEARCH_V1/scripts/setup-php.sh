#!/bin/sh
# User-space Debian installation: signed repository metadata + APT SHA256 validation.
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
if command -v php >/dev/null 2>&1 && php -r 'exit(PHP_VERSION_ID >= 80200 ? 0 : 1);'; then
  php -v
  exit 0
fi
if [ -x .tools/php/usr/bin/php8.4 ]; then
  LD_LIBRARY_PATH="$PWD/.tools/php/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" .tools/php/usr/bin/php8.4 -n -v
  exit 0
fi
if [ "$(uname -m)" != x86_64 ] || [ ! -r /usr/share/keyrings/debian-archive-keyring.gpg ]; then
  echo 'PHP >=8.2 CLI kurun. Bu yardımcı yalnız Debian x86_64 içindir.' >&2
  exit 1
fi
. /etc/os-release
if [ "${ID:-}" != debian ] || [ "${VERSION_CODENAME:-}" != trixie ]; then
  echo 'Bu yardımcı Debian 13 içindir. Dağıtımınıza uygun PHP >=8.2 CLI kurun.' >&2
  exit 1
fi
aptroot="$PWD/.tools/apt"
mkdir -p "$aptroot/lists/partial" "$aptroot/cache/archives/partial" "$aptroot/parts" "$aptroot/packages" .tools/php
cat > "$aptroot/sources.list" <<'EOF'
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie main
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://security.debian.org/debian-security trixie-security main
EOF
apt_user() {
  /usr/bin/apt-get -o "Dir::Etc::parts=$aptroot/parts" -o "Dir::Etc::sourcelist=$aptroot/sources.list" -o Dir::Etc::sourceparts=- -o "Dir::State::lists=$aptroot/lists" -o "Dir::Cache=$aptroot/cache" "$@"
}
apt_user update
cd "$aptroot/packages"
apt_user download php8.4-cli php8.4-common libargon2-1 libsodium23
cd ../../..
for package in "$aptroot/packages/"*.deb; do dpkg-deb -x "$package" .tools/php; done
LD_LIBRARY_PATH="$PWD/.tools/php/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" .tools/php/usr/bin/php8.4 -n -v
