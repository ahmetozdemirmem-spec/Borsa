#!/usr/bin/env node
'use strict';
const fs=require('node:fs');
const P=require('../public/assets/strategy.js');
const B=require('../public/assets/backtest.js');
const demo=require('../public/assets/demo.js');
try{
  const file=process.argv[2];
  if(!file)throw new Error('Kullanım: node scripts/backtest.cjs veri.csv [rapor.json] veya --demo');
  const bars=file==='--demo'?demo.bars(720):P.parseCsv(fs.readFileSync(file,'utf8'));
  const config=JSON.parse(fs.readFileSync(require('node:path').join(__dirname,'../config/risk.json'),'utf8'));
  const result=B.run(bars,config);
  let walkForward;try{walkForward=B.walkForward(bars,config);}catch(e){walkForward={error:e.message};}
  const report={synthetic:file==='--demo',createdAt:new Date().toISOString(),result,walkForward};
  if(process.argv[3])fs.writeFileSync(process.argv[3],JSON.stringify(report,null,2));
  console.log(JSON.stringify({synthetic:report.synthetic,bars:result.bars,tradeCount:result.tradeCount,netReturnPct:result.netReturnPct,maxDrawdownPct:result.maxDrawdownPct,warnings:result.warnings,walkForward:walkForward.folds?.map(f=>({tradeCount:f.tradeCount,netReturnPct:f.netReturnPct,maxDrawdownPct:f.maxDrawdownPct}))||walkForward},null,2));
}catch(e){console.error(e.message);process.exitCode=1;}
