#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
exec sh scripts/php.sh -S "127.0.0.1:${PORT:-8080}" -t public
