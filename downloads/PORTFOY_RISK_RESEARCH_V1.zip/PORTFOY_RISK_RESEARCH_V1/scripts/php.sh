#!/bin/sh
set -eu
project="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
if [ -n "${PHP_BIN:-}" ]; then exec "$PHP_BIN" "$@"; fi
if [ -x "$project/.tools/php/usr/bin/php8.4" ]; then
  export LD_LIBRARY_PATH="$project/.tools/php/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
  exec "$project/.tools/php/usr/bin/php8.4" -n "$@"
fi
exec php "$@"
