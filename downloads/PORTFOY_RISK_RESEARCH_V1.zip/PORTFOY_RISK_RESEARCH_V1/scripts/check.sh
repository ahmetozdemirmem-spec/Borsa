#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
for file in app/*.php public/*.php tests/*.php; do sh scripts/php.sh -l "$file"; done
node tests/strategy.test.cjs
sh scripts/php.sh tests/broker.php
python3 tests/http_smoke.py
