<?php
declare(strict_types=1);

/** Paper ledger only. This class has no transport capable of placing live orders. */
final class PaperBroker
{
    private array $config;

    public function __construct(private string $directory, ?array $config = null)
    {
        $this->config = $config ?? json_decode(file_get_contents(__DIR__.'/../config/risk.json'), true, 512, JSON_THROW_ON_ERROR);
        foreach (['initialCapital','commissionRate','slippageRate','riskPerTrade','maxPortfolioRisk','maxPositionPct','maxGrossExposure','cashReservePct','maxOrderTL','maxPositions','hardStopPct','maxStopPct','atrStopMultiple','trailActivationPct','trailDistancePct','maxHoldingHours','maxDailyLossPct','maxDrawdownPct','maxConsecutiveLosses','lossPauseMinutes','cooldownMinutes','quoteMaxAgeMs','maxSpreadPct'] as $key) {
            if (!isset($this->config[$key]) || !is_numeric($this->config[$key]) || !is_finite((float)$this->config[$key]) || $this->config[$key] <= 0) {
                throw new RuntimeException('Geçersiz risk ayarı: '.$key);
            }
        }
        foreach (['commissionRate','slippageRate','riskPerTrade','maxPortfolioRisk','maxPositionPct','maxGrossExposure','cashReservePct','hardStopPct','maxStopPct','trailActivationPct','trailDistancePct','maxDailyLossPct','maxDrawdownPct','maxSpreadPct'] as $key) {
            if ($this->config[$key] >= 1) throw new RuntimeException('Risk oranı 0..1 aralığında olmalı: '.$key);
        }
        if ($this->config['maxStopPct'] < $this->config['hardStopPct']) throw new RuntimeException('Stop aralığı geçersiz.');
        if (!is_dir($directory) && !mkdir($directory, 0700, true)) throw new RuntimeException('Kayıt dizini oluşturulamadı.');
    }

    private function freshAccount(int $now): array
    {
        return ['version'=>1,'initialCapital'=>$this->config['initialCapital'],'mode'=>'demo','cash'=>$this->config['initialCapital'],'positions'=>[], 'trades'=>[],
            'quotes'=>[],'receipts'=>[],'cooldowns'=>[],'killed'=>false,'peakEquity'=>$this->config['initialCapital'],
            'dayStartEquity'=>$this->config['initialCapital'],'day'=>$this->day($now),'dailyBlocked'=>false,
            'drawdownBlocked'=>false,'lossStreak'=>0,'pauseUntil'=>0,'createdAt'=>$now];
    }

    private function day(int $now): string { return (new DateTimeImmutable('@'.intdiv($now,1000)))->setTimezone(new DateTimeZone('Europe/Istanbul'))->format('Y-m-d'); }
    private function symbol(mixed $raw): string
    {
        if (!is_string($raw) || !preg_match('/^[A-Z0-9][A-Z0-9._-]{1,11}$/D', $raw)) throw new DomainException('Geçersiz sembol.');
        return $raw;
    }
    private function number(mixed $value): float
    {
        if ((!is_int($value) && !is_float($value)) || !is_finite((float)$value) || $value <= 0 || $value > 1e12) throw new DomainException('Geçersiz sayısal değer.');
        return (float)$value;
    }
    private function equity(array $s): float
    {
        $v=$s['cash'];
        foreach ($s['positions'] as $p) $v += $p['last']*$p['qty']*(1-$this->config['slippageRate'])*(1-$this->config['commissionRate']);
        return $v;
    }
    private function sessionOpen(int $now): bool
    {
        $d=(new DateTimeImmutable('@'.intdiv($now,1000)))->setTimezone(new DateTimeZone('Europe/Istanbul'));
        // Missing exchange holiday/half-day confirmation is not evidence of an open session.
        $session=$this->config['marketSessions'][$d->format('Y-m-d')]??null;
        if (!is_array($session) || !isset($session['open'],$session['close']) ||
            !preg_match('/^\d{2}:\d{2}$/D',$session['open']) || !preg_match('/^\d{2}:\d{2}$/D',$session['close'])) return false;
        return (int)$d->format('N')<=5 && !in_array($d->format('Y-m-d'), $this->config['closedDates'], true)
            && $d->format('H:i') >= max($this->config['sessionStart'],$session['open'])
            && $d->format('H:i') < min($this->config['sessionEnd'],$session['close']);
    }
    private function updateLimits(array &$s, int $now): void
    {
        $e=$this->equity($s);
        $s['peakEquity']=max($s['peakEquity'],$e);
        if ($e <= $s['dayStartEquity']*(1-$this->config['maxDailyLossPct'])) $s['dailyBlocked']=true;
        if ($e <= $s['peakEquity']*(1-$this->config['maxDrawdownPct'])) $s['drawdownBlocked']=true;
    }
    private function quoteFresh(array $q, string $field, int $now): bool
    {
        return isset($q[$field],$q[$field.'At']) && $q[$field]>0 && $now-$q[$field.'At'] >= 0 && $now-$q[$field.'At'] <= $this->config['quoteMaxAgeMs'];
    }
    private function close(array &$s, string $symbol, int $now, string $reason, string $id): array
    {
        if (!isset($s['positions'][$symbol])) throw new DomainException('Açık pozisyon yok.');
        $q=$s['quotes'][$symbol]??[];
        if (!$this->quoteFresh($q,'bid',$now)) throw new DomainException('Güncel Bid yok; maliyet fiyatıyla satış yapılmaz.');
        $p=$s['positions'][$symbol];
        $price=$q['bid']*(1-$this->config['slippageRate']);
        $fee=$price*$p['qty']*$this->config['commissionRate'];
        $proceeds=$price*$p['qty']-$fee;
        $net=$proceeds-($p['cost']*$p['qty']+$p['entryFee']);
        $s['cash']+=$proceeds;
        $fill=['id'=>$id,'side'=>'S','symbol'=>$symbol,'qty'=>$p['qty'],'price'=>$price,'fee'=>$fee,'entryFee'=>$p['entryFee'],
            'buy'=>$p['cost'],'netPnl'=>$net,'pnlPct'=>$net/($p['cost']*$p['qty']+$p['entryFee'])*100,
            'buyTime'=>$p['openedAt'],'time'=>$now,'reason'=>$reason,'mode'=>$s['mode']];
        $s['trades'][]=$fill;
        unset($s['positions'][$symbol]);
        $s['cooldowns'][$symbol]=$now+(int)($this->config['cooldownMinutes']*60000);
        $s['lossStreak']=$net<0 ? $s['lossStreak']+1 : 0;
        if ($s['lossStreak'] >= $this->config['maxConsecutiveLosses']) {
            $s['pauseUntil']=$now+(int)($this->config['lossPauseMinutes']*60000);
            $s['lossStreak']=0;
        }
        $this->updateLimits($s,$now);
        return $fill;
    }
    private function protectPositions(array &$s, int $now): void
    {
        foreach (array_keys($s['positions']) as $symbol) {
            $q=$s['quotes'][$symbol]??[];
            if (!$this->quoteFresh($q,'bid',$now)) continue;
            $p=&$s['positions'][$symbol];
            $p['last']=$q['bid'];
            $p['lastAt']=$q['bidAt'];
            $reason=null;
            // Test the existing stop BEFORE moving the peak. Stops never loosen.
            if ($q['bid'] <= $p['stop']) $reason=$p['armed']?'TRAILING_STOP':'HARD_STOP';
            elseif ($now-$p['openedAt'] >= $this->config['maxHoldingHours']*3600000) $reason='TIME_EXIT';
            if ($reason!==null) {
                unset($p);
                $this->close($s,$symbol,$now,$reason,'exit:'.$symbol.':'.$now);
                continue;
            }
            $p['peak']=max($p['peak'],$q['bid']);
            if ($p['peak'] >= $p['cost']*(1+$this->config['trailActivationPct'])) $p['armed']=true;
            if ($p['armed']) {
                $breakEven=$p['cost']*(1+$this->config['commissionRate'])/((1-$this->config['slippageRate'])*(1-$this->config['commissionRate']));
                $p['stop']=max($p['stop'],$p['peak']*(1-$this->config['trailDistancePct']),$breakEven);
            }
            unset($p);
        }
        $this->updateLimits($s,$now);
    }
    private function buy(array &$s, array $in, int $now, string $id): array
    {
        if ($s['killed'] || $s['dailyBlocked'] || $s['drawdownBlocked'] || $now<$s['pauseUntil']) throw new DomainException('Risk devre kesici: yeni AL işlemleri kapalı.');
        if ($s['mode']==='market' && !$this->sessionOpen($now)) throw new DomainException('Doğrulanmış BIST takvimi yok veya işlem saatleri dışında; AL kapalı.');
        $symbol=$this->symbol($in['symbol']??null);
        if (isset($s['positions'][$symbol])) throw new DomainException('Aynı sembolde ikinci pozisyon açılamaz.');
        if (($s['cooldowns'][$symbol]??0)>$now) throw new DomainException('Satış sonrası bekleme süresi dolmadı.');
        if (count($s['positions']) >= $this->config['maxPositions']) throw new DomainException('Azami pozisyon sayısı.');
        $q=$s['quotes'][$symbol]??[];
        if (!$this->quoteFresh($q,'bid',$now) || !$this->quoteFresh($q,'ask',$now)) throw new DomainException('Güncel çift taraflı fiyat gerekli.');
        if ($q['ask']<$q['bid'] || ($q['ask']-$q['bid'])/$q['bid']>$this->config['maxSpreadPct']) throw new DomainException('Spread sınırı aşıldı veya fiyatlar ters.');
        foreach ($s['positions'] as $sym=>$p) {
            if (!$this->quoteFresh($s['quotes'][$sym]??[],'bid',$now)) throw new DomainException('Mevcut pozisyonun fiyatı eski; yeni AL kapalı.');
        }
        $e=$this->equity($s);
        $price=$q['ask']*(1+$this->config['slippageRate']);
        $stopPct=$this->config['hardStopPct'];
        if (isset($in['atr'])) $stopPct=max($stopPct,$this->number($in['atr'])*$this->config['atrStopMultiple']/$price);
        if ($stopPct>$this->config['maxStopPct']) throw new DomainException('ATR çok yüksek; stop mesafesi risk aralığını aşıyor.');
        $unitRisk=$price*$stopPct + $price*$this->config['commissionRate'] + $price*(1-$stopPct)*($this->config['commissionRate']+$this->config['slippageRate']);
        $gross=0;$openRisk=0;
        foreach ($s['positions'] as $p) { $gross+=$p['last']*$p['qty']; $openRisk+=max(0,($p['cost']-$p['stop'])*$p['qty']+$p['entryFee']+$p['stop']*$p['qty']*($this->config['commissionRate']+$this->config['slippageRate'])); }
        $maxBudget=min($this->config['maxOrderTL'],$e*$this->config['maxPositionPct'],max(0,$e*$this->config['maxGrossExposure']-$gross),max(0,($s['cash']-$e*$this->config['cashReservePct'])/(1+$this->config['commissionRate'])));
        $riskBudget=max(0,min($e*$this->config['riskPerTrade'],$e*$this->config['maxPortfolioRisk']-$openRisk));
        $qty=(int)floor(min($riskBudget/$unitRisk,$maxBudget/$price));
        if ($qty<1) throw new DomainException('Risk/nakit limiti en az bir lota yetmiyor.');
        $fee=$price*$qty*$this->config['commissionRate'];
        $s['cash']-=$price*$qty+$fee;
        $s['positions'][$symbol]=['symbol'=>$symbol,'qty'=>$qty,'cost'=>$price,'last'=>$q['bid'],'lastAt'=>$q['bidAt'],'entryFee'=>$fee,'openedAt'=>$now,
            'stop'=>$price*(1-$stopPct),'initialStop'=>$price*(1-$stopPct),'peak'=>$q['bid'],'armed'=>false,'reason'=>substr((string)($in['reason']??'MANUAL'),0,120)];
        $fill=['id'=>$id,'side'=>'B','symbol'=>$symbol,'qty'=>$qty,'price'=>$price,'fee'=>$fee,'time'=>$now,'mode'=>$s['mode']];
        $s['trades'][]=$fill;
        $this->updateLimits($s,$now);
        return $fill;
    }
    private function snapshot(array $s, int $now): array
    {
        $e=$this->equity($s);
        $closed=array_filter($s['trades'],fn($t)=>$t['side']==='S');
        $realized=array_sum(array_column($closed,'netPnl'));
        $sessionBlocked=$s['mode']==='market'&&!$this->sessionOpen($now);
        $reason=$s['killed']?'ACİL DURDURMA':($s['drawdownBlocked']?'AZAMİ DÜŞÜŞ':($s['dailyBlocked']?'GÜNLÜK KAYIP':($s['pauseUntil']>$now?'ARDIŞIK KAYIP BEKLEMESİ':($sessionBlocked?'TAKVİM / SEANS KAPALI':'AL AÇIK'))));
        return ['ok'=>true,'paperOnly'=>true,'mode'=>$s['mode'],'cash'=>$s['cash'],'equity'=>$e,'positions'=>(object)$s['positions'],
            'trades'=>$s['trades'],'realizedPnl'=>$realized,'netPnl'=>$e-$this->config['initialCapital'],
            'drawdownPct'=>max(0,1-$e/$s['peakEquity'])*100,'dailyPnl'=>$e-$s['dayStartEquity'],'riskStatus'=>$reason,
            'entriesBlocked'=>$s['killed']||$s['dailyBlocked']||$s['drawdownBlocked']||$now<$s['pauseUntil']||$sessionBlocked,
            'killed'=>$s['killed'],'config'=>$this->config,'serverTime'=>$now];
    }

    /** Lock includes read, risk evaluation and atomic commit. Duplicate IDs cannot fill twice. */
    public function handle(string $action, array $in=[], ?int $clock=null): array
    {
        $now=$clock??(int)floor(microtime(true)*1000);
        $lock=fopen($this->directory.'/ledger.lock','c');
        if (!$lock || !flock($lock,LOCK_EX)) throw new RuntimeException('Kayıt kilitlenemedi.');
        $path=$this->directory.'/ledger.json';
        try {
            $s=is_file($path)?json_decode(file_get_contents($path),true,512,JSON_THROW_ON_ERROR):$this->freshAccount($now);
            if (($s['initialCapital']??null)!=$this->config['initialCapital']) throw new RuntimeException('Başlangıç sermayesi değiştirilmiş; ayrı kayıt dizini gerekli.');
            if (($in['dry_run']??true)!==true) throw new DomainException('Bu sürüm canlı emir göndermez.');
            if ($this->day($now)!==$s['day']) {
                $s['day']=$this->day($now);$s['dayStartEquity']=$this->equity($s);$s['dailyBlocked']=false;
            }
            $fill=null;$failure=null;
            if (in_array($action,['buy','sell'],true)) {
                $id=$in['id']??null;
                if (!is_string($id) || !preg_match('/^[A-Za-z0-9:_-]{8,100}$/D',$id)) throw new DomainException('Geçerli idempotency kimliği gerekli.');
                $fingerprint=hash('sha256',json_encode([$action,$in['symbol']??null,$in['atr']??null,$in['reason']??null]));
                if (isset($s['receipts'][$id])) {
                    $r=$s['receipts'][$id];
                    if ($r['fingerprint']!==$fingerprint) throw new DomainException('Kimlik farklı bir emir için kullanılmış.');
                    return $this->snapshot($s,$now)+['fill'=>$r['fill'],'duplicate'=>true];
                }
            }
            if ($action==='quotes') {
                $rows=$in['quotes']??null;
                if (!is_array($rows) || count($rows)>250) throw new DomainException('En fazla 250 fiyat kaydı gerekli.');
                if (($in['source']??null)!==$s['mode']) throw new DomainException('Demo ve piyasa fiyatları aynı hesapta karıştırılamaz.');
                foreach ($rows as $row) {
                    if (!is_array($row)) throw new DomainException('Geçersiz fiyat kaydı.');
                    $symbol=$this->symbol($row['symbol']??null);
                    foreach (['bid','ask'] as $field) {
                        if (!array_key_exists($field,$row)) continue;
                        $v=$this->number($row[$field]);$ts=$row[$field.'At']??null;
                        if (!is_int($ts) || $ts>$now+2000 || $ts<$now-$this->config['quoteMaxAgeMs']) throw new DomainException('Eski veya gelecek zamanlı fiyat.');
                        if ($ts<($s['quotes'][$symbol][$field.'At']??0)) continue;
                        $s['quotes'][$symbol][$field]=$v;$s['quotes'][$symbol][$field.'At']=min($ts,$now);
                    }
                    $this->protectPositions($s,$now);
                }
            } elseif ($action==='buy' || $action==='sell') {
                $this->protectPositions($s,$now);
                try {
                    $fill=$action==='buy'?$this->buy($s,$in,$now,$id):$this->close($s,$this->symbol($in['symbol']??null),$now,substr((string)($in['reason']??'MANUAL'),0,120),$id);
                    $s['receipts'][$id]=['fingerprint'=>$fingerprint,'fill'=>$fill];
                } catch (DomainException $e) {
                    // A rejected entry/manual sell must not roll back protective exits.
                    $failure=$e;
                }
            } elseif ($action==='kill') {
                $s['killed']=true; // Stops and manual exits remain operational.
            } elseif ($action==='resume') {
                $s['killed']=false; // Daily/drawdown latches cannot be bypassed here.
            } elseif ($action==='mode') {
                if (count($s['trades']) || count($s['positions'])) throw new DomainException('İşlem geçmişi olan hesabın veri modu değiştirilemez. Ayrı PORTFOY_STATE_DIR kullanın.');
                if (!in_array($in['mode']??null,['demo','market'],true)) throw new DomainException('Geçersiz mod.');
                $s['mode']=$in['mode'];$s['quotes']=[];
            } elseif ($action!=='state') throw new DomainException('Geçersiz işlem.');
            $this->updateLimits($s,$now);
            $tmp=tempnam($this->directory,'ledger-');
            try {
                if (file_put_contents($tmp,json_encode($s,JSON_THROW_ON_ERROR|JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE))===false || !chmod($tmp,0600) || !rename($tmp,$path)) throw new RuntimeException('Kayıt yazılamadı.');
            } finally { if (is_file($tmp)) unlink($tmp); }
            if ($failure!==null) throw $failure;
            return $this->snapshot($s,$now)+['fill'=>$fill,'duplicate'=>false];
        } finally { flock($lock,LOCK_UN);fclose($lock); }
    }
}
