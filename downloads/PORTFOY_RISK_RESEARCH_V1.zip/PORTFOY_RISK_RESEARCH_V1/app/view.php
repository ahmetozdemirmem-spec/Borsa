<!doctype html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="csrf-token" content="<?= $csrf ?>">
  <title>PORTFOY · Risk Kontrollü Araştırma Botu</title>
  <link rel="stylesheet" href="/assets/style.css">
  <script defer src="/assets/strategy.js"></script>
  <script defer src="/assets/backtest.js"></script>
  <script defer src="/assets/demo.js"></script>
  <script defer src="/assets/app.js"></script>
</head>
<body><div class="wrap">
  <header class="topbar">
    <div><h1>PORTFOY <span class="badge">PAPER ONLY</span></h1><p class="muted">BIST · RSI toparlanma + trend + ATR · Risk kontrollü araştırma</p></div>
    <div class="top-actions"><button id="refresh">Portföyü Yenile</button><button id="export">İşlem Kaydı İndir</button><button class="danger" id="kill">ACİL DURDUR</button><button id="resume">Alımları Sürdür</button></div>
  </header>
  <div class="notice">Gerçek emir gönderilmez. Getiri ve zarar durdurma fiyatı garanti değildir. Sayfa kapalıyken tarayıcı stratejisi ve fiyat takibi durur; bu sürüm canlı işlem için uygun değildir.</div>
  <div class="metrics">
    <div class="stat">Net Varlık <b id="equity">—</b><small>tahmini çıkış maliyeti sonrası</small></div>
    <div class="stat">Nakit <b id="cash">—</b></div>
    <div class="stat">Net Kâr/Zarar <b id="net">—</b></div>
    <div class="stat">Günlük Kâr/Zarar <b id="daily">—</b></div>
    <div class="stat">Zirveden Düşüş <b id="dd">—</b></div>
    <div class="stat">Risk Durumu <b id="risk">—</b></div>
  </div>
  <main class="grid">
    <aside>
      <section class="panel"><div class="hd">Kontrol Paneli</div><div class="bd">
        <div class="field"><label for="mode">Fiyat Kaynağı (hesap geçmişi sonrası değişmez)</label><select id="mode"><option value="demo">SENTETİK DEMO · gerçek piyasa değildir</option><option value="market">Fintables · sadece paper işlem</option></select></div>
        <div class="field"><label for="symbols">Takip Listesi</label><input id="symbols" value="THYAO,ASELS,TUPRS" maxlength="1000"><small>Virgülle ayırın. Eski DNA listesi otomatik kullanılmaz.</small></div>
        <div class="field"><label for="feedToken">Fintables WebSocket Anahtarı</label><input id="feedToken" type="password" autocomplete="off"><small>Yalnız bu sekmenin belleğinde tutulur. Anahtarı paylaşmayın.</small></div>
        <div class="btnrow section"><button class="primary" id="start">Fiyat Akışını Başlat</button><button id="stop">Akışı Durdur</button></div>
        <p id="feedStatus" role="status" class="muted">Akış kapalı. Otomasyon varsayılan kapalı.</p>
        <p class="tiny muted">Piyasa paper AL işlemleri için risk.json içindeki marketSessions alanına doğrulanmış BIST tam/yarım gün takvimi girilmelidir. Takvim yoksa alımlar kapalıdır.</p>
        <div class="field"><label for="rsiRecovery">RSI(14) toparlanma eşiği</label><input id="rsiRecovery" type="number" value="30" min="1" max="99"></div>
        <label class="check"><input id="autoBuy" type="checkbox"> Kapanmış mum sinyalinde Oto-AL</label>
        <p class="tiny muted">RSI aşağıda diye AL yapılmaz: eşiği yukarı kesme, yükselen EMA50, uygun ATR ve eksiksiz 60 mum gerekir. Zarar durdurma ve trailing, akış açıkken sunucuda her zaman değerlendirilir.</p>
        <div id="riskConfig" class="risk-config"></div>
      </div></section>
      <section class="panel"><div class="hd">İşlem ve Risk Günlüğü</div><pre id="log" role="log" class="log"></pre></section>
    </aside>
    <div class="tables">
      <section class="panel"><div class="hd">Tarama <span id="universe" class="muted tiny"></span></div><div class="bd scroll"><table><thead><tr><th>Sembol</th><th>Ask</th><th>Bid</th><th>Spread%</th><th>RSI14</th><th>Sinyal</th><th>İşlem</th><th>Zaman</th></tr></thead><tbody id="scanRows"></tbody></table></div></section>
      <section class="panel"><div class="hd">Alınanlar <span id="positionCount"></span></div><div class="bd scroll"><table><thead><tr><th>Sembol</th><th>Adet</th><th>Maliyet</th><th>Bid</th><th>Net K/Z*</th><th>Stop</th><th>Durum</th><th>İşlem</th><th>Zaman</th></tr></thead><tbody id="positionRows"></tbody></table><small>* Tahmini satış komisyonu ve kayma dahil. Stop boşluklu piyasada daha kötü fiyattan gerçekleşebilir.</small></div></section>
      <section class="panel"><div class="hd">Satılanlar</div><div class="bd scroll"><table><thead><tr><th>Sembol</th><th>Adet</th><th>Alış</th><th>Satış</th><th>Komisyon</th><th>Net K/Z</th><th>Neden</th><th>Alış Zamanı</th><th>Satış Zamanı</th></tr></thead><tbody id="soldRows"></tbody></table></div></section>
      <section class="panel"><div class="hd">Geçmiş Veri Testi · Araştırma</div><div class="bd">
        <p>15 dakikalık <strong>Ask OHLC</strong> CSV yükleyin. Son mumda oluşan sinyal, sonraki mumun açılışında işleme girer. Tek hisse; spread modeli, iki yön komisyon ve kayma dahil.</p>
        <div class="formgrid">
          <div class="field"><label for="csv">CSV (en fazla 8 MB)</label><input id="csv" type="file" accept=".csv,text/csv"></div>
          <div class="field"><label for="spread">Spread varsayımı %</label><input id="spread" type="number" value="0.20" min="0.001" max="5" step="0.01"></div>
        </div>
        <div class="btnrow section"><button id="backtest" class="primary">Test + 3 Dönem Kontrolü</button><button id="sample">Sentetik Örnekle Test Et</button><button id="downloadReport" disabled>Rapor İndir</button></div>
        <p class="tiny muted">Başlık: timestamp,open,high,low,close,volume. Zaman ISO UTC/offset veya milisaniye. Volume isteğe bağlı. Fiyat bölünmeleri/temettüler doğru düzeltilmeli. Walk-forward sabit parametrelerle ayrı dönemleri ölçer; optimizasyon veya başarı kanıtı değildir.</p>
        <div id="testResult" role="status">Henüz test çalıştırılmadı.</div>
        <svg id="curve" viewBox="0 0 800 160" role="img" aria-label="Test özsermaye eğrisi"></svg>
      </div></section>
    </div>
  </main>
  <footer>Zipteki PORTFOY ekran ve strateji yaklaşımından geliştirilmiştir. Canlı Ziraat entegrasyonu: emir/gerçekleşme mutabakatı ve aracı kurum doğrulaması tamamlanana kadar kapalı. Risk ayarları örnek başlangıç değerleridir.</footer>
</div></body></html>
