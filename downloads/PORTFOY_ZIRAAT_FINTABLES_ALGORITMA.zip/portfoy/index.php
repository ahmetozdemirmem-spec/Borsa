<?php
header('Content-Type: text/html; charset=utf-8');
date_default_timezone_set('Europe/Istanbul');
require_once __DIR__.'/baslangic.php';

$settingsFile = PORTFOY_DATA_DIR . '/ayarlar.json';
$logsDir = PORTFOY_DATA_DIR . '/logs';
$soldDir = PORTFOY_DATA_DIR . '/sold';
$holdingsDir = PORTFOY_DATA_DIR . '/holdings';
require_once __DIR__ . '/core/ziraat_no_extension_core.php';

function json_response($arr): void {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($arr, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

if (isset($_GET['logs']) && $_GET['logs'] === 'save') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['ok'=>false,'error'=>'POST gerekli']);
    $json = json_decode(file_get_contents('php://input') ?: '', true);
    if (!is_array($json)) json_response(['ok'=>false,'error'=>'Geçersiz JSON']);
    @is_dir($logsDir) || @mkdir($logsDir, 0777, true);
    $date = date('Y-m-d');
    $file = $logsDir . '/' . $date . '.json';
    $payload = ['date'=>$date,'saved_at'=>date('Y-m-d H:i:s'),'logs'=>array_values($json['logs'] ?? [])];
    $ok = @file_put_contents($file, json_encode($payload, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
    json_response($ok === false ? ['ok'=>false,'error'=>'Log JSON yazılamadı'] : ['ok'=>true,'file'=>'data/logs/'.basename($file),'count'=>count($payload['logs'])]);
}


if (isset($_GET['sold'])) {
    $mode = (string)$_GET['sold'];
    $date = (string)($_GET['date'] ?? '');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) json_response(['ok'=>false,'error'=>'Geçerli tarih gerekli (YYYY-MM-DD)']);
    @is_dir($soldDir) || @mkdir($soldDir, 0777, true);
    $displayDate = substr($date,8,2).'.'.substr($date,5,2).'.'.substr($date,0,4);
    $file = $soldDir . '/Sat_' . $displayDate . '.json';
    $legacyFile = $soldDir . '/' . $date . '.json';
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $mode === 'save') {
        $json = json_decode(file_get_contents('php://input') ?: '', true);
        if (!is_array($json)) json_response(['ok'=>false,'error'=>'Geçersiz JSON']);
        $rows = array_values(is_array($json['sold'] ?? null) ? $json['sold'] : []);
        $payload = ['date'=>$date,'saved_at'=>date('Y-m-d H:i:s'),'sold'=>$rows];
        $ok = @file_put_contents($file, json_encode($payload, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        json_response($ok === false ? ['ok'=>false,'error'=>'Satılanlar JSON yazılamadı'] : ['ok'=>true,'file'=>'data/sold/'.basename($file),'count'=>count($rows)]);
    }
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && $mode === 'load') {
        if (!file_exists($file) && file_exists($legacyFile)) $file = $legacyFile;
        if (!file_exists($file)) json_response(['ok'=>false,'error'=>$date.' tarihli Satılanlar kaydı bulunamadı']);
        $json = json_decode(@file_get_contents($file) ?: '', true);
        if (!is_array($json)) json_response(['ok'=>false,'error'=>'Satılanlar JSON bozuk']);
        json_response(['ok'=>true,'date'=>$date,'sold'=>array_values(is_array($json['sold'] ?? null) ? $json['sold'] : [])]);
    }
    json_response(['ok'=>false,'error'=>'Geçersiz Satılanlar isteği']);
}


if (isset($_GET['holdings'])) {
    $mode = (string)$_GET['holdings'];
    $date = (string)($_GET['date'] ?? '');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) json_response(['ok'=>false,'error'=>'Geçerli tarih gerekli (YYYY-MM-DD)']);
    @is_dir($holdingsDir) || @mkdir($holdingsDir, 0777, true);
    $displayDate = substr($date,8,2).'.'.substr($date,5,2).'.'.substr($date,0,4);
    $file = $holdingsDir . '/Al_' . $displayDate . '.json';
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $mode === 'save') {
        $json = json_decode(file_get_contents('php://input') ?: '', true);
        if (!is_array($json)) json_response(['ok'=>false,'error'=>'Geçersiz JSON']);
        $rows = array_values(is_array($json['holdings'] ?? null) ? $json['holdings'] : []);
        $payload = ['date'=>$date,'saved_at'=>date('Y-m-d H:i:s'),'holdings'=>$rows];
        $ok = @file_put_contents($file, json_encode($payload, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        json_response($ok === false ? ['ok'=>false,'error'=>'Alınanlar JSON yazılamadı'] : ['ok'=>true,'file'=>'data/holdings/'.basename($file),'count'=>count($rows)]);
    }
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && $mode === 'load') {
        if (!file_exists($file)) json_response(['ok'=>false,'error'=>$date.' tarihli Alınanlar kaydı bulunamadı']);
        $json = json_decode(@file_get_contents($file) ?: '', true);
        if (!is_array($json)) json_response(['ok'=>false,'error'=>'Alınanlar JSON bozuk']);
        json_response(['ok'=>true,'date'=>$date,'holdings'=>array_values(is_array($json['holdings'] ?? null) ? $json['holdings'] : [])]);
    }
    json_response(['ok'=>false,'error'=>'Geçersiz Alınanlar isteği']);
}

function external_json_fetch(string $kind): void {
    $urls = [
        'equity' => 'https://markets.fintables.com/barbar/server/query?fields=V,YLD3m&type=equity',
        'tedbir' => 'https://halkarz.com/wp-content/themes/halkarz/api/tedbir.php',
    ];
    if (!isset($urls[$kind])) json_response(['ok'=>false,'error'=>'Geçersiz dış veri isteği']);
    $url = $urls[$kind];
    $body = false;
    $http = 0;
    $err = '';

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 18,
            CURLOPT_ENCODING => '',
            CURLOPT_HTTPHEADER => ['Accept: application/json, text/plain, */*'],
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/152 Safari/537.36',
        ]);
        $body = curl_exec($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = (string)curl_error($ch);
        curl_close($ch);
    }

    if ($body === false || $body === '') {
        $ctx = stream_context_create(['http'=>[
            'method'=>'GET', 'timeout'=>18, 'ignore_errors'=>true,
            'header'=>"Accept: application/json, text/plain, */*\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/152 Safari/537.36\r\nConnection: close\r\n"
        ]]);
        $body = @file_get_contents($url, false, $ctx);
        if (isset($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) $http = (int)$m[1];
        if ($body === false) $err = $err ?: 'file_get_contents başarısız';
    }

    if ($body === false || $body === '') json_response(['ok'=>false,'error'=>'Dış veri alınamadı','kind'=>$kind,'http_status'=>$http,'detail'=>$err]);
    $json = json_decode($body, true);
    if (!is_array($json)) json_response(['ok'=>false,'error'=>'Dış kaynak JSON döndürmedi','kind'=>$kind,'http_status'=>$http,'detail'=>substr((string)$body,0,240)]);
    json_response(['ok'=>true,'kind'=>$kind,'http_status'=>$http,'data'=>$json]);
}

if (isset($_GET['external'])) external_json_fetch((string)$_GET['external']);

if (isset($_GET['api'])) {
    $api = (string)$_GET['api'];
    if (in_array($api,['ziraat_login_start','ziraat_login_otp','ziraat_order'],true) && $_SERVER['REQUEST_METHOD']!=='POST') { http_response_code(405);json_response(['ok'=>false,'error'=>'POST gerekli.']); }
    $body = json_decode(file_get_contents('php://input') ?: '', true);
    if (!is_array($body)) $body = [];
    if ($api === 'ziraat_status') json_response(zrx_status());
    if ($api === 'ziraat_login_start') json_response(zrx_login_start($body));
    if ($api === 'ziraat_login_otp') json_response(zrx_login_otp($body));
    if ($api === 'ziraat_portfolio') json_response(zrx_portfolio_items($body));
    if ($api === 'ziraat_daily_orders') json_response(zrx_daily_orders($body));
    if ($api === 'ziraat_order') json_response(zrx_order($body));
    json_response(['ok'=>false,'error'=>'Geçersiz Ziraat API isteği']);
}

if (isset($_GET['settings'])) {
    $mode = (string)$_GET['settings'];
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && $mode === 'load') {
        if (!file_exists($settingsFile)) json_response(['ok'=>true,'data'=>null]);
        $json = json_decode(@file_get_contents($settingsFile) ?: '', true);
        if (!is_array($json)) json_response(['ok'=>false,'error'=>'ayarlar.json bozuk']);
        json_response(['ok'=>true,'data'=>$json]);
    }
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $mode === 'save') {
        $json = json_decode(file_get_contents('php://input') ?: '', true);
        if (!is_array($json)) json_response(['ok'=>false,'error'=>'Geçersiz JSON']);
        $ok = @file_put_contents($settingsFile, json_encode($json, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        json_response($ok === false ? ['ok'=>false,'error'=>'ayarlar.json yazılamadı'] : ['ok'=>true]);
    }
    json_response(['ok'=>false,'error'=>'Geçersiz ayar isteği']);
}
?>
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="csrf-token" content="<?= htmlspecialchars($portfoyCsrf,ENT_QUOTES,'UTF-8') ?>">
<title>Ziraat Portföy ve Emir Köprüsü</title>
<script src="gostergeler.js"></script>
<script src="strateji_motoru.js"></script>
<style>
:root{--bg:#0b1220;--panel:#121a2b;--card:#182235;--muted:#96a0b5;--txt:#eef3ff;--line:#25324a;--ok:#18c37e;--bad:#ff6b6b;--warn:#ffcb57;--blue:#4ea1ff}
*{box-sizing:border-box}html,body{height:100%}body{margin:0;font:13px/1.25 Arial,Helvetica,sans-serif;background:var(--bg);color:var(--txt)}
.wrap{width:100%;max-width:none;margin:0;padding:10px;box-sizing:border-box}.topbar{display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap;margin-bottom:8px}.title{font-size:22px;font-weight:700}.muted{color:var(--muted)}.tiny{font-size:12px}
.panel{background:var(--panel);border:1px solid var(--line);border-radius:16px;overflow:hidden;margin-bottom:10px}.hd{padding:9px 12px;border-bottom:1px solid var(--line);font-weight:700;background:rgba(255,255,255,.02)}.bd{padding:9px}
button,input{border:1px solid var(--line);background:var(--card);color:var(--txt);border-radius:7px;padding:4px 7px;font:inherit;min-height:25px}button{line-height:1.05}table button{min-height:22px;padding:2px 7px;font-size:11px;border-radius:6px}button{cursor:pointer;font-weight:700}button.primary{background:linear-gradient(180deg,#1d7ef2,#1564c3)}button.good{background:linear-gradient(180deg,#18c37e,#129b64)}button.danger{background:linear-gradient(180deg,#ff7d7d,#de5252)}button.warn{background:linear-gradient(180deg,#ffcb57,#d8a834);color:#2a220a}
.btnrow,.statline{display:flex;gap:7px;flex-wrap:wrap}.statline{margin-top:8px}.stat{padding:5px 8px;border-radius:10px;background:var(--card);border:1px solid var(--line);color:var(--muted)}.stat b{color:var(--txt)}.check{display:inline-flex;align-items:center;gap:7px;background:var(--card);border:1px solid var(--line);padding:5px 8px;border-radius:8px}.check input{min-height:auto}
table{width:100%;border-collapse:collapse}th,td{padding:3px 5px;border-bottom:1px solid var(--line);text-align:left;white-space:nowrap;font-size:12px}th{position:sticky;top:0;background:#111b2d;color:#cfd8ea;z-index:1}.num{text-align:right}.pos{color:var(--ok)}.neg{color:var(--bad)}.scroll{overflow:auto;max-height:330px}.log{background:#0d1524;border:1px solid var(--line);border-radius:12px;padding:9px;max-height:180px;overflow:auto;font-family:Consolas,monospace;font-size:12px}
.modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.62);align-items:center;justify-content:center;z-index:50}.modal.open{display:flex}.modal-card{width:min(460px,92vw);background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:14px}.field{display:flex;flex-direction:column;gap:4px;margin-bottom:9px}.field label{color:var(--muted);font-size:12px}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:10px}@media(max-width:900px){.grid2{grid-template-columns:1fr}}
.grid{display:grid;grid-template-columns:360px minmax(0,1fr);gap:8px;align-items:start}
.grid>.panel:first-child{min-width:0}
.tables{display:flex;flex-direction:column;gap:8px;min-width:0}
.tables>.panel{margin-bottom:0}
.formgrid{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.formgrid .field{margin-bottom:0}
.section{margin-top:9px;padding-top:9px;border-top:1px solid var(--line)}
.switchrow{display:flex;gap:6px;flex-wrap:wrap}
.table-scroll{overflow:auto;max-height:315px}
.scan-panel .table-scroll{max-height:330px}
th.sortable{cursor:pointer;user-select:none}th.sortable:hover{background:#17243a}.symbol-link{color:#8fc5ff;text-decoration:none;font-weight:700}.symbol-link:hover{text-decoration:underline}.top-actions{display:flex;align-items:center;gap:7px;flex-wrap:wrap}.sold-tools,.hold-tools{display:flex;align-items:center;gap:6px;flex-wrap:wrap}.sold-tools input,.hold-tools input{width:132px}.hd-metric{font-size:12px;font-weight:500;margin-left:12px;white-space:nowrap}.hd-titlegroup{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.time-col{text-align:right!important;width:150px;min-width:150px}@media(max-width:1100px){.grid{grid-template-columns:1fr}.tables{display:flex;flex-direction:column}}

.topbar{align-items:flex-start}
.top-metrics{display:flex;align-items:flex-start;gap:6px;flex:1;min-width:0;overflow-x:auto;padding-bottom:2px}
.perf-summary{display:flex;align-items:center;gap:8px;flex-wrap:nowrap;white-space:nowrap;font-size:11px}
.perf-summary .perf-item{padding:3px 6px;border:1px solid var(--line);border-radius:7px;background:#0d1524}
@media(max-width:1100px){.topbar{flex-direction:column}.top-metrics{width:100%}.top-actions{width:100%}}
</style>
</head>
<body>
<div class="wrap">
  <div class="topbar">
    <div class="top-metrics">
      <div class="perf-summary" id="dailyPerformanceSummary">
        <span class="perf-item">GÜNLÜK HACİM(TL): <b id="dailyTradeVolumeDisplay">0,00</b></span>
        <span class="perf-item">Brüt KarTL: <b id="perfGross">0,00</b></span>
        <span class="perf-item">Açık KarTL: <b id="perfOpen">0,00</b></span>
        <span class="perf-item">Komisyon: <b id="perfCommission">0,00</b></span>
        <span class="perf-item">Net KarTL: <b id="perfNet">0,00</b></span>
      </div>
    </div>
    <div class="top-actions">
      <button class="danger" id="btnReset">Portföyü Sıfırla</button>
      <button id="btnPortfolio">Portföy Çek</button>
      <button class="primary" id="btnZiraatLogin">Ziraat Giriş</button>
      <button class="primary" id="btnFintables">Fintables Bağlantı</button>
      <div class="stat">Ziraat: <b id="ziraatLoginState">Giriş Yapılmadı</b></div>
    </div>
  </div>

  <div class="grid">
    <div class="panel">
      <div class="hd">Kontrol Paneli</div>
      <div class="bd">
        <div class="formgrid">
          <div class="field"><label>AL Tutarı (TL)</label><input id="buyAmount" type="number" value="9000" min="1" step="1"></div>
          <div class="field"><label>AL Toplam Limit (TL)</label><input id="totalLimit" type="number" value="100000" min="0" step="1"></div>
          <div class="field"><label>Değerlendirme MİN%</label><input id="evalMinPct" type="number" value="-2" step="0.01"></div>
          <div class="field"><label>Değerlendirme MAX%</label><input id="evalMaxPct" type="number" value="3" step="0.01"></div>
          <div class="field"><label>RSI Periyodu</label><input id="rsiPeriod" type="number" value="14" min="2" step="1"></div>
          <div class="field"><label>RSI Toparlanma Eşiği ↑</label><input id="rsiBuy" type="number" value="25" step="0.1"></div>
          <div class="field"><label>Trailing Aktivasyon %</label><input id="trailActivation" type="number" value="2.00" min="0" step="0.01"></div>
          <div class="field"><label>Trailing Sapma %</label><input id="trailDistance" type="number" value="0.10" min="0" step="0.01"></div>
          <div class="field"><label>Timeframe (dk)</label><input id="timeframe" type="number" value="15" readonly></div>
          <div class="field"><label>RSI Fiyatı</label><input id="rsiSource" value="ASK" readonly></div>
          <div class="field"><label>3AYMİN%</label><input id="threeMonthMinPct" type="number" value="-100" step="0.01"></div>
          <div class="field"><label>3AYMAX%</label><input id="threeMonthMaxPct" type="number" value="100" step="0.01"></div>
          <div class="field"><label>HİSSEADET (DNA TOP-N)</label><input id="stockCount" type="number" value="100" min="1" max="623" step="1"></div>
          <div class="field"><label>MANUEL HİSSE</label><div style="display:flex;gap:6px;align-items:center"><input id="manualSymbol" type="text" placeholder="Örn: THYAO" maxlength="12" autocomplete="off"><button id="btnManualAdd" type="button" class="primary" style="white-space:nowrap">EKLE</button></div></div>
        </div>
        <div class="section switchrow">
          <label class="check"><input id="autoBuy" type="checkbox"> Oto-AL</label>
          <label class="check"><input id="autoSell" type="checkbox"> Oto-SAT</label>
          <label class="check"><input id="paperMode" type="checkbox" checked> Paper mod (gerçek emir yok)</label>
        </div>
        <div class="section btnrow">
          <button id="btnDailyOrders">Günlük Emirler</button>
          <button id="btnSave">Kaydet</button>
          <button id="btnLoad">Yükle</button>
        </div>
        <div class="section">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:6px">
            <label style="margin:0">Kayıt</label>
            <button id="btnSaveLogs" type="button">Günün Logunu JSON Kaydet</button>
          </div>
          <div class="log" id="logBox"></div>
        </div>
      </div>
    </div>

    <div class="tables">
      <div class="panel scan-panel">
        <div class="hd" style="display:flex;align-items:center;justify-content:space-between;gap:8px">
          <span>Tarama Tablosu</span>
          <span id="scanInfo" class="tiny muted">Sayfa açılışında otomatik hazırlanıyor...</span>
        </div>
        <div class="bd" style="padding-top:0">
          <div class="table-scroll">
            <table id="scanTable">
              <thead><tr><th class="sortable" data-scan-sort="symbol">SEMBOL ↕</th><th class="num">ŞUAN</th><th class="num sortable" data-scan-sort="dayPct">GÜN% ↕</th><th class="num sortable" data-scan-sort="rsi">RSI14 ↕</th><th class="sortable" data-scan-sort="signal">SİNYAL ↕</th><th>İŞLEM</th><th class="time-col sortable" data-scan-sort="time">ZAMAN ↕</th></tr></thead>
              <tbody></tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="panel">
        <div class="hd" style="display:flex;align-items:center;justify-content:space-between;gap:8px">
          <div class="hd-titlegroup"><span>Alınanlar</span><span class="hd-metric">Kâr%: <b id="holdingAvg">0.00</b></span><span class="hd-metric">KarTL: <b id="holdingProfitTL">0,00</b></span><span class="hd-metric">Aktif Pozisyon: <b id="holdingCount">0</b></span></div>
          <div class="hold-tools"><input id="holdingDate" type="date"><button id="btnHoldingSave" class="good">Kaydet</button><button id="btnHoldingLoad" class="primary">Yükle</button></div>
        </div>
        <div class="bd"><div class="scroll"><table id="holdingsTable"><thead><tr><th class="sortable" data-hold-sort="symbol">SEMBOL ↕</th><th class="num">ADET</th><th class="num sortable" data-hold-sort="cost">MALİYET ↕</th><th class="num">ŞUAN</th><th class="num sortable" data-hold-sort="dayPct">GÜN% ↕</th><th class="num">ALIŞ TL</th><th class="num">ŞUAN TL</th><th class="num sortable" data-hold-sort="pnl">KAR% ↕</th><th class="num sortable" data-hold-sort="rsi">RSI14 ↕</th><th class="sortable" data-hold-sort="signal">SİNYAL ↕</th><th>İŞLEM</th><th class="time-col sortable" data-hold-sort="time">ZAMAN ↕</th></tr></thead><tbody></tbody></table></div></div>
      </div>

      <div class="panel">
        <div class="hd" style="display:flex;align-items:center;justify-content:space-between;gap:8px"><div class="hd-titlegroup"><span>Satılanlar</span><span class="hd-metric">Kâr%: <b id="realizedAvg">0.00</b></span><span class="hd-metric">KarTL: <b id="realizedProfitTL">0,00</b></span><span class="hd-metric">Aktif Pozisyon: <b id="soldActiveCount">0</b></span></div><div class="sold-tools"><input id="soldDate" type="date"><button id="btnSoldSave" class="good">Kaydet</button><button id="btnSoldLoad" class="primary">Yükle</button></div></div>
        <div class="bd"><div class="scroll"><table id="soldTable"><thead><tr><th class="sortable" data-sold-sort="symbol">SEMBOL ↕</th><th class="num">ADET</th><th class="num">ALIŞ</th><th class="num">SATIŞ</th><th class="num">ALIŞ TL</th><th class="num">SATIŞ TL</th><th class="num sortable" data-sold-sort="pnl">KAR% ↕</th><th class="time-col">ALIŞ ZAMANI</th><th class="time-col sortable" data-sold-sort="time">SATIŞ ZAMANI ↕</th></tr></thead><tbody></tbody></table></div></div>
      </div>
    </div>
  </div>

</div>

<div class="modal" id="ziraatLoginModal"><div class="modal-card"><h3>Ziraat Giriş</h3><div class="field"><label>Kullanıcı / Hesap</label><input id="ziraatAccount" autocomplete="username"></div><div class="field"><label>Şifre</label><input id="ziraatPassword" type="password" autocomplete="current-password"></div><div class="field"><label>Alt hesap</label><input id="ziraatSubaccount" value="100"></div><div id="ziraatLoginMsg" class="muted tiny"></div><div class="btnrow" style="margin-top:10px"><button class="primary" id="btnLoginStart">SMS İste</button><button id="btnLoginClose">Kapat</button></div></div></div>
<div class="modal" id="ziraatOtpModal"><div class="modal-card"><h3>SMS Doğrulama</h3><div class="field"><label>SMS Kodu</label><input id="ziraatOtp" inputmode="numeric"></div><div id="ziraatOtpMsg" class="muted tiny"></div><div class="btnrow" style="margin-top:10px"><button class="primary" id="btnOtpSend">Giriş Yap</button><button id="btnOtpClose">Kapat</button></div></div></div>

<script>
const PORTFOY_ALGO_CONFIG=<?= json_encode($portfoyAlgoConfig,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
const rawFetch=window.fetch.bind(window);
window.fetch=(resource,options={})=>{
  const url=new URL(typeof resource==='string'?resource:resource.url,location.href);
  if(url.origin===location.origin && !['GET','HEAD'].includes((options.method||'GET').toUpperCase())){
    options={...options,headers:new Headers(options.headers||{})};
    options.headers.set('X-CSRF-Token',document.querySelector('meta[name="csrf-token"]').content);
  }
  return rawFetch(resource,options);
};
const SETTINGS_ENDPOINT='?settings='; const ZIRAAT_API_ENDPOINT='?api='; const LOGS_ENDPOINT='?logs=save'; const EXTERNAL_ENDPOINT='?external=';
const EQUITY_URL='https://markets.fintables.com/barbar/server/query?fields=V,YLD3m&type=equity';
const DNA_SELECTION_URL='dna_top100_latest.json'; // HistGradientBoosting DNA 1+3+5, son 30 işlem günü
const TEDBIR_URL='https://halkarz.com/wp-content/themes/halkarz/api/tedbir.php';
const WS_URL='wss://markets.fintables.com/vessel';
// Fintables WebSocket login token. WebSocket API özel Authorization header kabul etmediği için
// token bağlantı açıldıktan sonra login mesajında gönderilir.
let FINTABLES_WS_TOKEN=<?= json_encode($portfoyFeedToken,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
const WS_TOPICS=['A','B','P'];
const STRAT_RSI_THRESHOLD=25;
const STRAT_RSI_COMPARE=(v,t)=>v <= t;
const STRAT_NAME="3Commas";

const WS_CHUNK_SIZE=120;
const state={holdings:{},sold:[],t2:0,dailyOrders:[],logs:[],scan:[],scanBusy:false,ws:null,wsRows:{},wsReconnectTimer:null,wsStopped:false,candles:{},trail:{},entryLocks:new Set(),sellLocks:new Set(),scanSort:{key:'symbol',dir:1},holdSort:{key:'symbol',dir:1},soldSort:{key:'symbol',dir:1},tedbirFilteredCount:0,dailyTradeVolumeTL:0,dailyTradeDate:''};
const $=id=>document.getElementById(id); const n=(v,d=0)=>{const x=Number(v);return Number.isFinite(x)?x:d}; const fmt=(v,d=2)=>n(v).toLocaleString('tr-TR',{minimumFractionDigits:d,maximumFractionDigits:d});
const safeSym=x=>String(x||'').toUpperCase().trim().replace(/[^A-Z0-9_.-]/g,'');
function nowStr(){return new Date().toLocaleString('tr-TR')}
function setText(id,v){const e=$(id);if(e)e.textContent=v}
function log(msg){const line=`[${nowStr()}] ${msg}`;state.logs.push(line);if(state.logs.length>500)state.logs=state.logs.slice(-500);const b=$('logBox');if(b){b.textContent=state.logs.slice(-250).join('\n');b.scrollTop=b.scrollHeight}}
function show(id){$(id)?.classList.add('open')} function hide(id){$(id)?.classList.remove('open')}
function pctClass(v){return n(v)>0?'pos':(n(v)<0?'neg':'')}
function pickNumber(o,keys,d=0){for(const k of keys){if(o&&o[k]!=null&&o[k]!==''&&!Number.isNaN(Number(String(o[k]).replace(',','.'))))return Number(String(o[k]).replace(',','.'));}return d}
function displayTime(v){if(!v)return '—';const d=new Date(v);return Number.isNaN(d.getTime())?String(v):d.toLocaleString('tr-TR')}
function timeNumeric(v){if(v==null||v==='')return 0;if(typeof v==='number'&&Number.isFinite(v))return v;const s=String(v).trim();let t=Date.parse(s);if(Number.isFinite(t))return t;const m=s.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?/);if(m){const d=new Date(Number(m[3]),Number(m[2])-1,Number(m[1]),Number(m[4]||0),Number(m[5]||0),Number(m[6]||0));t=d.getTime();if(Number.isFinite(t))return t}return 0}
function symbolLink(sym){const s=safeSym(sym);return `<a class="symbol-link" href="https://fintables.com/islem-ekrani?code=${encodeURIComponent(s)}" target="_blank" rel="noopener noreferrer">${s}</a>`}
function commissionOnbinde(volumeTL){const v=Math.max(0,n(volumeTL,0));if(v<=75000)return 15;if(v<=150000)return 12;if(v<=500000)return 10;if(v<=1000000)return 8;if(v<=2000000)return 7;if(v<=4000000)return 6;if(v<=5500000)return 5;if(v<=7000000)return 4;if(v<=11000000)return 3;if(v<=15000000)return 2.5;if(v<=25000000)return 2;if(v<=30000000)return 1.5;return 1}
const DAILY_VOLUME_STORAGE_KEY='borsa_daily_trade_volume:'+location.pathname.replace(/\/+$/,'');
function localDateKey(){const d=new Date(),pad=x=>String(x).padStart(2,'0');return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`}
function tableTradeVolumeTL(){
  const holdingBuy=Object.values(state.holdings||{}).reduce((s,h)=>s+Math.max(0,n(h.qty))*Math.max(0,n(h.cost)),0);
  const soldTurnover=(state.sold||[]).reduce((s,x)=>s+(Math.max(0,n(x.qty))*Math.max(0,n(x.buy)))+(Math.max(0,n(x.qty))*Math.max(0,n(x.sell))),0);
  return holdingBuy+soldTurnover;
}
function recalculateDailyTradeVolumeFromTables(){
  const today=localDateKey();state.dailyTradeDate=today;state.dailyTradeVolumeTL=tableTradeVolumeTL();
  try{localStorage.setItem(DAILY_VOLUME_STORAGE_KEY,JSON.stringify({date:today,total:state.dailyTradeVolumeTL}))}catch(_){}
  updateDailyTradeVolumeDisplay();updateDailyPerformance();return state.dailyTradeVolumeTL;
}
function ensureDailyTradeVolume(){const today=localDateKey();if(state.dailyTradeDate!==today){state.dailyTradeDate=today;state.dailyTradeVolumeTL=tableTradeVolumeTL()}updateDailyTradeVolumeDisplay();return state.dailyTradeVolumeTL}
function loadDailyTradeVolume(){state.dailyTradeDate=localDateKey();state.dailyTradeVolumeTL=tableTradeVolumeTL();updateDailyTradeVolumeDisplay()}
function updateDailyTradeVolumeDisplay(){setText('dailyTradeVolumeDisplay',fmt(state.dailyTradeVolumeTL,2))}
function addDailyTradeVolume(amountTL){ensureDailyTradeVolume();const add=Math.max(0,n(amountTL,0));if(!(add>0))return;state.dailyTradeVolumeTL+=add;try{localStorage.setItem(DAILY_VOLUME_STORAGE_KEY,JSON.stringify({date:state.dailyTradeDate,total:state.dailyTradeVolumeTL}))}catch(_){}updateDailyTradeVolumeDisplay();updateDailyPerformance()}
function currentCommissionPct(){ensureDailyTradeVolume();return commissionOnbinde(state.dailyTradeVolumeTL)/100}
function dateOnly(v){const t=timeNumeric(v);if(!t)return '';const d=new Date(t),p=x=>String(x).padStart(2,'0');return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}`}
function shortDateTime(v){const t=timeNumeric(v);if(!t)return '—';return new Date(t).toLocaleString('tr-TR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'})}
function tradeFeeTL(x,commPct){const turn=(Math.max(0,n(x.qty))*Math.max(0,n(x.buy)))+(Math.max(0,n(x.qty))*Math.max(0,n(x.sell)));return turn*(commPct/100)}
function updateDailyPerformance(){
  const sold=Array.isArray(state.sold)?state.sold:[], hs=Object.values(state.holdings||{});
  const gross=sold.reduce((s,x)=>s+(n(x.sell)-n(x.buy))*n(x.qty),0);
  const open=hs.reduce((s,h)=>s+(n(h.last)-n(h.cost))*n(h.qty),0);
  const commPct=commissionOnbinde(Math.max(0,n(state.dailyTradeVolumeTL)))/100;
  const commission=sold.reduce((s,x)=>s+tradeFeeTL(x,commPct),0),net=gross-commission;
  setText('perfGross',fmt(gross,2));setText('perfOpen',fmt(open,2));setText('perfCommission',fmt(commission,2));setText('perfNet',fmt(net,2));
  for(const [id,val] of [['perfGross',gross],['perfOpen',open],['perfNet',net]]){const e=$(id);if(e)e.className=pctClass(val)}
}
function dynamicSellMarginPct(h){const net=Math.max(0,n($('sellMarginPct')?.value,0.30));const comm=currentCommissionPct();const bid=n(h?.last,NaN),ask=n(h?.ask,NaN);const spread=(bid>0&&ask>=bid)?((ask-bid)/bid*100):0;const commissionAdjusted=((((1+net/100)*(1+comm/100))/(1-comm/100))-1)*100;return commissionAdjusted+spread}

function firstPresent(o,keys){for(const k of keys){if(o&&o[k]!=null&&o[k]!=="")return o[k];}return null}
function rawNumber(v){if(v==null||v==='')return NaN;if(typeof v==='number')return Number.isFinite(v)?v:NaN;let t=String(v).trim().replace(/\s/g,'');if(!t)return NaN;if(t.includes(',')&&t.includes('.')){if(t.lastIndexOf(',')>t.lastIndexOf('.'))t=t.replace(/\./g,'').replace(',','.');else t=t.replace(/,/g,'')}else if(t.includes(','))t=t.replace(',','.');const x=Number(t);return Number.isFinite(x)?x:NaN}
function extractEquityRows(payload){
  const map=new Map(),seen=new WeakSet();
  const getVal=x=>{if(x&&typeof x==='object'&&Object.prototype.hasOwnProperty.call(x,'v'))return rawNumber(x.v);return rawNumber(x)};
  const fieldIndexes=fields=>{if(!Array.isArray(fields))return null;const f=fields.map(x=>String(x||'').trim().toUpperCase());const vi=f.indexOf('V'),yi=f.indexOf('YLD3M');return vi>=0&&yi>=0?{vi,yi}:null};
  function walk(node,inheritedFields=null,keyHint='',depth=0){
    if(depth>10||node==null)return;
    if(Array.isArray(node)){for(const x of node)if(x&&typeof x==='object')walk(x,inheritedFields,'',depth+1);return}
    if(typeof node!=='object'||seen.has(node))return;seen.add(node);
    const localFields=Array.isArray(node.fields)?node.fields:inheritedFields;
    const idx=fieldIndexes(localFields);

    // Fintables query biçimi: { data:{YYAPI:[{v:V},{v:YLD3m}],...}, fields:['V','YLD3m'] }
    if(idx){
      for(const [k,v] of Object.entries(node)){
        if(k==='fields'||!Array.isArray(v))continue;
        const symbol=safeSym(k);
        if(!symbol||symbol.length<2||v.length<=Math.max(idx.vi,idx.yi))continue;
        const V=getVal(v[idx.vi]),y=getVal(v[idx.yi]);
        if(Number.isFinite(V)&&Number.isFinite(y))map.set(symbol,{symbol,V,yRaw:y});
      }
    }

    // Gerçek Fintables equity biçimi:
    // {updated_at:'...', results:{A1CAP:[{r:true,v:...}, ...], ...}}
    // Bu cevapta fields=[V,YLD3m] görünse bile results dizisi 11 metrik içerebiliyor.
    // Kullanılan equity sırası: [2]=V (hacim), [5]=YLD3m (3 aylık getiri).
    if(node.results && typeof node.results==='object' && !Array.isArray(node.results)){
      for(const [k,v] of Object.entries(node.results)){
        if(!Array.isArray(v))continue;
        const symbol=safeSym(k);
        if(!symbol||symbol.length<2)continue;
        let V=NaN,y=NaN;
        if(v.length>=11){V=getVal(v[2]);y=getVal(v[5]);}
        else if(idx && v.length>Math.max(idx.vi,idx.yi)){V=getVal(v[idx.vi]);y=getVal(v[idx.yi]);}
        if(Number.isFinite(V)&&Number.isFinite(y))map.set(symbol,{symbol,V,yRaw:y});
      }
    }

    // Olası alternatif nesne biçimi için geriye dönük destek.
    const hasV=Object.prototype.hasOwnProperty.call(node,'V');
    const hasY=Object.prototype.hasOwnProperty.call(node,'YLD3m');
    if(hasV&&hasY){
      const symbol=safeSym(firstPresent(node,['code','symbol','ticker','sembol','hisse','S','Code','Symbol'])??keyHint);
      const V=rawNumber(node.V),y=rawNumber(node.YLD3m);
      if(symbol&&Number.isFinite(V)&&Number.isFinite(y))map.set(symbol,{symbol,V,yRaw:y});
    }

    for(const [k,v] of Object.entries(node)){
      if(k==='fields'||v==null||typeof v!=='object')continue;
      walk(v,localFields,k,depth+1);
    }
  }
  walk(payload,null,'',0);
  return [...map.values()];
}
function detectYieldScale(rows){const a=rows.map(r=>Math.abs(r.yRaw)).filter(Number.isFinite).sort((x,y)=>x-y);if(!a.length)return 1;const q=a[Math.min(a.length-1,Math.floor(a.length*.75))];return q<=2?100:1}
function extractTedbirCodes(payload){const out=new Set(),seen=new WeakSet();function walk(node,depth=0){if(depth>8||node==null)return;if(Array.isArray(node)){node.forEach(x=>walk(x,depth+1));return}if(typeof node!=='object')return;if(seen.has(node))return;seen.add(node);const code=safeSym(node.t_bistkod);if(code)out.add(code);for(const v of Object.values(node))if(v&&typeof v==='object')walk(v,depth+1)}walk(payload);return out}
async function fetchJsonDirectThenLocal(url,kind){try{const r=await fetch(url,{method:'GET',mode:'cors',cache:'no-store',credentials:'omit',headers:{'Accept':'application/json, text/plain, */*'}});if(r.ok)return await r.json()}catch(_e){}const r=await fetch(EXTERNAL_ENDPOINT+encodeURIComponent(kind),{cache:'no-store'});const j=await r.json();if(!j?.ok)throw new Error(j?.error||`${kind} verisi alınamadı`);return j.data}
function rsiWilder(closes,period){
  const p=Math.max(2,Math.floor(n(period,14)));if(!Array.isArray(closes)||closes.length<p+1)return NaN;
  let gain=0,loss=0;for(let i=1;i<=p;i++){const d=closes[i]-closes[i-1];if(d>=0)gain+=d;else loss-=d}gain/=p;loss/=p;
  for(let i=p+1;i<closes.length;i++){const d=closes[i]-closes[i-1],g=d>0?d:0,l=d<0?-d:0;gain=(gain*(p-1)+g)/p;loss=(loss*(p-1)+l)/p}
  if(loss===0)return gain===0?50:100;const rs=gain/loss;return 100-(100/(1+rs));
}
function candleBucket(ts,minutes=15){const ms=Math.max(1,minutes)*60000;return Math.floor(ts/ms)*ms}
function closedCloses(sym){const cs=state.candles[`${sym}:15`]||[],b=candleBucket(Date.now(),15);return cs.filter(c=>c.t<b).map(c=>c.c)}
function indicatorFor(sym){const rsi=rsiWilder(closedCloses(sym),Math.max(2,Math.floor(n($('rsiPeriod').value,14))));const thr=n($('rsiBuy').value,STRAT_RSI_THRESHOLD);const buy=Number.isFinite(rsi)&&STRAT_RSI_COMPARE(rsi,thr);return {rsi,signal:buy?'AL':'BEKLE'}}
function sortValueScan(r,key){if(key==='symbol'||key==='signal')return key==='signal'?indicatorFor(r.symbol).signal:String(r.symbol);if(key==='dayPct')return n(r.dayPct,NaN);if(key==='rsi')return indicatorFor(r.symbol).rsi;if(key==='time')return timeNumeric(r.wsTime||r.scanTime);return 0}
function renderScan(){
  const tb=$('scanTable').querySelector('tbody');tb.innerHTML='';
  const rows=[...state.scan].sort((a,b)=>{const k=state.scanSort.key,d=state.scanSort.dir,av=sortValueScan(a,k),bv=sortValueScan(b,k);if(k==='symbol'||k==='signal')return d*String(av).localeCompare(String(bv),'tr');return d*((Number.isFinite(av)?av:-Infinity)-(Number.isFinite(bv)?bv:-Infinity))});
  rows.forEach(r=>{const ind=indicatorFor(r.symbol),tr=document.createElement('tr');tr.dataset.symbol=r.symbol;const disabled=!Number.isFinite(r.ask)||r.ask<=0||!!state.holdings[r.symbol];tr.innerHTML=`<td>${symbolLink(r.symbol)}</td><td class="num js-ask">${Number.isFinite(r.ask)?fmt(r.ask):'—'}</td><td class="num js-day ${pctClass(r.dayPct)}">${Number.isFinite(r.dayPct)?fmt(r.dayPct,4)+'%':'—'}</td><td class="num js-rsi">${Number.isFinite(ind.rsi)?fmt(ind.rsi,2):'—'}</td><td class="js-signal">${ind.signal}</td><td><button class="primary js-buy" data-buy="${r.symbol}" ${disabled?'disabled':''}>AL</button></td><td class="js-time time-col">${displayTime(r.wsTime||r.scanTime)}</td>`;tb.appendChild(tr)});
  tb.querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>manualBuy(b.dataset.buy));
}
function updateScanRow(symbol){
  const r=state.scan.find(x=>x.symbol===symbol);if(!r)return;const tr=$('scanTable').querySelector(`tbody tr[data-symbol="${symbol}"]`);if(!tr)return;const ind=indicatorFor(symbol);
  const a=tr.querySelector('.js-ask'),d=tr.querySelector('.js-day'),ri=tr.querySelector('.js-rsi'),si=tr.querySelector('.js-signal'),t=tr.querySelector('.js-time'),b=tr.querySelector('.js-buy');
  if(a)a.textContent=Number.isFinite(r.ask)?fmt(r.ask):'—';if(d){d.textContent=Number.isFinite(r.dayPct)?fmt(r.dayPct,4)+'%':'—';d.className='num js-day '+pctClass(r.dayPct)}if(ri)ri.textContent=Number.isFinite(ind.rsi)?fmt(ind.rsi,2):'—';if(si)si.textContent=ind.signal;if(t)t.textContent=displayTime(r.wsTime||r.scanTime);if(b)b.disabled=!Number.isFinite(r.ask)||r.ask<=0||!!state.holdings[symbol];
}
function wsSend(obj){if(state.ws&&state.ws.readyState===WebSocket.OPEN)state.ws.send(JSON.stringify(obj))}
function buildWsTopics(){const out=[],symbols=new Set(state.scan.map(r=>r.symbol));for(const sym of Object.keys(state.holdings))symbols.add(sym);for(const sym of symbols)for(const f of WS_TOPICS)out.push(sym+'/'+f);return out}
function subscribeWsSymbols(){const topics=buildWsTopics();for(let i=0;i<topics.length;i+=WS_CHUNK_SIZE)wsSend({type:'subscribe',topics:topics.slice(i,i+WS_CHUNK_SIZE)});log(`WS → ${new Set([...state.scan.map(r=>r.symbol),...Object.keys(state.holdings)]).size} hisse / ${topics.length} A-B-P aboneliği gönderildi`)}
function stopWebSocket(permanent=false){if(permanent)state.wsStopped=true;if(state.wsReconnectTimer){clearTimeout(state.wsReconnectTimer);state.wsReconnectTimer=null}const ws=state.ws;state.ws=null;if(ws){try{ws.onclose=null;ws.onerror=null;ws.onmessage=null;ws.close()}catch(_e){}}}
function scheduleWsReconnect(){const symbolCount=new Set([...state.scan.map(r=>r.symbol),...Object.keys(state.holdings)]).size;if(state.wsStopped||state.wsReconnectTimer||!symbolCount)return;state.wsReconnectTimer=setTimeout(()=>{state.wsReconnectTimer=null;startWebSocket()},3000)}
function updateCandle(sym,price,minutes=15){if(!(price>0))return;const key=`${sym}:${minutes}`,b=candleBucket(Date.now(),minutes);let cs=state.candles[key]||(state.candles[key]=[]),c=cs.length?cs[cs.length-1]:null;if(!c||c.t!==b){if(c)onClosedCandle(sym,minutes);c={t:b,o:price,h:price,l:price,c:price};cs.push(c);if(cs.length>260)cs.splice(0,cs.length-260)}else{c.h=Math.max(c.h,price);c.l=Math.min(c.l,price);c.c=price}}
function onClosedCandle(sym,minutes){if(minutes!==15)return;const ind=indicatorFor(sym);updateScanRow(sym);if($('autoBuy').checked&&Number.isFinite(ind.rsi)&&STRAT_RSI_COMPARE(ind.rsi,n($('rsiBuy').value,STRAT_RSI_THRESHOLD))&&!state.holdings[sym]&&state.scan.some(x=>x.symbol===sym))autoBuyStrategy(sym,`${STRAT_NAME} RSI(${Math.floor(n($('rsiPeriod').value,14))})=${fmt(ind.rsi,2)} | 15dk kapanış`);}
function restoreScanFromHolding(h){if(!h||state.scan.some(x=>x.symbol===h.symbol)||state.holdings[h.symbol])return;state.scan.push({symbol:h.symbol,V:n(h.scanV,0),yRaw:n(h.scanY,0),scanTime:new Date().toISOString(),ask:n(h.ask,NaN),bid:n(h.last,NaN),prev:n(h.prev,NaN),dayPct:n(h.dayPct,NaN),wsTime:new Date().toISOString()});renderScan();if(state.ws&&state.ws.readyState===WebSocket.OPEN)subscribeWsSymbols();}
function strategyOnBid(sym,bid){const h=state.holdings[sym];if(!h||!$('autoSell').checked||!(bid>0)||!(h.cost>0))return;const act=Math.max(0,n($('trailActivation').value,2.0)),dist=Math.max(0,n($('trailDistance').value,0.1)),pnl=(bid-h.cost)/h.cost*100,t=state.trail[sym]||(state.trail[sym]={armed:false,peak:0});if(!t.armed&&pnl>=act){t.armed=true;t.peak=bid;log(`TRAIL ARM → ${sym} | +${fmt(pnl,4)}% | tepe ${fmt(bid)}`)}if(t.armed){if(bid>t.peak)t.peak=bid;const stop=t.peak*(1-dist/100);if(bid<=stop+1e-12)autoSellStrategy(sym,`3Commas Trailing TP | aktivasyon ${fmt(act,2)}% | sapma ${fmt(dist,2)}% | tepe ${fmt(t.peak)}`)}}
function holdingSignal(sym){const h=state.holdings[sym],t=state.trail[sym]||{armed:false,peak:0},ind=indicatorFor(sym);if(!h)return ind.signal;if(t.armed){const dist=Math.max(0,n($('trailDistance').value,0.1)),stop=t.peak*(1-dist/100);return `TRAIL ${fmt(stop)}`}return Number.isFinite(ind.rsi)?`RSI ${fmt(ind.rsi,2)}`:'BEKLE';}
function updateHoldingRow(symbol){const h=state.holdings[symbol];if(!h)return;const tr=$('holdingsTable').querySelector(`tbody tr[data-symbol="${symbol}"]`);if(!tr){renderHoldings();return}const pnl=h.cost>0?((n(h.last)-h.cost)/h.cost*100):0,ind=indicatorFor(symbol);const cells={last:tr.querySelector('.js-h-last'),day:tr.querySelector('.js-h-day'),tl:tr.querySelector('.js-h-tl'),pnl:tr.querySelector('.js-h-pnl'),rsi:tr.querySelector('.js-h-rsi'),signal:tr.querySelector('.js-h-signal')};if(cells.last)cells.last.textContent=Number.isFinite(n(h.last,NaN))?fmt(h.last):'—';if(cells.day){cells.day.textContent=Number.isFinite(n(h.dayPct,NaN))?fmt(h.dayPct,4)+'%':'—';cells.day.className='num js-h-day '+pctClass(h.dayPct)}if(cells.tl)cells.tl.textContent=fmt(n(h.last)*n(h.qty));if(cells.pnl){cells.pnl.textContent=fmt(pnl,4)+'%';cells.pnl.className='num js-h-pnl '+pctClass(pnl)}if(cells.rsi)cells.rsi.textContent=Number.isFinite(ind.rsi)?fmt(ind.rsi,2):'—';if(cells.signal)cells.signal.textContent=holdingSignal(symbol);updateStats();}
function applyWsField(symbol,field,value){
  const sym=safeSym(symbol),f=String(field||'').toUpperCase();
  if(!sym||!f)return false;
  let raw=value;
  if(raw&&typeof raw==='object'){
    if(raw.v!==undefined)raw=raw.v;
    else if(raw.value!==undefined)raw=raw.value;
    else if(raw.data_value!==undefined)raw=raw.data_value;
  }
  const num=rawNumber(raw);if(!Number.isFinite(num))return false;
  let changed=false;
  const row=state.scan.find(x=>x.symbol===sym);
  if(row){
    if(f==='A')row.ask=num;else if(f==='B')row.bid=num;else if(f==='P')row.prev=num;else return false;
    if(Number.isFinite(row.bid)&&Number.isFinite(row.prev)&&row.prev!==0)row.dayPct=((row.bid-row.prev)/row.prev)*100;
    row.wsTime=new Date().toISOString();updateScanRow(sym);changed=true;
  }
  const h=state.holdings[sym];
  if(h){
    if(f==='B')h.last=num;
    else if(f==='P')h.prev=num;
    else if(f==='A')h.ask=num;
    else return changed;
    if(Number.isFinite(n(h.last,NaN))&&Number.isFinite(n(h.prev,NaN))&&n(h.prev)!==0)h.dayPct=((n(h.last)-n(h.prev))/n(h.prev))*100;
    h.wsTime=new Date().toISOString();updateHoldingRow(sym);if(f==='B')strategyOnBid(sym,num);changed=true;
  }
  if(f==='A'){updateCandle(sym,num,15);updateScanRow(sym);updateHoldingRow(sym)}
  return changed;
}
function applyWsChannel(key,value){
  if(!key)return false;
  const parts=String(key).replace(/^\/+|\/+$/g,'').replace(/^r\//i,'').split('/');
  if(parts.length<2)return false;
  return applyWsField(parts[0],parts[1],value);
}
function handleWsPayload(payload,depth=0){
  if(depth>10||payload==null)return;
  if(typeof payload==='string'){
    const t=payload.trim();if(!t)return;
    try{handleWsPayload(JSON.parse(t),depth+1)}catch(_e){}return;
  }
  if(Array.isArray(payload)){payload.forEach(x=>handleWsPayload(x,depth+1));return}
  if(typeof payload!=='object')return;

  // En yaygın kanal biçimleri: {k:'THYAO/A',v:...}, {topic:'r/THYAO/P',value:...}
  const key=payload.k??payload.topic??payload.channel??payload.path;
  const hasSimpleVal=(payload.v!==undefined&&typeof payload.v!=='object')||payload.value!==undefined||payload.data_value!==undefined;
  if(key&&hasSimpleVal){
    const val=payload.v!==undefined?payload.v:(payload.value!==undefined?payload.value:payload.data_value);
    applyWsChannel(key,val);
  }

  // {k:'THYAO/A',v:{v:123}} gibi sarılı değerler.
  if(key&&payload.v&&typeof payload.v==='object')applyWsChannel(key,payload.v);

  // Doğrudan sembol nesnesi: {code:'THYAO',A:...,B:...,P:...}
  const directSym=safeSym(payload.code??payload.symbol??payload.sembol??payload.o);
  if(directSym){
    if(payload.A!==undefined||payload.ask!==undefined)applyWsField(directSym,'A',payload.A??payload.ask);
    if(payload.B!==undefined||payload.bid!==undefined)applyWsField(directSym,'B',payload.B??payload.bid);
    if(payload.P!==undefined||payload.prev!==undefined||payload.previousClose!==undefined)applyWsField(directSym,'P',payload.P??payload.prev??payload.previousClose);
    // Fintables'in {o:'THYAO',v:{A:...,B:...,P:...}} biçimi.
    if(payload.v&&typeof payload.v==='object'){
      const v=payload.v;
      if(v.A!==undefined||v.ask!==undefined)applyWsField(directSym,'A',v.A??v.ask);
      if(v.B!==undefined||v.bid!==undefined)applyWsField(directSym,'B',v.B??v.bid);
      if(v.P!==undefined||v.prev!==undefined||v.previousClose!==undefined)applyWsField(directSym,'P',v.P??v.prev??v.previousClose);
    }
  }

  // WebSocket sunucusunun kullandığı olası wrapper'ları recursive tara.
  for(const name of ['data','rows','results','payload','message','messages','items','result']){
    const v=payload[name];
    if(v&&typeof v==='object')handleWsPayload(v,depth+1);
  }
}
function startWebSocket(){
  const symbolCount=new Set([...state.scan.map(r=>r.symbol),...Object.keys(state.holdings)]).size;
  if(!symbolCount){setText('scanInfo','WS için sembol yok');return}
  state.wsStopped=false;stopWebSocket(false);
  try{state.ws=new WebSocket(WS_URL)}catch(e){log('WS HATA → '+e.message);scheduleWsReconnect();return}
  state.ws.onopen=()=>{setText('scanInfo',`Tarama ${state.scan.length} | WS login... | Tedbirli ${state.tedbirFilteredCount}`);log('WS → bağlantı açıldı, tokenli login gönderiliyor');wsSend({type:'login',token:String(FINTABLES_WS_TOKEN).replace(/^Bearer\s+/i,'').trim()})};
  state.ws.onmessage=ev=>{
    let msg;try{msg=JSON.parse(ev.data)}catch(_e){return}
    if(msg?.type==='login_success'){
      setText('scanInfo',`Tarama ${state.scan.length} | WS canlı | Tedbirli ${state.tedbirFilteredCount}`);
      log('WS → login başarılı');
      subscribeWsSymbols();
      return;
    }
    if(msg?.type==='subscribe_success'){
      // Fintables ilk A/B/P değerlerini subscribe_success.data içinde gönderiyor.
      // Önce bu fiyat paketini tabloya uygula; ardından abonelik durumunu göster.
      if(Array.isArray(msg.data)) handleWsPayload(msg.data);
      setText('scanInfo',`Tarama ${state.scan.length} | A/B/P abone | Tedbirli ${state.tedbirFilteredCount}`);
      log(`WS → subscribe_success | ilk veri=${Array.isArray(msg.data)?msg.data.length:0}`);
      return;
    }
    handleWsPayload(msg);
  };
  state.ws.onerror=()=>{setText('scanInfo',`Tarama ${state.scan.length} | WS hata | Tedbirli ${state.tedbirFilteredCount}`);log('WS HATA → bağlantı/token kontrol edilmeli')};
  state.ws.onclose=()=>{state.ws=null;setText('scanInfo',`Tarama ${state.scan.length} | WS kapalı | Tedbirli ${state.tedbirFilteredCount}`);log('WS → bağlantı kapandı');scheduleWsReconnect()};
}
async function loadDnaSelection(){
  const r=await fetch(DNA_SELECTION_URL,{cache:'no-store'});
  if(!r.ok)throw new Error(`DNA seçim dosyası okunamadı: HTTP ${r.status}`);
  const j=await r.json();
  if(!Array.isArray(j?.rows)||!j.rows.length)throw new Error('DNA seçim dosyasında hisse yok');
  return j;
}
function addManualScanSymbol(raw){
  const sym=safeSym(raw);
  if(!sym){alert('Geçerli bir hisse kodu girin.');return}
  if(state.holdings[sym]){alert(sym+' zaten Alınanlar tablosunda.');return}
  if(state.scan.some(x=>x.symbol===sym)){alert(sym+' zaten Tarama Tablosunda.');return}
  const row={symbol:sym,V:0,yld3m:NaN,dnaRank:null,dnaScore:NaN,selectionSource:'manual',scanTime:new Date().toISOString(),ask:NaN,bid:NaN,prev:NaN,dayPct:NaN};
  state.scan.push(row);renderScan();
  const input=$('manualSymbol');if(input)input.value='';
  log(`MANUEL TARAMA EKLE → ${sym}`);
  setText('scanInfo',`Tarama ${state.scan.length} | DNA + manuel | WS güncelleniyor...`);
  if(state.ws&&state.ws.readyState===WebSocket.OPEN){
    const topics=[];for(const f of WS_TOPICS)topics.push(sym+'/'+f);wsSend({type:'subscribe',topics});
  }else startWebSocket();
}
async function runOpeningScan(){
  if(state.scanBusy)return;state.scanBusy=true;
  try{
    stopWebSocket(false);state.wsRows={};
    const count=Math.max(1,Math.floor(n($('stockCount').value,100)));
    setText('scanInfo','DNA Top-N seçimi yükleniyor...');
    const dna=await loadDnaSelection();
    const ranked=dna.rows.slice(0,count).map(x=>({symbol:safeSym(x.symbol),V:0,yld3m:NaN,dnaRank:n(x.rank),dnaScore:n(x.score,NaN),selectionSource:'dna'})).filter(x=>x.symbol);
    let blocked=new Set();
    try{const ted=await fetchJsonDirectThenLocal(TEDBIR_URL,'tedbir');blocked=extractTedbirCodes(ted)}catch(e){log('TEDBİR KONTROL UYARI → '+e.message)}
    state.scan=ranked.filter(r=>!blocked.has(r.symbol)).map(r=>({...r,scanTime:new Date().toISOString(),ask:NaN,bid:NaN,prev:NaN,dayPct:NaN}));
    state.tedbirFilteredCount=ranked.length-state.scan.length;
    renderScan();
    setText('scanInfo',`DNA ${dna.algorithm||'HistGBR'} | ${dna.selection_date||''} → Top ${ranked.length} → Tedbir -${state.tedbirFilteredCount} → Tarama ${state.scan.length} | WS açılıyor...`);
    log(`DNA TARAMA → model=${dna.algorithm||'HistGBR DNA'} | seçim tarihi=${dna.selection_date||'?'} | eğitim=${dna.train_from||'?'}..${dna.train_to||'?'} | TopN=${ranked.length} | Tedbir elenen=${state.tedbirFilteredCount}`);
    if(state.scan.length)startWebSocket();
  }catch(e){state.scan=[];state.tedbirFilteredCount=0;renderScan();setText('scanInfo','DNA HATA: '+e.message);log('DNA TARAMA HATA → '+e.message)}
  finally{state.scanBusy=false}
}

function normalizeHolding(raw,meta={}){const symbol=safeSym(raw?.symbol??raw?.code??raw?.ticker??raw?.hisse??raw?.sembol??raw?.stock??raw?.instrument);if(!symbol)return null;const qty=pickNumber(raw,['amount','amountToSell','qty','quantity','adet','piece','lot','lots','size'],0);if(!(qty>0))return null;const cost=pickNumber(raw,['cost','avgCost','averageCost','maliyet','buyPrice','price'],0);const last=pickNumber(raw,['lastPrice','last','currentPrice','current','price','son'],cost);const dayPct=pickNumber(raw,['changePercentage','dayPct','change_percent','gun_pct','gün_pct','pct','dailyChange'],0);return{symbol,qty,cost,last,dayPct,time:meta.updatedAt||new Date().toISOString()}}
function updateStats(){const hs=Object.values(state.holdings);setText('holdingCount',hs.length);setText('soldActiveCount',Array.isArray(state.sold)?state.sold.length:0);const activePs=hs.map(h=>n(h.cost)>0?((n(h.last)-n(h.cost))/n(h.cost)*100):NaN).filter(Number.isFinite),holdingAvg=activePs.length?activePs.reduce((a,b)=>a+b,0)/activePs.length:0;setText('holdingAvg',fmt(holdingAvg));const he=$('holdingAvg');if(he)he.className=pctClass(holdingAvg);const holdingProfitTL=hs.reduce((sum,h)=>sum+(n(h.last)-n(h.cost))*n(h.qty),0);setText('holdingProfitTL',fmt(holdingProfitTL,2));const htl=$('holdingProfitTL');if(htl)htl.className=pctClass(holdingProfitTL);const ps=state.sold.map(x=>n(x.pnlPct)).filter(Number.isFinite),realizedAvg=ps.length?ps.reduce((a,b)=>a+b,0)/ps.length:0;setText('realizedAvg',fmt(realizedAvg));const re=$('realizedAvg');if(re)re.className=pctClass(realizedAvg);const realizedBuyTL=state.sold.reduce((sum,x)=>sum+n(x.buy)*n(x.qty),0),realizedSellTL=state.sold.reduce((sum,x)=>sum+n(x.sell)*n(x.qty),0),realizedProfitTL=realizedSellTL-realizedBuyTL;setText('realizedProfitTL',fmt(realizedProfitTL,2));const rtl=$('realizedProfitTL');if(rtl)rtl.className=pctClass(realizedProfitTL);updateDailyTradeVolumeDisplay();updateDailyPerformance()}
function sortHoldValue(h,key){if(key==='symbol'||key==='signal')return key==='signal'?holdingSignal(h.symbol):String(h.symbol);if(key==='cost')return n(h.cost,NaN);if(key==='dayPct')return n(h.dayPct,NaN);if(key==='pnl')return h.cost>0?((n(h.last)-h.cost)/h.cost*100):NaN;if(key==='rsi')return indicatorFor(h.symbol).rsi;if(key==='time')return timeNumeric(h.time);return 0}
function renderHoldings(){const tb=$('holdingsTable').querySelector('tbody');tb.innerHTML='';let rows=Object.values(state.holdings);rows.sort((a,b)=>{const k=state.holdSort.key,d=state.holdSort.dir,av=sortHoldValue(a,k),bv=sortHoldValue(b,k);if(k==='symbol'||k==='signal')return d*String(av).localeCompare(String(bv),'tr');return d*((Number.isFinite(av)?av:-Infinity)-(Number.isFinite(bv)?bv:-Infinity))});for(const h of rows){const pnl=h.cost>0?((n(h.last)-h.cost)/h.cost*100):0,ind=indicatorFor(h.symbol);const tr=document.createElement('tr');tr.dataset.symbol=h.symbol;tr.innerHTML=`<td>${symbolLink(h.symbol)}</td><td class="num">${fmt(h.qty,0)}</td><td class="num">${fmt(h.cost)}</td><td class="num js-h-last">${fmt(h.last)}</td><td class="num js-h-day ${pctClass(h.dayPct)}">${fmt(h.dayPct,4)}%</td><td class="num">${fmt(n(h.qty)*n(h.cost))}</td><td class="num js-h-tl">${fmt(n(h.last)*n(h.qty))}</td><td class="num js-h-pnl ${pctClass(pnl)}">${fmt(pnl,4)}%</td><td class="num js-h-rsi">${Number.isFinite(ind.rsi)?fmt(ind.rsi,2):'—'}</td><td class="js-h-signal">${holdingSignal(h.symbol)}</td><td><button class="danger" data-sell="${h.symbol}">SAT</button></td><td class="time-col">${displayTime(h.buyTime||h.time)}</td>`;tb.appendChild(tr)}tb.querySelectorAll('[data-sell]').forEach(b=>b.onclick=()=>manualSell(b.dataset.sell));updateStats()}
function renderSold(){const tb=$('soldTable').querySelector('tbody');tb.innerHTML='';let rows=[...state.sold];rows.sort((a,b)=>{const k=state.soldSort.key,d=state.soldSort.dir;if(k==='symbol')return d*String(a.symbol).localeCompare(String(b.symbol),'tr');if(k==='pnl')return d*(n(a.pnlPct)-n(b.pnlPct));if(k==='time')return d*(timeNumeric(a.time)-timeNumeric(b.time));return 0});for(const x of rows){const tr=document.createElement('tr');tr.innerHTML=`<td>${x.symbol}</td><td class="num">${fmt(x.qty,0)}</td><td class="num">${fmt(x.buy)}</td><td class="num">${fmt(x.sell)}</td><td class="num">${fmt(x.buy*n(x.qty))}</td><td class="num">${fmt(x.sell*n(x.qty))}</td><td class="num ${pctClass(x.pnlPct)}">${fmt(x.pnlPct)}%</td><td class="time-col">${displayTime(x.buyTime||'')}</td><td class="time-col">${displayTime(x.sellTime||x.time)}</td>`;tb.appendChild(tr)}updateStats()}
function renderOrders(){const table=$('ordersTable');if(!table)return;const tb=table.querySelector('tbody');tb.innerHTML='';for(const o of state.dailyOrders){const sym=safeSym(o.symbol??o.Stock??o.stock);const side=String(o.side??o.BuySell??o.buySell??'');const qty=pickNumber(o,['size','amount','Amount','quantity'],0);const price=pickNumber(o,['price','Price'],0);const status=String(o.status??o.Status??o.INFOMSG??o.MSG??'');const ref=String(o.RefNo??o.IMKBRefNo??o.refNo??'');const time=o.time??o.OrderDate??o.dateTime??'';const tr=document.createElement('tr');tr.innerHTML=`<td>${displayTime(time)}</td><td>${sym}</td><td>${side}</td><td class="num">${fmt(qty,0)}</td><td class="num">${fmt(price)}</td><td>${status}</td><td>${ref}</td>`;tb.appendChild(tr)}}

async function ziraatApi(name,body={}){const opt={cache:'no-store'};if(body&&Object.keys(body).length){opt.method='POST';opt.headers={'Content-Type':'application/json'};opt.body=JSON.stringify(body)}const r=await fetch(ZIRAAT_API_ENDPOINT+encodeURIComponent(name),opt);const t=await r.text();try{return JSON.parse(t)}catch(e){throw new Error('JSON olmayan cevap: '+t.slice(0,160))}}
async function ziraatCheckStatus(){try{const s=await ziraatApi('ziraat_status');if(!s?.session_exists){setText('ziraatLoginState','Giriş Yapılmadı');return{session_exists:false}}const probe=await ziraatApi('ziraat_portfolio',{});const ok=!!probe?.ok;setText('ziraatLoginState',ok?'Giriş Yapıldı':'Giriş Yapılmadı');return{session_exists:ok,portfolio:ok?probe:null,error:ok?'':(probe?.error||probe?.INFOMSG||probe?.message||'Oturum doğrulanamadı')}}catch(e){setText('ziraatLoginState','Giriş Yapılmadı');return{session_exists:false,error:e.message}}}
async function ziraatStartLogin(){const account=$('ziraatAccount').value.trim(),password=$('ziraatPassword').value,subaccount=$('ziraatSubaccount').value.trim()||'100';if(!account||!password){setText('ziraatLoginMsg','Kullanıcı adı ve şifre zorunlu.');return}setText('ziraatLoginMsg','SMS isteniyor...');try{const j=await ziraatApi('ziraat_login_start',{account,username:account,password,subaccount});if(j?.ok){hide('ziraatLoginModal');setText('ziraatOtpMsg',j.INFOMSG||j.message||'SMS kodunu girin.');show('ziraatOtpModal')}else setText('ziraatLoginMsg',j?.error||j?.INFOMSG||j?.message||'Giriş başlatılamadı.')}catch(e){setText('ziraatLoginMsg',e.message)}}
async function ziraatSendOtp(){const otp=$('ziraatOtp').value.trim(),subaccount=$('ziraatSubaccount').value.trim()||'100';if(!otp){setText('ziraatOtpMsg','SMS kodu zorunlu.');return}setText('ziraatOtpMsg','Oturum açılıyor...');try{const j=await ziraatApi('ziraat_login_otp',{otp,subaccount});if(j?.ok){hide('ziraatOtpModal');setText('ziraatLoginState','Giriş Yapıldı');log('ZİRAAT GİRİŞ → Oturum açıldı');await ziraatFetchPortfolio(true);await ziraatFetchDailyOrders(true)}else{setText('ziraatLoginState','Giriş Yapılmadı');setText('ziraatOtpMsg',j?.error||j?.message||j?.INFOMSG||'SMS doğrulanamadı.')}}catch(e){setText('ziraatOtpMsg',e.message)}}
async function ziraatFetchPortfolio(auto=false){const st=await ziraatCheckStatus();if(!st.session_exists){setText('ziraatLoginState','Giriş Yapılmadı');if(!auto)show('ziraatLoginModal');return}try{const j=st.portfolio||await ziraatApi('ziraat_portfolio',{});if(!j?.ok)throw new Error(j?.error||j?.INFOMSG||j?.message||'Portföy alınamadı');const mapped={};let t2=state.t2;for(const raw of (j.items||[])){const rs=safeSym(raw?.symbol??raw?.code??raw?.ticker??raw?.hisse??raw?.sembol??raw?.stock??raw?.instrument);if(rs==='TRY'){t2=pickNumber(raw,['amount','amountToSell','qty','quantity','adet','piece','lot','lots','size','value','tutar','balance','volume'],t2);continue}const it=normalizeHolding(raw,{updatedAt:j.updatedAt});if(it){mapped[it.symbol]=it}}state.holdings=mapped;state.t2=t2;renderHoldings();if(state.ws&&state.ws.readyState===WebSocket.OPEN)subscribeWsSymbols();else if(Object.keys(state.holdings).length||state.scan.length)startWebSocket();setText('ziraatLoginState','Giriş Yapıldı');log(`ZİRAAT PORTFÖY → ${Object.keys(mapped).length} hisse aktarıldı | T2=${fmt(t2)}`)}catch(e){setText('ziraatLoginState','Giriş Yapılmadı');if(!auto)alert(e.message);log('ZİRAAT PORTFÖY HATA → '+e.message)}}
async function ziraatFetchDailyOrders(auto=false){try{const j=await ziraatApi('ziraat_daily_orders',{});if(!j?.ok)throw new Error(j?.error||j?.message||'Günlük emirler alınamadı');state.dailyOrders=Array.isArray(j.orders)?j.orders:(Array.isArray(j.items)?j.items:[]);renderOrders();log(`ZİRAAT EMİRLER → ${state.dailyOrders.length} kayıt`)}catch(e){if(!auto)alert(e.message);log('ZİRAAT EMİRLER HATA → '+e.message)}}
function investedCostTL(){return Object.values(state.holdings).reduce((sum,h)=>sum+n(h.cost)*n(h.qty),0)}
async function executeBuy(sym,reason,isAuto=false){sym=safeSym(sym);if(state.entryLocks.has(sym)||state.holdings[sym])return;const r=state.scan.find(x=>x.symbol===sym);if(!r)return;const price=n(r.ask);if(!(price>0)){if(!isAuto)alert(sym+' için geçerli Ask fiyatı henüz gelmedi.');return}const amount=Math.max(0,n($('buyAmount').value,9000)),limit=Math.max(0,n($('totalLimit').value,100000)),qty=Math.floor(amount/price);if(qty<1){if(!isAuto)alert('AL Tutarı 1 lot almaya yetmiyor.');return}const orderTL=qty*price,currentTL=investedCostTL();if(limit>0&&currentTL+orderTL>limit+1e-9){log(`${isAuto?'OTO-AL':'AL'} ENGEL → ${sym} | toplam limit`);return}if(!isAuto&&!confirm(`${sym} ${qty} adet ${fmt(price)} Ask fiyattan AL emri gönderilsin mi?
Tutar: ${fmt(orderTL)} TL`))return;state.entryLocks.add(sym);const dry=$('paperMode').checked;try{const j=await ziraatApi('ziraat_order',{symbol:sym,side:'B',price:String(price),size:String(qty),dry_run:dry});if(!j?.ok)throw new Error(j?.error||j?.INFOMSG||j?.message||'AL emri başarısız');addDailyTradeVolume(orderTL);const buyNow=new Date().toISOString();const h={symbol:sym,qty,cost:price,last:Number.isFinite(r.bid)?r.bid:price,ask:price,prev:Number.isFinite(r.prev)?r.prev:NaN,dayPct:Number.isFinite(r.dayPct)?r.dayPct:0,time:buyNow,buyTime:buyNow,buyReason:reason||'—',source:dry?'paper':'order',scanV:n(r.V,0),scanY:n(r.yRaw,0)};state.holdings[sym]=h;state.trail[sym]={armed:false,peak:0};state.scan=state.scan.filter(x=>x.symbol!==sym);renderScan();renderHoldings();log(`${dry?'PAPER':'GERÇEK'} ${isAuto?'OTO-AL':'AL'} → ${sym} x ${qty} @ Ask ${fmt(price)} | ${reason||''}`);subscribeWsSymbols();if(!dry)await ziraatFetchDailyOrders(true)}catch(e){log(`${isAuto?'OTO-AL':'AL'} HATA → ${sym} | ${e.message}`)}finally{state.entryLocks.delete(sym)}}
async function manualBuy(sym){return executeBuy(sym,'Manuel AL',false)}
async function autoBuyStrategy(sym,reason){return executeBuy(sym,reason,true)}
async function executeSell(sym,reason,isAuto=false){const h=state.holdings[sym];if(!h||state.sellLocks.has(sym))return;const qty=Math.floor(n(h.qty)),price=n(h.last)>0?n(h.last):n(h.cost);if(!(qty>0&&price>0))return;if(!isAuto&&!confirm(`${sym} ${qty} adet ${fmt(price)} Bid fiyattan SAT emri gönderilsin mi?`))return;state.sellLocks.add(sym);const dry=$('paperMode').checked;try{const j=await ziraatApi('ziraat_order',{symbol:sym,side:'S',price:String(price),size:String(qty),dry_run:dry});if(!j?.ok)throw new Error(j?.error||j?.INFOMSG||j?.message||'SAT emri başarısız');addDailyTradeVolume(price*qty);const pnl=h.cost>0?((price-h.cost)/h.cost*100):0;const sellNow=new Date().toISOString();state.sold.unshift({time:sellNow,buyTime:h.buyTime||h.time||'',sellTime:sellNow,symbol:sym,qty,buy:h.cost,sell:price,pnlPct:pnl,buyReason:h.buyReason||'—',sellReason:reason||'—',reason});delete state.holdings[sym];delete state.trail[sym];restoreScanFromHolding(h);renderHoldings();renderSold();log(`${dry?'PAPER':'GERÇEK'} ${isAuto?'OTO-SAT':'SAT'} → ${sym} x ${qty} @ Bid ${fmt(price)} | KAR% ${fmt(pnl,4)} | ${reason||''}`);if(!dry){await ziraatFetchDailyOrders(true);await ziraatFetchPortfolio(true)}}catch(e){log(`${isAuto?'OTO-SAT':'SAT'} HATA → ${sym} | ${e.message}`)}finally{state.sellLocks.delete(sym)}}
async function manualSell(sym){return executeSell(sym,'Manuel SAT',false)}
async function autoSellStrategy(sym,reason){return executeSell(sym,reason,true)}

async function saveState(){const payload={saved_at:new Date().toISOString(),settings:{paperMode:$('paperMode').checked,autoBuy:$('autoBuy').checked,autoSell:$('autoSell').checked,buyAmount:n($('buyAmount').value,9000),totalLimit:n($('totalLimit').value,100000),evalMinPct:n($('evalMinPct').value,-2),evalMaxPct:n($('evalMaxPct').value,3),rsiPeriod:Math.max(2,Math.floor(n($('rsiPeriod').value,14))),rsiBuy:n($('rsiBuy').value,25),trailActivation:Math.max(0,n($('trailActivation').value,2.0)),trailDistance:Math.max(0,n($('trailDistance').value,0.1)),threeMonthMinPct:n($('threeMonthMinPct').value,-100),threeMonthMaxPct:n($('threeMonthMaxPct').value,100),stockCount:Math.max(1,Math.floor(n($('stockCount').value,20)))},holdings:state.holdings,sold:state.sold,t2:state.t2,candles:state.candles,trail:state.trail};try{const r=await fetch(SETTINGS_ENDPOINT+'save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});const j=await r.json();if(!j.ok)throw new Error(j.error||'Kayıt başarısız');log('KAYDET → portföy ve strateji durumu kaydedildi')}catch(e){alert(e.message)}}
async function loadState(){try{const r=await fetch(SETTINGS_ENDPOINT+'load',{cache:'no-store'}),j=await r.json();if(!j.ok)throw new Error(j.error||'Yükleme başarısız');if(!j.data)return;const p=j.data;if(typeof p.settings?.paperMode==='boolean')$('paperMode').checked=p.settings.paperMode;if(typeof p.settings?.autoBuy==='boolean')$('autoBuy').checked=p.settings.autoBuy;if(typeof p.settings?.autoSell==='boolean')$('autoSell').checked=p.settings.autoSell;const vals={buyAmount:[9000],totalLimit:[100000],evalMinPct:[-2],evalMaxPct:[3],rsiPeriod:[14],rsiBuy:[25],trailActivation:[2.0],trailDistance:[0.1],threeMonthMinPct:[-100],threeMonthMaxPct:[100],stockCount:[100]};for(const [id,[def]] of Object.entries(vals))if(p.settings?.[id]!=null&&$(id))$(id).value=n(p.settings[id],def);state.holdings=p.holdings&&typeof p.holdings==='object'?p.holdings:{};state.sold=Array.isArray(p.sold)?p.sold:[];state.t2=n(p.t2);state.candles=p.candles&&typeof p.candles==='object'?p.candles:{};state.trail=p.trail&&typeof p.trail==='object'?p.trail:{};renderHoldings();renderSold();recalculateDailyTradeVolumeFromTables();log('YÜKLE → kayıtlı durum yüklendi')}catch(e){log('YÜKLE HATA → '+e.message)}}
async function saveSoldByDate(){const date=$('soldDate').value;if(!date){alert('Tarih seçin.');return}try{const r=await fetch(`?sold=save&date=${encodeURIComponent(date)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sold:state.sold})});const j=await r.json();if(!j.ok)throw new Error(j.error||'Satılanlar kaydedilemedi');log(`SATILANLAR KAYDET → ${date} | ${j.count} kayıt | ${j.file}`)}catch(e){alert(e.message);log('SATILANLAR KAYDET HATA → '+e.message)}}
async function loadSoldByDate(){const date=$('soldDate').value;if(!date){alert('Tarih seçin.');return}try{const r=await fetch(`?sold=load&date=${encodeURIComponent(date)}`,{cache:'no-store'});const j=await r.json();if(!j.ok)throw new Error(j.error||'Satılanlar yüklenemedi');state.sold=(Array.isArray(j.sold)?j.sold:[]).map(x=>({...x,buyTime:x?.buyTime||'',sellTime:x?.sellTime||x?.time||'',time:x?.sellTime||x?.time||''}));renderSold();recalculateDailyTradeVolumeFromTables();log(`SATILANLAR YÜKLE → ${date} | ${state.sold.length} kayıt`)}catch(e){alert(e.message);log('SATILANLAR YÜKLE HATA → '+e.message)}}

async function saveHoldingsByDate(){const date=$('holdingDate').value;if(!date){alert('Tarih seçin.');return}try{const rows=Object.values(state.holdings||{}).filter(h=>h&&safeSym(h.symbol)).map(h=>{const buyTime=h.buyTime||h.time||new Date().toISOString();return {...h,buyTime,time:buyTime}});const r=await fetch(`?holdings=save&date=${encodeURIComponent(date)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({holdings:rows})});const j=await r.json();if(!j.ok)throw new Error(j.error||'Alınanlar kaydedilemedi');log(`ALINANLAR KAYDET → ${date} | ${j.count} kayıt | ${j.file}`)}catch(e){alert(e.message);log('ALINANLAR KAYDET HATA → '+e.message)}}
async function loadHoldingsByDate(){const date=$('holdingDate').value;if(!date){alert('Tarih seçin.');return}try{const r=await fetch(`?holdings=load&date=${encodeURIComponent(date)}`,{cache:'no-store'});const j=await r.json();if(!j.ok)throw new Error(j.error||'Alınanlar yüklenemedi');const mapped={};for(const h of (Array.isArray(j.holdings)?j.holdings:Object.values(j.holdings||{}))){const sym=safeSym(h?.symbol);if(sym){const buyTime=h?.buyTime||h?.time||'';mapped[sym]={...h,symbol:sym,buyTime,time:buyTime}}}state.holdings=mapped;state.trail={};renderHoldings();recalculateDailyTradeVolumeFromTables();if(state.ws&&state.ws.readyState===WebSocket.OPEN)subscribeWsSymbols();else if(Object.keys(state.holdings).length||state.scan.length)startWebSocket();log(`ALINANLAR YÜKLE → ${date} | ${Object.keys(state.holdings).length} kayıt`)}catch(e){alert(e.message);log('ALINANLAR YÜKLE HATA → '+e.message)}}
async function saveLogs(){try{const r=await fetch(LOGS_ENDPOINT,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({logs:state.logs})}),j=await r.json();if(!j.ok)throw new Error(j.error||'Log kaydı başarısız');log(`LOG → ${j.file}`)}catch(e){alert(e.message)}}
function resetScreen(){state.holdings={};state.trail={};state.candles={};state.sold=[];state.dailyOrders=[];state.t2=0;renderHoldings();renderSold();renderOrders();recalculateDailyTradeVolumeFromTables();log('EKRAN → sıfırlandı')}

$('btnManualAdd').onclick=()=>addManualScanSymbol($('manualSymbol').value);$('manualSymbol').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();addManualScanSymbol($('manualSymbol').value)}});$('btnZiraatLogin').onclick=()=>show('ziraatLoginModal');$('btnLoginClose').onclick=()=>hide('ziraatLoginModal');$('btnOtpClose').onclick=()=>hide('ziraatOtpModal');$('btnLoginStart').onclick=ziraatStartLogin;$('btnOtpSend').onclick=ziraatSendOtp;$('btnPortfolio').onclick=()=>ziraatFetchPortfolio(false);$('btnDailyOrders').onclick=()=>ziraatFetchDailyOrders(false);$('btnSave').onclick=saveState;$('btnLoad').onclick=loadState;$('btnSaveLogs').onclick=saveLogs;$('btnReset').onclick=resetScreen;$('btnSoldSave').onclick=saveSoldByDate;$('btnSoldLoad').onclick=loadSoldByDate;$('btnHoldingSave').onclick=saveHoldingsByDate;$('btnHoldingLoad').onclick=loadHoldingsByDate;
document.querySelectorAll('[data-scan-sort]').forEach(th=>th.onclick=()=>{const key=th.dataset.scanSort;if(state.scanSort.key===key)state.scanSort.dir*=-1;else state.scanSort={key,dir:1};renderScan()});
document.querySelectorAll('[data-hold-sort]').forEach(th=>th.onclick=()=>{const key=th.dataset.holdSort;if(state.holdSort.key===key)state.holdSort.dir*=-1;else state.holdSort={key,dir:1};renderHoldings()});
document.querySelectorAll('[data-sold-sort]').forEach(th=>th.onclick=()=>{const key=th.dataset.soldSort;if(state.soldSort.key===key)state.soldSort.dir*=-1;else state.soldSort={key,dir:1};renderSold()});
(function(){const d=new Date(),pad=x=>String(x).padStart(2,'0'),today=`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;$('soldDate').value=today;$('holdingDate').value=today;state.dailyTradeDate=today;state.dailyTradeVolumeTL=0;updateDailyTradeVolumeDisplay();updateDailyPerformance()})();
async function portfoyStart(){await loadState();recalculateDailyTradeVolumeFromTables();await runOpeningScan();await ziraatCheckStatus();}
</script>
<div class="modal" id="fintablesModal"><div class="modal-card"><h3>Fintables Bağlantı</h3><p class="muted">Kendi yetkili veri anahtarınızı girin. A/B/P akışı orijinal Fintables WebSocket bağlantısını kullanır.</p><div class="field"><label>Veri Anahtarı</label><input id="fintablesToken" type="password" autocomplete="off"></div><div id="fintablesMsg" class="tiny muted"></div><div class="btnrow"><button class="primary" id="btnFintablesConnect">Bağlan</button><button id="btnFintablesClose">Kapat</button></div></div></div>
<script src="strateji_baglanti.js"></script>
<script>
if(window.PORTFOY_ALGO_READY){portfoyStart();}
else{
  $('autoBuy').checked=false;$('autoSell').checked=false;$('autoBuy').disabled=true;$('autoSell').disabled=true;
  executeBuy=async()=>log('AL kapalı: algoritma dosyaları eksik veya yüklenemedi.');
  executeSell=async()=>log('SAT kapalı: algoritma dosyaları eksik veya yüklenemedi.');
  onClosedCandle=()=>{};strategyOnBid=()=>{};
  setText('scanInfo','Algoritma dosyaları yüklenemedi. ZIP içindeki bütün dosyaları kopyalayın.');
}
</script>
</body></html>
