<?php
// Kendi yetkili Fintables anahtarinizi ekrandaki Fintables dugmesinden girebilirsiniz.
// Alternatif olarak yerel FINTABLES_WS_TOKEN ortam degiskeni kullanilabilir.
// Bu dosyaya anahtar eklerseniz dosyayi GitHub'a yuklemeyin.
return ['token'=>getenv('FINTABLES_WS_TOKEN')?:''];
