(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('./gostergeler.js'));else root.PortfoyAlgoritma=factory(root.Portfoy);})(typeof globalThis!=='undefined'?globalThis:this,function(P){
  'use strict';
  function options(raw){
    const c={...raw};
    for(const [key,value] of Object.entries(c))if(typeof value!=='number'||!Number.isFinite(value)||value<=0)throw new Error('Algoritma ayarı geçersiz: '+key);
    for(const key of ['riskPerTradePct','maxPortfolioRiskPct','maxPositionPct','maxExposurePct','hardStopPct','maxStopPct','maxSpreadPct','maxDailyLossPct','maxDrawdownPct','slippagePct'])if(c[key]>=100)throw new Error('Yüzde 0..100 aralığında olmalı: '+key);
    if(c.hardStopPct>c.maxStopPct)throw new Error('Stop aralığı geçersiz.');
    return c;
  }
  function entry(bars,ui,c){
    const result=P.signal(bars,{rsiPeriod:ui.rsiPeriod,rsiRecovery:ui.rsiBuy,trendPeriod:c.trendPeriod,warmupBars:c.warmupBars});
    return {...result,signal:result.buy?'AL':result.reason};
  }
  function fresh(q,side,now,c){return !!q&&Number.isFinite(q[side])&&q[side]>0&&Number.isFinite(q[side+'At'])&&now-q[side+'At']>=0&&now-q[side+'At']<=c.quoteMaxAgeMs;}
  function plan({quote,capital,equity,invested,openRisk=0,cash=Infinity,buyAmount,totalLimit,positions,atr,commissionRate,now},c){
    if(!fresh(quote,'ask',now,c)||!fresh(quote,'bid',now,c))return {ok:false,reason:'GÜNCEL A/B FİYATI YOK'};
    if(quote.ask<quote.bid||(quote.ask/quote.bid-1)*100>c.maxSpreadPct)return {ok:false,reason:'SPREAD SINIRI'};
    if(positions>=c.maxPositions)return {ok:false,reason:'POZİSYON SAYISI SINIRI'};
    if(![capital,equity,invested,buyAmount,totalLimit,commissionRate].every(Number.isFinite)||capital<=0||equity<=0||buyAmount<=0||totalLimit<=0||commissionRate<0||commissionRate>=1)return {ok:false,reason:'SERMAYE AYARI GEÇERSİZ'};
    const execution=quote.ask*(1+c.slippagePct/100);
    const stopPct=Math.max(c.hardStopPct/100,Number.isFinite(atr)&&atr>0?atr*c.atrStopMultiple/execution:0);
    if(stopPct>c.maxStopPct/100)return {ok:false,reason:'ATR RİSK SINIRI'};
    const stop=execution*(1-stopPct),perLotRisk=execution-stop+execution*commissionRate+stop*(commissionRate+c.slippagePct/100);
    const budget=Math.max(0,Math.min(buyAmount,equity*c.maxPositionPct/100,totalLimit-invested,equity*c.maxExposurePct/100-invested,cash/(1+commissionRate)));
    const riskBudget=Math.max(0,Math.min(equity*c.riskPerTradePct/100,equity*c.maxPortfolioRiskPct/100-openRisk));
    const qty=Math.floor(Math.min(riskBudget/perLotRisk,budget/execution));
    if(qty<1)return {ok:false,reason:'NAKİT / RİSK LİMİTİ'};
    return {ok:true,qty,price:quote.ask,paperPrice:execution,stop,atr:Number.isFinite(atr)?atr:0,plannedRisk:qty*perLotRisk};
  }
  function exit(position,previous,bid,ui,c,now,commissionRate){
    if(!Number.isFinite(bid)||bid<=0||!(position.cost>0))return {state:previous,reason:null};
    const t={...(previous||{})},atr=Number.isFinite(position.entryAtr)?position.entryAtr:0;
    const initialStop=position.initialStop>0?position.initialStop:position.cost*(1-c.hardStopPct/100);
    t.stop=Math.max(Number(t.stop)||0,initialStop);t.peak=Math.max(Number(t.peak)||0,bid);t.armed=!!t.armed;
    // Existing stop first: a gap never fills at the old stop or at cost.
    if(bid<=t.stop)return {state:t,reason:t.armed?'ATR_TRAILING':'ZARAR_DURDUR'};
    const opened=Date.parse(position.buyTime||position.time||'');
    if(Number.isFinite(opened)&&now-opened>=c.maxHoldingHours*3600000)return {state:t,reason:'SÜRE_ÇIKIŞI'};
    const netReturn=(bid*(1-c.slippagePct/100)*(1-commissionRate)/(position.cost*(1+commissionRate))-1)*100;
    if(netReturn>=ui.trailActivation)t.armed=true;
    if(t.armed){
      const distance=Math.max(ui.trailDistance/100,atr*c.atrTrailMultiple/t.peak);
      const breakEven=position.cost*(1+commissionRate)/((1-c.slippagePct/100)*(1-commissionRate));
      t.stop=Math.max(t.stop,t.peak*(1-distance),breakEven);
    }
    return {state:t,reason:bid<=t.stop?'ATR_TRAILING':null};
  }
  function limits({equity,capital,previous,day},c){
    const s={...(previous||{})};
    if(!Number.isFinite(equity)||!Number.isFinite(capital)||equity<=0||capital<=0)return {blocked:true,reason:'SERMAYE HESAPLANAMADI',state:s};
    if(!Number.isFinite(s.peak))s.peak=capital;
    if(s.day!==day){s.day=day;s.dayStart=Number.isFinite(s.lastEquity)?s.lastEquity:capital;s.dailyBlocked=false;}
    s.peak=Math.max(s.peak,equity);s.lastEquity=equity;
    s.dailyBlocked=!!s.dailyBlocked||equity<=s.dayStart*(1-c.maxDailyLossPct/100);
    s.drawdownBlocked=!!s.drawdownBlocked||equity<=s.peak*(1-c.maxDrawdownPct/100);
    return {state:s,blocked:s.dailyBlocked||s.drawdownBlocked,reason:s.drawdownBlocked?'AZAMİ DÜŞÜŞ':s.dailyBlocked?'GÜNLÜK KAYIP':''};
  }
  return {options,entry,fresh,plan,exit,limits};
});
