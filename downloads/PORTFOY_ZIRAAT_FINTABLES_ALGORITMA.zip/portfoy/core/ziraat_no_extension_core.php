<?php

function zrx_config(): array {
    $cfgFile = dirname(__DIR__) . '/config_ziraat.php';
    $cfg = is_file($cfgFile) ? require $cfgFile : [];
    return array_merge([
        'default_subaccount' => '100',
        'trade_url' => 'https://trade.ziraatyatirim.com.tr/',
        'after_hours_limit_tl' => 1000,
        'order_debug' => false,
    ], is_array($cfg) ? $cfg : []);
}
function zrx_data_dir(): string { $dir = PORTFOY_DATA_DIR; if(!is_dir($dir)) mkdir($dir,0700,true); return $dir; }
function zrx_session_file(): string { return zrx_data_dir() . '/ziraat_session.json'; }
function zrx_pending_file(): string { return zrx_data_dir() . '/ziraat_pending_login.json'; }
function zrx_template_file(): string { return zrx_data_dir() . '/order_template.json'; }
function zrx_last_order_file(): string { return zrx_data_dir() . '/last_order_debug.json'; }
function zrx_orders_log_file(): string { return zrx_data_dir() . '/orders_log.json'; }
function zrx_read(string $file, $default=null){ if(!is_file($file)) return $default; $j=json_decode((string)file_get_contents($file), true); return is_array($j)?$j:$default; }
function zrx_write(string $file, array $data): bool {
    if(!is_dir(dirname($file))) mkdir(dirname($file),0700,true);
    $tmp=tempnam(dirname($file),'zrx-');
    try { return file_put_contents($tmp,json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR))!==false && chmod($tmp,0600) && rename($tmp,$file); }
    finally { if(is_file($tmp)) unlink($tmp); }
}
function zrx_xml_tag(string $xml, string $tag): string { if(preg_match('~<'.preg_quote($tag,'~').'\b[^>]*>(.*?)</'.preg_quote($tag,'~').'>~is',$xml,$m)) return html_entity_decode(trim(strip_tags($m[1])), ENT_QUOTES|ENT_XML1, 'UTF-8'); return ''; }
function zrx_mask(string $v): string { if($v==='') return ''; if(strlen($v)<=4) return str_repeat('*',strlen($v)); return substr($v,0,2).str_repeat('*',strlen($v)-4).substr($v,-2); }
function zrx_norm_fx(string $body): string { return trim(preg_replace('~^/FX_Trade&1234&~i','',trim($body))); }
function zrx_payload(string $fx): string { return '/FX_Trade&1234&'.zrx_norm_fx($fx); }
if (!function_exists('zrx_curl_post')) {
function zrx_curl_post(string $url, string $body, array $headers=[], int $timeout=25): array {
    if (!function_exists('curl_init')) return ['body'=>'','error'=>'PHP cURL etkin değil. php.ini içinde curl uzantısını etkinleştirip Apache yeniden başlatılmalı.','http_code'=>0];
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_POST=>true, CURLOPT_POSTFIELDS=>$body, CURLOPT_RETURNTRANSFER=>true, CURLOPT_HTTPHEADER=>$headers, CURLOPT_TIMEOUT=>$timeout, CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_SSL_VERIFYHOST=>2]);
    $res = curl_exec($ch); $err = curl_error($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    return ['body'=>$res===false?'':(string)$res, 'error'=>$err, 'http_code'=>$code];
}
}
function zrx_build_login_xml(array $s): string {
    $e = fn($v)=>htmlspecialchars((string)$v, ENT_XML1|ENT_QUOTES, 'UTF-8');
    return '<login><account>'.$e($s['account']??'').'</account><username>'.$e($s['username']??'').'</username><password>'.$e($s['sessionPassword']??'').'</password><subaccount>'.$e($s['subaccount']??'100').'</subaccount><extraInfo>'.$e($s['extraInfo']??'').'</extraInfo><token>'.$e($s['token']??'').'</token><vendor>'.$e($s['vendor']??'WEBCLIENT').'</vendor><ip/></login>';
}
function zrx_datetime(): string { return date('Ymdhis'); }
function zrx_builtin_order_template(): array {
    return ['time'=>date('Y-m-d H:i:s'),'url'=>'built-in/no-extension/v57','type'=>'Order','body'=>'<FxTrade><trader><traderName>ZIRAAT</traderName></trader><login><account></account><username></username><password></password><subaccount>100</subaccount><extraInfo></extraInfo><token></token><vendor>WEBCLIENT</vendor><ip/></login><request><type>Order</type><stock>TEST</stock><amount>1</amount><price>1</price><buySell>A</buySell><dateTime></dateTime></request></FxTrade>'];
}
function zrx_ensure_template(): array { $f=zrx_template_file(); $tpl=zrx_read($f); if($tpl && !empty($tpl['body'])) return ['created'=>false,'template'=>$tpl,'file'=>$f]; $tpl=zrx_builtin_order_template(); zrx_write($f,$tpl); return ['created'=>true,'template'=>$tpl,'file'=>$f]; }

function zrx_slim_order_record(array $r): array {
    $keep=['time','RefNo','IMKBRefNo','symbol','side','price','size','MSG','ERROR_ID','INFOMSG','ok','dry_run','http_code','curl_error','status'];
    $out=[];
    foreach($keep as $k){ if(array_key_exists($k,$r)) $out[$k]=$r[$k]; }
    return $out;
}

function zrx_parse_ref(string $xml): string { $info=zrx_xml_tag($xml,'INFOMSG'); if(preg_match('~Referans Numaranız:\s*([A-Za-z0-9_-]+)~u',$info,$m)) return $m[1]; if(preg_match('~\b(FO[A-Za-z0-9_-]{3,})\b~u',$info,$m)) return $m[1]; return ''; }
function zrx_status(): array { $s=zrx_read(zrx_session_file()); return ['ok'=>true,'session_exists'=>(bool)$s,'session'=>$s?['account'=>$s['account']??'','username'=>$s['username']??'','subaccount'=>$s['subaccount']??'','extraInfo'=>zrx_mask((string)($s['extraInfo']??'')),'token'=>zrx_mask((string)($s['token']??'')),'updatedAt'=>$s['updatedAt']??'']:null]; }
function zrx_login_start(array $in): array {
    $cfg=zrx_config(); $account=trim((string)($in['account']??'')); $username=trim((string)($in['username']??$account)); $password=(string)($in['password']??''); $sub=trim((string)($in['subaccount']??$cfg['default_subaccount']));
    if($account==='' || !preg_match('/^[0-9A-Za-z._-]{3,32}$/',$account)) return ['ok'=>false,'error'=>'Geçerli kullanıcı/müşteri no zorunlu.'];
    if($password==='') return ['ok'=>false,'error'=>'Şifre zorunlu.'];
    $e=fn($v)=>htmlspecialchars((string)$v, ENT_XML1|ENT_QUOTES, 'UTF-8');
    $fx='<FxTrade><trader><traderName>ZIRAAT</traderName></trader><login><account>'.$e($account).'</account><username>'.$e($username).'</username><password>'.$e($password).'</password><subaccount>'.$e($sub).'</subaccount><extraInfo/><token/><vendor>WEBCLIENT</vendor><ip/></login><request><type>LoginStep1</type></request></FxTrade>';
    $r=zrx_curl_post($cfg['trade_url'], zrx_payload($fx), ['Content-Type: text/plain','Accept: text/plain, */*; q=0.01','Origin: https://pro.ziraatyatirim.com.tr','Referer: https://pro.ziraatyatirim.com.tr/']);
    $token=zrx_xml_tag($r['body'],'TOKEN'); $msg=zrx_xml_tag($r['body'],'MSG'); $err=zrx_xml_tag($r['body'],'ERROR_ID'); $info=zrx_xml_tag($r['body'],'INFOMSG');
    $ok=($r['error']==='' && strtoupper($msg)==='SUCCESS' && $token!=='');
    if($ok) zrx_write(zrx_pending_file(), ['account'=>$account,'username'=>$username,'password'=>$password,'subaccount'=>$sub,'token'=>$token,'vendor'=>'WEBCLIENT','createdAt'=>date('Y-m-d H:i:s')]);
    return ['ok'=>$ok,'message'=>$ok?'SMS gönderildi.':'SMS başlatılamadı.','http_code'=>$r['http_code'],'curl_error'=>$r['error'],'MSG'=>$msg,'ERROR_ID'=>$err,'INFOMSG'=>$info,'TOKEN'=>$token?zrx_mask($token):'','pending_saved'=>$ok];
}
function zrx_login_otp(array $in): array {
    $cfg=zrx_config(); $otp=trim((string)($in['otp']??$in['extraInfo']??'')); $captcha=trim((string)($in['gRecaptchaResponse']??'')); $p=zrx_read(zrx_pending_file());
    if(!$p) return ['ok'=>false,'error'=>'Bekleyen login yok. Önce Giriş yapın.'];
    if (time()-strtotime($p['createdAt']??'1970-01-01')>600) { unlink(zrx_pending_file());return ['ok'=>false,'error'=>'SMS giriş süresi doldu. Yeniden giriş başlatın.']; }
    if($otp==='' || !preg_match('/^[0-9]{4,8}$/',$otp)) return ['ok'=>false,'error'=>'Geçerli SMS kodu zorunlu.'];
    $account=$p['account']??''; $username=$p['username']??$account; $password=$p['password']??''; $sub=$p['subaccount']??$cfg['default_subaccount']; $token=$p['token']??''; $e=fn($v)=>htmlspecialchars((string)$v, ENT_XML1|ENT_QUOTES, 'UTF-8');
    $fx='<FxTrade><trader><traderName>ZIRAAT</traderName></trader><login><account>'.$e($account).'</account><username>'.$e($username).'</username><password>'.$e($password).'</password><subaccount>'.$e($sub).'</subaccount><extraInfo>'.$e($otp).'</extraInfo><token>'.$e($token).'</token><vendor>WEBCLIENT</vendor><ip/></login><request><type>LoginStep2</type></request></FxTrade>';
    $r1=zrx_curl_post($cfg['trade_url'], zrx_payload($fx), ['Content-Type: text/plain','Accept: text/plain, */*; q=0.01','Origin: https://pro.ziraatyatirim.com.tr','Referer: https://pro.ziraatyatirim.com.tr/']);
    $msg=zrx_xml_tag($r1['body'],'MSG'); $err=zrx_xml_tag($r1['body'],'ERROR_ID'); $info=zrx_xml_tag($r1['body'],'INFOMSG'); $step2Ok=($r1['error']==='' && strtoupper($msg)==='SUCCESS' && strtolower($err)!=='wrongparams');
    $sessionPassword=$password; $authJson=null; $r2=null;
    if($captcha!==''){
        $payload=json_encode(['username'=>$username,'account'=>$account,'password'=>$password,'subaccount'=>$sub,'extraInfo'=>$otp,'token'=>$token,'gRecaptchaResponse'=>$captcha], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        $r2=zrx_curl_post('https://web-auth.foreks.com/bffweblogin/ZIRAAT/login', $payload, ['Content-Type: application/json','Accept: application/json, text/plain, */*','Origin: https://pro.ziraatyatirim.com.tr','Referer: https://pro.ziraatyatirim.com.tr/']);
        $tmp=json_decode($r2['body'], true); if(is_array($tmp)){ $authJson=$tmp; if(!empty($tmp['session'])) $sessionPassword=(string)$tmp['session']; elseif(!empty($tmp['message'])) $sessionPassword=(string)$tmp['message']; }
    }
    $canSave=$step2Ok || ($authJson && !empty($authJson['session']) && $r2['error']==='' && $r2['http_code']>=200 && $r2['http_code']<300);
    if($canSave){ $s=['account'=>$account,'username'=>$username,'sessionPassword'=>$sessionPassword,'subaccount'=>$sub,'extraInfo'=>$otp,'token'=>$token,'vendor'=>'WEBCLIENT','ip'=>'','mainToken'=>$authJson['mainToken']??'','feedToken'=>$authJson['feedToken']??'','feedCompany'=>$authJson['feedCompany']??'','loginMode'=>$authJson?'web-auth+sms':'fxtrade-step2','updatedAt'=>date('Y-m-d H:i:s')]; $s['loginXml']=zrx_build_login_xml($s); zrx_write(zrx_session_file(), $s); }
    if ($canSave && is_file(zrx_pending_file())) unlink(zrx_pending_file());
    return ['ok'=>$canSave,'message'=>$canSave?'Oturum açıldı.':'OTP başarısız. Captcha gerekebilir.','session_saved'=>$canSave,'mode'=>$authJson?'web-auth+sms':'fxtrade-step2','fxtrade_step2'=>['http_code'=>$r1['http_code'],'curl_error'=>$r1['error'],'MSG'=>$msg,'ERROR_ID'=>$err,'INFOMSG'=>$info],'web_auth'=>$r2?['http_code'=>$r2['http_code'],'curl_error'=>$r2['error'],'json_ok'=>is_array($authJson),'has_session'=>is_array($authJson)&&!empty($authJson['session'])]:['skipped'=>'gRecaptchaResponse boş.']];
}

function zrx_num($v): float { return (float)str_replace(',', '.', trim((string)$v)); }
function zrx_parse_portfolio_items(string $xml): array {
    $msg=zrx_xml_tag($xml,'MSG'); $err=zrx_xml_tag($xml,'ERROR_ID'); $info=zrx_xml_tag($xml,'INFOMSG');
    $clean=trim($xml);
    if($clean==='') return ['ok'=>false,'MSG'=>$msg,'ERROR_ID'=>$err,'INFOMSG'=>$info,'error'=>'Boş Ziraat cevabı.','items'=>[],'subitems'=>[]];
    $items=[];
    if(preg_match_all('~<PortfolioItem[^>]*>(.*?)</PortfolioItem>~is', $clean, $mm)){
        foreach($mm[1] as $chunk){
            $get=function($tag) use ($chunk){ return zrx_xml_tag($chunk, $tag); };
            $sec=$get('secType'); $code=strtoupper(trim($get('code')));
            $items[]=[
                'name'=>$get('name'),
                'code'=>$code,
                'symbol'=>$code,
                'secType'=>$sec,
                'amount'=>zrx_num($get('amount')),
                'amountToSell'=>zrx_num($get('amountToSell')),
                'price'=>zrx_num($get('price')),
                'cost'=>zrx_num($get('cost')),
                'volume'=>zrx_num($get('volume')),
                'gainLoss'=>zrx_num($get('gainLoss')),
                'totalGainLoss'=>zrx_num($get('totalGainLoss')),
                'changePercentage'=>zrx_num($get('changePercentage')),
                'lastPrice'=>zrx_num($get('lastPrice')),
                'stockShortName'=>$get('stockShortName'),
                'serialCode'=>$get('serialCode'),
            ];
        }
    }
    $subitems=[];
    if(preg_match_all('~<SubItem[^>]*>(.*?)</SubItem>~is', $clean, $sm)){
        foreach($sm[1] as $chunk){
            $get=function($tag) use ($chunk){ return zrx_xml_tag($chunk, $tag); };
            $subitems[]=['subName'=>$get('subName'),'type'=>$get('type'),'value'=>$get('value'),'num'=>zrx_num($get('value'))];
        }
    }
    return ['ok'=>strtoupper($msg)==='SUCCESS' && strtolower($err)!=='wrongparams','MSG'=>$msg,'ERROR_ID'=>$err,'INFOMSG'=>$info,'items'=>$items,'subitems'=>$subitems,'count'=>count($items),'stock_count'=>count(array_filter($items, fn($x)=>strcasecmp($x['secType'],'Hisse')===0))];
}
function zrx_portfolio_items(array $in=[]): array {
    $cfg=zrx_config(); $s=zrx_read(zrx_session_file());
    if(!$s) return ['ok'=>false,'error'=>'Ziraat oturumu yok. Önce Ziraat Giriş yapın.'];
    $loginXml=zrx_build_login_xml($s);
    $fx='<FxTrade><trader><traderName>ZIRAAT</traderName></trader>'.$loginXml.'<request><type>PortfolioItems</type><Konsolide>1</Konsolide></request></FxTrade>';
    $r=zrx_curl_post($cfg['trade_url'], zrx_payload($fx), ['Content-Type: text/plain','Accept: text/plain, */*; q=0.01','Origin: https://pro.ziraatyatirim.com.tr','Referer: https://pro.ziraatyatirim.com.tr/'], 20);
    if($r['error']!=='') return ['ok'=>false,'http_code'=>$r['http_code'],'curl_error'=>$r['error'],'error'=>'Ziraat portföy isteği gönderilemedi.'];
    $parsed=zrx_parse_portfolio_items($r['body']);
    $parsed['http_code']=$r['http_code'];
    $parsed['updatedAt']=date('Y-m-d H:i:s');
    $parsed['request_type']='PortfolioItems';
    // Güvenlik için login/token içeren request_body döndürülmez.
    zrx_write(zrx_data_dir().'/last_portfolio_items.json', $parsed);
    return $parsed;
}


function zrx_parse_daily_orders(string $xml): array {
    $msg=zrx_xml_tag($xml,'MSG'); $err=zrx_xml_tag($xml,'ERROR_ID'); $info=zrx_xml_tag($xml,'INFOMSG');
    $clean=trim($xml);
    if($clean==='') return ['ok'=>false,'MSG'=>$msg,'ERROR_ID'=>$err,'INFOMSG'=>$info,'error'=>'Boş Ziraat günlük emir cevabı.','orders'=>[]];
    $orders=[];
    if(preg_match_all('~<DailyOrder[^>]*>(.*?)</DailyOrder>~is', $clean, $mm)){
        foreach($mm[1] as $chunk){
            $get=function($tag) use ($chunk){ return zrx_xml_tag($chunk, $tag); };
            $stock=strtoupper(trim($get('Stock') ?: $get('stockShortName')));
            $side=strtoupper(trim($get('BuySell')));
            $orders[]=[
                'AccountNo'=>$get('AccountNo'),
                'SubAccountNo'=>$get('SubAccountNo'),
                'RefNo'=>$get('RefNo'),
                'IMKBRefNo'=>$get('IMKBRefNo'),
                'Stock'=>$stock,
                'symbol'=>$stock,
                'BuySell'=>$side,
                'side'=>$side,
                'Status'=>$get('Status'),
                'StatusCode'=>$get('StatusCode'),
                'AStatus'=>$get('AStatus'),
                'Size'=>zrx_num($get('Size')),
                'Price'=>zrx_num($get('Price')),
                'Volume'=>zrx_num($get('Volume')),
                'RemainingSize'=>zrx_num($get('RemainingSize')),
                'CanceledSize'=>zrx_num($get('CanceledSize')),
                'ExecutedSize'=>zrx_num($get('ExecutedSize')),
                'ExecutedPrice'=>zrx_num($get('ExecutedPrice')),
                'ExecutedVolume'=>zrx_num($get('ExecutedVolume')),
                'OrderDate'=>$get('OrderDate'),
                'OrderTime'=>$get('OrderTime'),
                'CanDelete'=>$get('CanDelete'),
                'CanModify'=>$get('CanModify'),
            ];
        }
    }
    return ['ok'=>strtoupper($msg)==='SUCCESS' && strtolower($err)!=='wrongparams','MSG'=>$msg,'ERROR_ID'=>$err,'INFOMSG'=>$info,'orders'=>$orders,'count'=>count($orders)];
}

function zrx_daily_orders(array $in=[]): array {
    $cfg=zrx_config(); $s=zrx_read(zrx_session_file());
    if(!$s) return ['ok'=>false,'error'=>'Ziraat oturumu yok. Önce Ziraat Giriş yapın.'];
    $loginXml=zrx_build_login_xml($s);
    $type=trim((string)($in['type'] ?? 'DailyOrders'));
    if($type==='') $type='DailyOrders';
    $fx='<FxTrade><trader><traderName>ZIRAAT</traderName></trader>'.$loginXml.'<request><type>'.htmlspecialchars($type, ENT_XML1|ENT_QUOTES, 'UTF-8').'</type></request></FxTrade>';
    $r=zrx_curl_post($cfg['trade_url'], zrx_payload($fx), ['Content-Type: text/plain','Accept: text/plain, */*; q=0.01','Origin: https://pro.ziraatyatirim.com.tr','Referer: https://pro.ziraatyatirim.com.tr/'], 20);
    if($r['error']!=='') return ['ok'=>false,'http_code'=>$r['http_code'],'curl_error'=>$r['error'],'error'=>'Ziraat günlük emir isteği gönderilemedi.'];
    $parsed=zrx_parse_daily_orders($r['body']);
    if ($parsed['ok']) zrx_reconcile_receipts($parsed['orders']);
    $parsed['http_code']=$r['http_code'];
    $parsed['updatedAt']=date('Y-m-d H:i:s');
    $parsed['request_type']=$type;
    zrx_write(zrx_data_dir().'/last_daily_orders.json', $parsed);
    return $parsed;
}

function zrx_order_transport(array $in): array {
    $cfg=zrx_config(); $symbol=strtoupper(trim((string)($in['symbol']??''))); $side=strtoupper(trim((string)($in['side']??''))); $price=trim((string)($in['price']??'')); $size=trim((string)($in['size']??$in['amount']??'')); $dryRun = array_key_exists('dry_run',$in) ? (bool)$in['dry_run'] : true;
    if(in_array($side,['BUY','AL','B'],true)) $side='A'; if(in_array($side,['SELL','SAT'],true)) $side='S';
    if($symbol==='' || !preg_match('/^[A-Z0-9._-]+$/',$symbol)) return ['ok'=>false,'error'=>'Geçerli symbol zorunlu.'];
    if(!in_array($side,['A','S'],true)) return ['ok'=>false,'error'=>'side AL/SAT olmalı.'];
    if($price==='' || !preg_match('/^\d+([.,]\d+)?$/',$price)) return ['ok'=>false,'error'=>'Geçerli fiyat zorunlu.'];
    if($size==='' || !preg_match('/^\d+([.,]\d+)?$/',$size)) return ['ok'=>false,'error'=>'Geçerli adet zorunlu.'];
    $price=str_replace(',','.',$price); $size=str_replace(',','.',$size);
    if ((float)$price<=0 || (float)$size<=0 || floor((float)$size)!=(float)$size) return ['ok'=>false,'error'=>'Pozitif fiyat ve tam lot gerekli.'];
    if ($dryRun) return ['ok'=>true,'dry_run'=>true,'filled'=>false,'message'=>'Paper: gerçek emir gönderilmedi.'];
    $s=zrx_read(zrx_session_file()); if(!$s) return ['ok'=>false,'error'=>'Ziraat oturumu yok. Önce Ziraat Giriş yapın.'];
    $tplInfo=zrx_ensure_template(); $tpl=$tplInfo['template']; $body=zrx_norm_fx((string)$tpl['body']); $loginXml=zrx_build_login_xml($s);
    if(preg_match('~<login\b[^>]*>.*?</login>~is',$body)) $body=preg_replace('~<login\b[^>]*>.*?</login>~is',$loginXml,$body,1); else return ['ok'=>false,'error'=>'Template içinde login bloğu yok.'];
    $replaced=['stock'=>0,'amount'=>0,'price'=>0,'buySell'=>0,'dateTime'=>0];
    $rep=function($xml,$tag,$val,&$count){ $safe=htmlspecialchars((string)$val, ENT_XML1|ENT_QUOTES,'UTF-8'); $pat='~<'.preg_quote($tag,'~').'\b[^>]*>.*?</'.preg_quote($tag,'~').'>~is'; if(preg_match($pat,$xml)){ $count++; return preg_replace($pat,'<'.$tag.'>'.$safe.'</'.$tag.'>',$xml,1); } $pat2='~<'.preg_quote($tag,'~').'\b[^>]*/>~is'; if(preg_match($pat2,$xml)){ $count++; return preg_replace($pat2,'<'.$tag.'>'.$safe.'</'.$tag.'>',$xml,1); } return $xml; };
    $body=$rep($body,'stock',$symbol,$replaced['stock']); $body=$rep($body,'amount',$size,$replaced['amount']); $body=$rep($body,'price',$price,$replaced['price']); $body=$rep($body,'buySell',$side,$replaced['buySell']); $body=$rep($body,'dateTime',zrx_datetime(),$replaced['dateTime']);
    $missing=[]; foreach(['stock','amount','price','buySell'] as $k) if(!$replaced[$k]) $missing[]=$k;
    $base=['input'=>['symbol'=>$symbol,'side'=>$side,'price'=>$price,'size'=>$size],'dry_run'=>$dryRun,'template_source'=>$tplInfo['created']?'built-in-auto-created':'file','template_type'=>$tpl['type']??'Order','replaced'=>$replaced,'missing'=>$missing];
    $debug = !empty($cfg['order_debug']);
    $safeBody=preg_replace('~<login\b[^>]*>.*?</login>~is','<login>[REDACTED]</login>',$body);
    $debugBase = $base + ['request_body'=>$safeBody];
    if($missing){ zrx_write(zrx_last_order_file(), $debugBase+['error'=>'Eksik replacement']); return ['ok'=>false,'error'=>'Template alanları değiştirilemedi.','missing'=>$missing,'replaced'=>$replaced]; }
    if($dryRun){ zrx_write(zrx_last_order_file(), $debugBase+['response'=>'DRY_RUN']); return ['ok'=>true,'dry_run'=>true,'message'=>'Dry run: gerçek emir gönderilmedi.','replaced'=>$replaced]; }
    $r=zrx_curl_post($cfg['trade_url'], zrx_payload($body), ['Content-Type: text/plain','Accept: text/plain, */*; q=0.01','Origin: https://pro.ziraatyatirim.com.tr','Referer: https://pro.ziraatyatirim.com.tr/'], 20);
    $ref=zrx_parse_ref($r['body']); $msg=zrx_xml_tag($r['body'],'MSG'); $err=zrx_xml_tag($r['body'],'ERROR_ID'); $info=zrx_xml_tag($r['body'],'INFOMSG');
    $accepted=$r['error']==='' && $r['http_code']>=200 && $r['http_code']<300 && strtoupper($msg)==='SUCCESS' && ($err==='' || $err==='0');
    $unknown=!$accepted && ($r['error']!=='' || $r['http_code']===0 || $r['http_code']>=500 || ($msg==='' && $err===''));
    $out=$base+['ok'=>$accepted,'accepted'=>$accepted,'unknown'=>$unknown,'filled'=>false, 'http_code'=>$r['http_code'],'curl_error'=>$r['error'],'MSG'=>$msg,'ERROR_ID'=>$err,'INFOMSG'=>$info,'RefNo'=>$ref];
    zrx_write(zrx_last_order_file(), $debug ? ($out+['request_body'=>$safeBody]) : zrx_slim_order_record($out+['time'=>date('Y-m-d H:i:s'),'symbol'=>$symbol,'side'=>$side,'price'=>$price,'size'=>$size]));
    $orderRecord=zrx_slim_order_record($out+['time'=>date('Y-m-d H:i:s'),'symbol'=>$symbol,'side'=>$side,'price'=>$price,'size'=>$size]);
    if($ref!=='' || $msg!=='' || $err!=='' || $info!==''){ $log=zrx_read(zrx_orders_log_file(),[]); array_unshift($log,$orderRecord); zrx_write(zrx_orders_log_file(), array_slice($log,0,200)); }
    if($debug){ $out['request_body']=$safeBody; }
    return $out;
}

function zrx_order(array $in): array {
    if (array_key_exists('dry_run',$in) && !is_bool($in['dry_run'])) return ['ok'=>false,'error'=>'dry_run boolean olmalı.'];
    $id=$in['client_order_id']??'';
    if (!is_string($id) || !preg_match('/^[A-Za-z0-9_-]{8,100}$/D',$id)) return ['ok'=>false,'error'=>'Tekil emir kimliği gerekli.'];
    $lock=fopen(zrx_data_dir().'/order.lock','c');
    if (!$lock || !flock($lock,LOCK_EX)) return ['ok'=>false,'error'=>'Emir kaydı kilitlenemedi.'];
    try {
        $file=zrx_data_dir().'/order_receipts.json';
        try { $all=is_file($file)?json_decode(file_get_contents($file),true,512,JSON_THROW_ON_ERROR):[]; }
        catch (JsonException $e) { return ['ok'=>false,'error'=>'Emir kayıt dosyası bozuk; yeni emir gönderilmedi.']; }
        if (!is_array($all)) return ['ok'=>false,'error'=>'Emir kayıt biçimi geçersiz.'];
        $dry=($in['dry_run']??true)!==false;$session=zrx_read(zrx_session_file(),[]);
        $scope=$dry?'paper':hash('sha256',($session['account']??'').'|'.($session['subaccount']??''));
        $fingerprint=hash('sha256',json_encode([$in['symbol']??null,$in['side']??null,$in['price']??null,$in['size']??null,$in['dry_run']??true]));
        if (isset($all[$id])) {
            if ($all[$id]['fingerprint']!==$fingerprint || ($all[$id]['scope']??$scope)!==$scope) return ['ok'=>false,'error'=>'Emir kimliği farklı bir istek için kullanılmış.'];
            return $all[$id]['result']+['duplicate'=>true];
        }
        if (!$dry) foreach ($all as $receipt) {
            if (($receipt['scope']??$scope)!==$scope || !empty($receipt['terminal'])) continue;
            $result=$receipt['result'];
            $unresolved=!empty($result['unknown'])||!empty($result['accepted']);
            $buy=in_array(strtoupper((string)($in['side']??'')),['B','A','BUY','AL'],true);
            if ($unresolved && ($buy || ($receipt['symbol']??'')===($in['symbol']??''))) return ['ok'=>false,'error'=>'Sunucuda teyitsiz emir var; Günlük Emirler ve portföyden mutabakat gerekli.'];
        }
        $all[$id]=['fingerprint'=>$fingerprint,'scope'=>$scope,'symbol'=>$in['symbol']??'','qty'=>(float)($in['size']??0),'result'=>['ok'=>false,'unknown'=>true,'error'=>'Emir sonucu belirsiz; yeniden göndermeden Günlük Emirler ve portföyden kontrol edin.']];
        if (!zrx_write($file,$all)) return ['ok'=>false,'error'=>'Emir ön kaydı yazılamadı; emir gönderilmedi.'];
        try { $result=zrx_order_transport($in); }
        catch (Throwable $e) { return $all[$id]['result']; }
        $all[$id]['result']=$result;
        zrx_write($file,$all);
        return $result;
    } finally { flock($lock,LOCK_UN);fclose($lock); }
}

function zrx_reconcile_receipts(array $orders): void {
    $lock=fopen(zrx_data_dir().'/order.lock','c');if(!$lock||!flock($lock,LOCK_EX))return;
    try {
        $file=zrx_data_dir().'/order_receipts.json';$all=zrx_read($file,[]);$changed=false;
        foreach($all as &$receipt){
            $ref=$receipt['result']['RefNo']??'';if($ref===''||!empty($receipt['terminal']))continue;
            foreach($orders as $order)if(($order['RefNo']??'')===$ref){
                $qty=(float)($receipt['qty']??0);if($qty<=0)continue;
                $filled=(float)($order['ExecutedSize']??0);$cancelled=(float)($order['CanceledSize']??0);
                if($filled>=$qty||$filled+$cancelled>=$qty){
                    $receipt['terminal']=true;$receipt['result']['filled']=$filled>=$qty;
                    $receipt['result']['partial']=$filled>0&&$filled<$qty;$receipt['result']['cancelled_size']=$cancelled;
                    $receipt['result']['executed_size']=$filled;$receipt['result']['executed_price']=$order['ExecutedPrice']??0;$changed=true;
                }
            }
        }
        unset($receipt);if($changed)zrx_write($file,$all);
    } finally {flock($lock,LOCK_UN);fclose($lock);}
}
