/* Original PORTFOY UI, Ziraat calls, scan and A/B/P feed stay in index.php. */
'use strict';
(function(){
  const A=PortfoyAlgoritma,c=A.options(PORTFOY_ALGO_CONFIG),quotes=new Map(),signals=new Map(),reservations=new Map();
  const originalWs=applyWsField,originalStart=startWebSocket;
  const riskKey='portfoy-algoritma:'+location.pathname.replace(/index\.php$/,'');
  let risk={},pending={},pollBusy=false;
  try{pending=JSON.parse(localStorage.getItem(riskKey+':pending')||'{}');}catch(e){}
  function ui(){return {rsiPeriod:Math.max(2,Math.floor(n($('rsiPeriod').value,14))),rsiBuy:n($('rsiBuy').value,25),trailActivation:Math.max(0,n($('trailActivation').value,2)),trailDistance:Math.max(.01,n($('trailDistance').value,.1))};}
  function fee(){return Math.max(.0015,currentCommissionPct()/100);}
  function day(){return new Date(Date.now()+3*3600000).toISOString().slice(0,10);}
  function mode(){return $('paperMode').checked?'paper':'live';}
  function savePending(){localStorage.setItem(riskKey+':pending',JSON.stringify(pending));}
  function portfolio(){
    const capital=n($('totalLimit').value,100000),commission=fee();
    const realized=state.sold.filter(t=>mode()==='paper'?t.source==='paper':t.source==='broker').reduce((s,t)=>s+(n(t.sell)-n(t.buy))*n(t.qty)-(n(t.buy)+n(t.sell))*n(t.qty)*commission,0);
    const open=Object.values(state.holdings).reduce((s,h)=>s+(n(h.last)-n(h.cost))*n(h.qty)-(n(h.last)+n(h.cost))*n(h.qty)*commission,0);
    const equity=capital+realized+open,invested=investedCostTL()+[...reservations.values()].reduce((sum,r)=>sum+r.notional,0);
    const key=riskKey+':'+mode();
    try{risk=JSON.parse(localStorage.getItem(key)||'{}');}catch(e){risk={};}
    const guard=A.limits({capital,equity,previous:risk,day:day()},c);risk=guard.state;
    try{localStorage.setItem(key,JSON.stringify(risk));}catch(e){guard.blocked=true;guard.reason='RİSK KAYDI YAZILAMADI';}
    return {capital,equity,invested,guard};
  }
  function blocked(message,symbol){log(`ALGORİTMA ENGEL → ${symbol||''} | ${message}`);}
  function closedBars(symbol){const b=candleBucket(Date.now());return (state.candles[symbol+':15']||[]).filter(x=>x.t<b);}
  indicatorFor=function(symbol){
    const bars=closedBars(symbol),p=ui(),key=[bars.at(-1)?.t,bars.length,p.rsiPeriod,p.rsiBuy].join(':');
    const cached=signals.get(symbol);if(cached?.key===key)return cached.value;
    let value;try{value=A.entry(bars,p,c);}catch(e){value={buy:false,rsi:NaN,atr:NaN,signal:'VERİ HATASI',reason:e.message};}
    signals.set(symbol,{key,value});return value;
  };
  updateCandle=function(symbol,price,minutes=15){
    if(!(price>0))return;const now=Date.now(),bucket=candleBucket(now,minutes),key=symbol+':'+minutes;
    const bars=state.candles[key]||(state.candles[key]=[]),last=bars.at(-1);
    if(last&&now<(last.lastTick||last.t))return;
    if(!last||last.t!==bucket){
      signals.delete(symbol);
      if(last){last.complete=last.complete!==false&&last.lastTick>=last.t+minutes*60000-c.maxTickGapMs&&bucket===last.t+minutes*60000;onClosedCandle(symbol,minutes);}
      bars.push({t:bucket,o:price,h:price,l:price,c:price,lastTick:now,complete:now-bucket<=c.maxTickGapMs});
      if(bars.length>260)bars.splice(0,bars.length-260);
    }else{last.complete=last.complete!==false&&now-(last.lastTick||last.t)<=c.maxTickGapMs;last.h=Math.max(last.h,price);last.l=Math.min(last.l,price);last.c=price;last.lastTick=now;}
  };
  onClosedCandle=function(symbol,minutes){
    if(minutes!==15)return;const bars=closedBars(symbol),last=bars.at(-1),signal=indicatorFor(symbol);updateScanRow(symbol);
    if(!last||Date.now()-(last.t+900000)>900000)return;
    if($('autoBuy').checked&&signal.buy&&!state.holdings[symbol]&&state.scan.some(r=>r.symbol===symbol))autoBuyStrategy(symbol,`RSI TOPARLANMA + EMA${c.trendPeriod} + ATR | RSI ${fmt(signal.rsi,2)}`);
  };
  applyWsField=function(symbol,field,value){
    const f=String(field).toUpperCase(),sym=safeSym(symbol);let raw=value;
    if(raw&&typeof raw==='object')raw=raw.v??raw.value??raw.data_value;
    const price=rawNumber(raw);
    if(['A','B'].includes(f)&&price>0){const side=f==='A'?'ask':'bid',q=quotes.get(sym)||{};q[side]=price;q[side+'At']=Date.now();quotes.set(sym,q);}
    return originalWs(symbol,field,value);
  };
  strategyOnBid=function(symbol,bid){
    const h=state.holdings[symbol];if(!h||!$('autoSell').checked||pending[symbol])return;
    if(!A.fresh(quotes.get(symbol),'bid',Date.now(),c))return;
    const result=A.exit(h,state.trail[symbol]||h.algoTrail,bid,ui(),c,Date.now(),fee());
    state.trail[symbol]=result.state;h.algoTrail=result.state;if(result.reason)autoSellStrategy(symbol,result.reason);
  };
  holdingSignal=function(symbol){const h=state.holdings[symbol],t=state.trail[symbol]||h?.algoTrail;if(pending[symbol])return 'EMİR TEYİDİ BEKLE';if(!h)return indicatorFor(symbol).signal;return t?.stop>0?`${t.armed?'ATR TRAIL':'STOP'} ${fmt(t.stop)}`:'STOP HAZIRLANIYOR';};
  function modeMatches(h){return mode()==='paper'?h.source==='paper':h.source!=='paper';}
  function snapshotRisk(symbol,isAuto){
    const r=state.scan.find(x=>x.symbol===symbol);if(!r)return null;
    const p=portfolio();if(p.guard.blocked){blocked(p.guard.reason,symbol);return null;}
    if(Object.keys(pending).length){blocked('Bekleyen/belirsiz emir var; Günlük Emirler ve Portföy Çek ile kontrol edin.',symbol);return null;}
    for(const h of Object.values(state.holdings)){
      if(!modeMatches(h)){blocked('Paper ve gerçek portföy karıştırılamaz. Seçtiğiniz moda ait portföyü yükleyin.',symbol);return null;}
      if(!A.fresh(quotes.get(h.symbol),'bid',Date.now(),c)){blocked('Mevcut pozisyonun Bid verisi eski.',symbol);return null;}
    }
    const lastSale=state.sold.filter(t=>t.symbol===symbol).reduce((v,t)=>Math.max(v,Date.parse(t.sellTime||t.time)||0),0);
    if(Date.now()-lastSale<c.cooldownMinutes*60000){blocked('Satış sonrası bekleme süresi.',symbol);return null;}
    if(isAuto&&(!Number.isFinite(r.dayPct)||r.dayPct<n($('evalMinPct').value,-2)||r.dayPct>n($('evalMaxPct').value,3))){blocked('Günlük değişim değerlendirme aralığı dışında.',symbol);return null;}
    const openRisk=Object.values(state.holdings).reduce((sum,h)=>{const stop=state.trail[h.symbol]?.stop||h.initialStop||h.cost*(1-c.hardStopPct/100);return sum+Math.max(0,(h.cost-stop)*h.qty+(h.cost+stop)*h.qty*fee()+stop*h.qty*c.slippagePct/100);},0)+[...reservations.values()].reduce((sum,r)=>sum+r.risk,0);
    const plan=A.plan({quote:quotes.get(symbol),capital:p.capital,equity:p.equity,invested:p.invested,openRisk,buyAmount:n($('buyAmount').value),totalLimit:n($('totalLimit').value),positions:Object.keys(state.holdings).length+reservations.size,atr:indicatorFor(symbol).atr,commissionRate:fee(),now:Date.now()},c);
    if(!plan.ok){blocked(plan.reason,symbol);return null;}return {r,plan};
  }
  function remember(p){pending[p.symbol]=p;savePending();}
  function forget(symbol){delete pending[symbol];savePending();}
  async function reconcile(){
    for(const [symbol,p] of Object.entries(pending)){
      const orders=state.dailyOrders||[],o=orders.find(x=>(x.RefNo||x.refNo)===p.ref&&p.ref);
      if(!o)continue;
      const executed=n(o.ExecutedSize??o.executedSize),cancelled=n(o.CanceledSize??o.canceledSize),qty=p.qty;
      if(executed>0&&(executed>=qty||executed+cancelled>=qty)){
        const filledQty=Math.min(qty,executed);
        if(p.side==='B'){
          const h=state.holdings[symbol];if(!h||n(h.qty)<filledQty)continue;
          Object.assign(h,{entryAtr:p.atr,initialStop:h.cost*(1-c.hardStopPct/100),source:'broker',buyTime:p.time});
          state.trail[symbol]={armed:false,peak:h.last,stop:h.initialStop};
        }else{
          if(state.holdings[symbol]&&n(state.holdings[symbol].qty)>Math.max(0,p.beforeQty-filledQty))continue;
          const sell=n(o.ExecutedPrice??o.executedPrice);if(!(sell>0))continue;
          state.sold.unshift({symbol,qty:filledQty,buy:p.cost,sell,pnlPct:(sell/p.cost-1)*100,buyTime:p.buyTime,sellTime:new Date().toISOString(),time:new Date().toISOString(),reason:p.reason,source:'broker'});
        }
        addDailyTradeVolume(n(o.ExecutedPrice??o.executedPrice)*filledQty);forget(symbol);log(`ZİRAAT GERÇEKLEŞME TEYİT → ${symbol} ${filledQty} lot${cancelled>0?' | kalan iptal':''}`);
      }else if(cancelled>=qty&&executed===0){forget(symbol);log(`ZİRAAT İPTAL TEYİT → ${symbol}`);}
      else if(executed>0)log(`ZİRAAT KISMİ GERÇEKLEŞME → ${symbol} ${executed}/${qty}; kalan emir bekleniyor.`);
    }
  }
  const oldPortfolio=ziraatFetchPortfolio,oldOrders=ziraatFetchDailyOrders;
  ziraatFetchPortfolio=async function(auto){
    const previous=state.holdings;await oldPortfolio(auto);
    for(const h of Object.values(state.holdings)){
      const old=previous[h.symbol];
      if(old&&old.source!=='paper'&&Math.abs(old.cost-h.cost)<1e-8){for(const key of ['entryAtr','initialStop','buyTime','algoTrail'])if(old[key]!==undefined)h[key]=old[key];}
      if(h.algoTrail&&!state.trail[h.symbol])state.trail[h.symbol]=h.algoTrail;
    }
    await reconcile();renderHoldings();
  };
  ziraatFetchDailyOrders=async function(auto){await oldOrders(auto);await reconcile();};
  executeBuy=async function(symbol,reason,isAuto=false){
    symbol=safeSym(symbol);if(state.entryLocks.has(symbol)||state.holdings[symbol])return;
    const selected=snapshotRisk(symbol,isAuto);if(!selected)return;const {r,plan}=selected;
    const dry=$('paperMode').checked;
    if(!isAuto&&!confirm(`${symbol} ${plan.qty} lot @ Ask ${fmt(plan.price)} ${dry?'PAPER':'GERÇEK'} AL?\nPlanlı stop riski (boşlukta aşılabilir): ${fmt(plan.plannedRisk)} TL`))return;
    state.entryLocks.add(symbol);reservations.set(symbol,{notional:plan.paperPrice*plan.qty,risk:plan.plannedRisk});const id=crypto.randomUUID(),now=new Date().toISOString();
    try{
      if(!dry)remember({symbol,side:'B',qty:plan.qty,id,time:now,atr:plan.atr,reason,uncertain:true});
      const result=await ziraatApi('ziraat_order',{symbol,side:'B',price:String(plan.price),size:String(plan.qty),dry_run:dry,client_order_id:id});
      if(!result?.ok){if(!result?.unknown)forget(symbol);throw new Error(result?.error||result?.INFOMSG||'AL emri reddedildi.');}
      if(!dry){remember({...pending[symbol],ref:result.RefNo,uncertain:false});log(`ZİRAAT EMİR KABUL → ${symbol} | gerçekleşme teyidi bekleniyor`);await ziraatFetchDailyOrders(true);await ziraatFetchPortfolio(true);return;}
      state.holdings[symbol]={symbol,qty:plan.qty,cost:plan.paperPrice,last:r.bid,ask:r.ask,prev:r.prev,dayPct:r.dayPct,time:now,buyTime:now,buyReason:reason,source:'paper',scanV:n(r.V),scanY:n(r.yRaw),entryAtr:plan.atr,initialStop:plan.stop};
      state.trail[symbol]={armed:false,peak:r.bid,stop:plan.stop};state.scan=state.scan.filter(x=>x.symbol!==symbol);
      addDailyTradeVolume(plan.paperPrice*plan.qty);renderScan();renderHoldings();subscribeWsSymbols();log(`PAPER AL → ${symbol} x ${plan.qty} | ${reason}`);
    }catch(e){log('AL HATA → '+symbol+' | '+e.message);}finally{state.entryLocks.delete(symbol);reservations.delete(symbol);}
  };
  executeSell=async function(symbol,reason,isAuto=false){
    const h=state.holdings[symbol];if(!h||state.sellLocks.has(symbol)||pending[symbol])return;
    if(!modeMatches(h)){blocked('Portföy kaynağı seçilen paper/gerçek modla eşleşmiyor.',symbol);return;}
    const q=quotes.get(symbol);if(!A.fresh(q,'bid',Date.now(),c)){blocked('Güncel Bid yok; maliyet fiyatıyla SAT yapılmaz.',symbol);return;}
    const qty=Math.floor(n(h.qty)),dry=$('paperMode').checked,bid=q.bid;if(qty<1)return;
    if(!isAuto&&!confirm(`${symbol} ${qty} lot @ Bid ${fmt(bid)} ${dry?'PAPER':'GERÇEK'} SAT?`))return;
    state.sellLocks.add(symbol);const id=crypto.randomUUID();
    try{
      if(!dry)remember({symbol,side:'S',qty,beforeQty:h.qty,cost:h.cost,buyTime:h.buyTime||h.time,id,time:new Date().toISOString(),reason,uncertain:true});
      const result=await ziraatApi('ziraat_order',{symbol,side:'S',price:String(bid),size:String(qty),dry_run:dry,client_order_id:id});
      if(!result?.ok){if(!result?.unknown)forget(symbol);throw new Error(result?.error||result?.INFOMSG||'SAT emri reddedildi.');}
      if(!dry){remember({...pending[symbol],ref:result.RefNo,uncertain:false});log(`ZİRAAT SAT KABUL → ${symbol} | gerçekleşme teyidi bekleniyor`);await ziraatFetchDailyOrders(true);await ziraatFetchPortfolio(true);return;}
      const sell=bid*(1-c.slippagePct/100),time=new Date().toISOString();
      state.sold.unshift({symbol,qty,buy:h.cost,sell,pnlPct:(sell/h.cost-1)*100,buyTime:h.buyTime||h.time,sellTime:time,time,buyReason:h.buyReason,sellReason:reason,reason,source:'paper'});
      delete state.holdings[symbol];delete state.trail[symbol];restoreScanFromHolding(h);addDailyTradeVolume(sell*qty);renderHoldings();renderSold();portfolio();log(`PAPER SAT → ${symbol} | ${reason}`);
    }catch(e){log('SAT HATA → '+symbol+' | '+e.message);}finally{state.sellLocks.delete(symbol);}
  };
  startWebSocket=function(){if(!FINTABLES_WS_TOKEN){setText('scanInfo','Fintables anahtarı gerekli — Fintables Bağlantı düğmesini kullanın.');return;}return originalStart();};
  $('btnFintables').onclick=()=>show('fintablesModal');$('btnFintablesClose').onclick=()=>hide('fintablesModal');
  $('btnFintablesConnect').onclick=async()=>{
    const token=$('fintablesToken').value.trim().replace(/^Bearer\s+/i,'');
    try{const result=await ziraatApi('fintables_token',{token});if(!result.ok)throw new Error(result.error);FINTABLES_WS_TOKEN=token;$('fintablesToken').value='';hide('fintablesModal');startWebSocket();}
    catch(e){setText('fintablesMsg',e.message);}
  };
  setInterval(async()=>{if(!Object.keys(pending).length||pollBusy||$('paperMode').checked)return;pollBusy=true;try{await ziraatFetchDailyOrders(true);await ziraatFetchPortfolio(true);}finally{pollBusy=false;}},10000);
  log(`ALGORİTMA → RSI toparlanma + EMA${c.trendPeriod} + ATR stop/trailing; işlem riski %${c.riskPerTradePct}. Ziraat ve Fintables orijinal akıştadır.`);
  window.PORTFOY_ALGO_READY=true;
})();
