(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('./gostergeler.js'),require('./strateji_motoru.js'));else root.PortfoyStratejiTest=factory(root.Portfoy,root.PortfoyAlgoritma);})(typeof globalThis!=='undefined'?globalThis:this,function(P,A){
  'use strict';
  function run(bars,raw,settings={}){
    P.validateBars(bars);const c=A.options(raw);
    const {baseline=false,tradeFrom=0,...numericSettings}=settings;
    const u={capital:100000,buyAmount:9000,rsiPeriod:14,rsiBuy:25,trailActivation:2,trailDistance:.1,commissionRate:.0015,spreadPct:.2,...numericSettings};
    for(const key of Object.keys(u))if(!Number.isFinite(u[key])||(key==='commissionRate'||key==='spreadPct'?u[key]<0:u[key]<=0))throw new Error('Test ayarı geçersiz: '+key);
    if(u.spreadPct>=100||u.commissionRate>=1)throw new Error('Maliyet oranı geçersiz.');
    if(bars.length<65)throw new Error('En az 65 adet 15 dakikalık Ask OHLC mumu gerekli.');
    const first=tradeFrom;
    if(!Number.isInteger(first)||first<0||first>=bars.length)throw new Error('Test başlangıcı geçersiz.');
    let cash=u.capital,position=null,trail={},pending=null,risk={},cooldownUntil=0,peak=u.capital,drawdown=0;
    const trades=[],curve=[];
    const bid=ask=>ask/(1+u.spreadPct/100),day=t=>new Date(t+3*3600000).toISOString().slice(0,10);
    const equity=ask=>cash+(position?position.qty*bid(ask)*(1-c.slippagePct/100)*(1-u.commissionRate):0);
    function close(price,t,reason){
      const sell=price*(1-c.slippagePct/100),exitFee=sell*position.qty*u.commissionRate;
      const pnl=(sell-position.cost)*position.qty-position.entryFee-exitFee;
      cash+=sell*position.qty-exitFee;
      trades.push({entryTime:Date.parse(position.buyTime),exitTime:t,buy:position.cost,sell,qty:position.qty,fees:position.entryFee+exitFee,netPnl:pnl,reason});
      position=null;trail={};cooldownUntil=t+c.cooldownMinutes*60000;
    }
    function mark(e){peak=Math.max(peak,e);drawdown=Math.max(drawdown,(peak-e)/peak);}
    for(let i=first;i<bars.length;i++){
      const b=bars[i],atOpen=equity(b.o);mark(atOpen);
      let guard=A.limits({equity:atOpen,capital:u.capital,previous:risk,day:day(b.t)},c);risk=guard.state;
      if(pending&&!position&&b.t-pending.at===900000&&(baseline||(!guard.blocked&&b.t>=cooldownUntil))){
        const q={ask:b.o,bid:bid(b.o),askAt:b.t,bidAt:b.t};
        const p=baseline?{ok:true,qty:Math.floor(Math.min(u.buyAmount,cash/(1+u.commissionRate))/(b.o*(1+c.slippagePct/100))),paperPrice:b.o*(1+c.slippagePct/100),atr:0,stop:0}:A.plan({quote:q,capital:u.capital,equity:atOpen,invested:0,cash,buyAmount:u.buyAmount,totalLimit:u.capital,positions:0,atr:pending.atr,commissionRate:u.commissionRate,now:b.t},c);
        if(p.ok&&p.qty>0){const entryFee=p.paperPrice*p.qty*u.commissionRate;cash-=p.paperPrice*p.qty+entryFee;position={cost:p.paperPrice,qty:p.qty,entryFee,initialStop:p.stop,entryAtr:p.atr,buyTime:new Date(b.t).toISOString()};trail={peak:bid(b.o),stop:p.stop,armed:false};}
      }
      pending=null;
      if(position){
        const low=bid(b.l),open=bid(b.o);
        if(trail.stop>0&&open<=trail.stop)close(open,b.t,'GAP_STOP');
        else if(trail.stop>0&&low<=trail.stop)close(trail.stop,b.t,'STOP');
        else if(!baseline){
          const result=A.exit(position,trail,open,u,c,b.t,u.commissionRate);trail=result.state;
          if(result.reason)close(open,b.t,result.reason);
          else if(position)trail=A.exit(position,trail,bid(b.h),u,c,b.t,u.commissionRate).state;
        }else{
          trail.peak=Math.max(trail.peak,bid(b.h));if((trail.peak/position.cost-1)*100>=u.trailActivation)trail.armed=true;
          if(trail.armed)trail.stop=Math.max(trail.stop,trail.peak*(1-u.trailDistance/100));
        }
      }
      if(position)mark(equity(b.l));
      const e=equity(b.c);mark(e);curve.push({t:b.t,equity:e});
      guard=A.limits({equity:e,capital:u.capital,previous:risk,day:day(b.t)},c);risk=guard.state;
      const history=bars.slice(Math.max(0,i-259),i+1);
      if(!position){
        if(baseline){const rsi=P.rsi(history.map(x=>x.c),u.rsiPeriod);if(rsi<=u.rsiBuy)pending={at:b.t};}
        else{const signal=A.entry(history,u,c);if(signal.buy&&!guard.blocked)pending={at:b.t,atr:signal.atr};}
      }
    }
    if(position)close(bid(bars.at(-1).c),bars.at(-1).t,'VERİ_SONU');
    mark(cash);curve.at(-1).equity=cash;
    const wins=trades.filter(t=>t.netPnl>0),losses=trades.filter(t=>t.netPnl<0);
    const profit=wins.reduce((s,t)=>s+t.netPnl,0),loss=-losses.reduce((s,t)=>s+t.netPnl,0);
    return {label:baseline?'Eski RSI≤eşik + trailing':'Yeni RSI toparlanma + EMA + ATR',tradeCount:trades.length,netPnl:cash-u.capital,netPct:(cash/u.capital-1)*100,maxDrawdownPct:drawdown*100,
      winRate:trades.length?wins.length/trades.length*100:null,profitFactor:loss?profit/loss:null,fees:trades.reduce((s,t)=>s+t.fees,0),trades,curve,
      warnings:['Tek hisse ve modellenmiş spread/kayma; gerçek portföy veya emir defteri testi değildir.','Mum içi fiyat sırası bilinmez; yeni trailing seviyesi sonraki mumda uygulanır.','Vergiler ve kuruma özgü diğer ücretler dahil değildir.',...(trades.length<30?['30 işlemden az; sonuçtan güvenilir kârlılık çıkarılamaz.']:[])]};
  }
  function compare(bars,c,settings){return {newStrategy:run(bars,c,settings),original:run(bars,c,{...settings,baseline:true})};}
  return {run,compare};
});
