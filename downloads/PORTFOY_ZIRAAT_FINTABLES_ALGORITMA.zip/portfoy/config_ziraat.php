<?php
return [
    'default_subaccount'=>'100',
    'trade_url'=>'https://trade.ziraatyatirim.com.tr/',
    'after_hours_limit_tl'=>1000,
    'order_debug'=>false,
];
