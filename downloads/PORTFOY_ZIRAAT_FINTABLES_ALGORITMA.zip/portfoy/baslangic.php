<?php
declare(strict_types=1);
date_default_timezone_set('Europe/Istanbul');
if (PHP_SAPI!=='cli') {
    $remote=$_SERVER['REMOTE_ADDR']??'';$host=strtolower($_SERVER['HTTP_HOST']??'');
    if (!in_array($remote,['127.0.0.1','::1','::ffff:127.0.0.1'],true) || !preg_match('/^(?:localhost|127\.0\.0\.1|\[::1\])(?::[0-9]{1,5})?$/D',$host)) {
        http_response_code(403);header('Content-Type: application/json; charset=utf-8');
        echo '{"ok":false,"error":"Bu kurulum yalnız localhost üzerinden kullanılabilir."}';exit;
    }
}
$storage=getenv('PORTFOY_LEGACY_DATA_DIR')?:sys_get_temp_dir().'/portfoy-orijinal-'.substr(hash('sha256',__DIR__),0,16);
if (!is_dir($storage) && !mkdir($storage,0700,true)) { http_response_code(500);exit('Yazılabilir kayıt dizini oluşturulamadı.'); }
$storage=realpath($storage);
$document=realpath($_SERVER['DOCUMENT_ROOT']??'');
if ($document!==false) {
    $a=str_replace('\\','/',$storage);$b=rtrim(str_replace('\\','/',$document),'/').'/';
    if (PHP_OS_FAMILY==='Windows') { $a=strtolower($a);$b=strtolower($b); }
    if ($a===rtrim($b,'/') || str_starts_with($a,$b)) { http_response_code(500);exit('Kayıt dizini htdocs dışında olmalı.'); }
}
define('PORTFOY_DATA_DIR',$storage);
if (!is_dir($storage.'/http_sessions')) mkdir($storage.'/http_sessions',0700,true);
session_save_path($storage.'/http_sessions');
session_name('portfoy_orijinal_'.substr(hash('sha256',__DIR__),0,12));
$base=rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME']??'/index.php')),'/');
session_set_cookie_params(['path'=>$base.'/','httponly'=>true,'samesite'=>'Strict','secure'=>isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off']);
session_start();
$_SESSION['csrf']??=bin2hex(random_bytes(32));
$portfoyCsrf=$_SESSION['csrf'];
$ftConfig=require __DIR__.'/config_fintables.php';
$portfoyFeedToken=(string)($_SESSION['fintables_token']??$ftConfig['token']??'');
if (($_SERVER['REQUEST_METHOD']??'GET')==='POST' && !hash_equals($portfoyCsrf,$_SERVER['HTTP_X_CSRF_TOKEN']??'')) {
    http_response_code(403);header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok'=>false,'error'=>'Sayfayı yenileyin: oturum doğrulaması gerekli.'],JSON_UNESCAPED_UNICODE);exit;
}
if ((int)($_SERVER['CONTENT_LENGTH']??0)>2097152) { http_response_code(413);exit('İstek çok büyük.'); }
if (($_GET['api']??'')==='fintables_token') {
    header('Content-Type: application/json; charset=utf-8');
    if (($_SERVER['REQUEST_METHOD']??'GET')!=='POST') { http_response_code(405);echo '{"ok":false,"error":"POST gerekli."}';exit; }
    $body=json_decode(file_get_contents('php://input'),true);
    $token=is_array($body)?trim((string)($body['token']??'')):'';
    $token=preg_replace('/^Bearer\s+/i','',$token);
    if (strlen($token)<16 || strlen($token)>8192 || preg_match('/[\x00-\x20]/',$token)) { http_response_code(422);echo '{"ok":false,"error":"Geçerli veri anahtarı gerekli."}';exit; }
    $_SESSION['fintables_token']=$token;
    echo '{"ok":true,"message":"Anahtar yerel oturumda saklandı; bağlantı doğrulanıyor."}';exit;
}
session_write_close();
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');
header('Referrer-Policy: no-referrer');
$portfoyAlgoConfig=json_decode(file_get_contents(__DIR__.'/algoritma_ayar.json'),true,512,JSON_THROW_ON_ERROR);
if (!is_file($storage.'/ayarlar.json')) {
    // Yeni paket kendi varsayilanini olusturur; mevcut kayitlarin ustune yazmaz.
    $seed=file_get_contents(is_file(__DIR__.'/ayarlar.json')?__DIR__.'/ayarlar.json':__DIR__.'/ayarlar.ornek.json');
    $migration=json_decode($seed,true,512,JSON_THROW_ON_ERROR);
    $migration['settings']['paperMode']=true;$migration['settings']['autoBuy']=false;$migration['settings']['autoSell']=false;
    $seed=json_encode($migration,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
    $handle=fopen($storage.'/ayarlar.json','x');
    if ($handle!==false) { fwrite($handle,$seed);fclose($handle);chmod($storage.'/ayarlar.json',0600); }
}
