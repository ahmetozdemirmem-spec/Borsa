'use strict';
let report;
const el=id=>document.getElementById(id),fmt=v=>Number.isFinite(v)?v.toFixed(2):'hesaplanamadı';
el('test').onclick=async()=>{
  el('test').disabled=true;el('result').textContent='Test çalışıyor…';
  try{
    const file=el('csv').files[0];if(!file)throw new Error('Önce CSV seçin.');if(file.size>8*1024*1024)throw new Error('CSV en fazla 8 MB olmalı.');
    const bars=Portfoy.parseCsv(await file.text());if(bars.length>10000)throw new Error('Tarayıcı testi en fazla 10000 mum.');
    const response=await fetch('algoritma_ayar.json',{cache:'no-store'});if(!response.ok)throw new Error('Algoritma ayarları okunamadı.');const c=await response.json();
    await new Promise(r=>setTimeout(r,20));
    report=PortfoyStratejiTest.compare(bars,c,{capital:Number(el('capital').value),buyAmount:Number(el('budget').value),rsiBuy:Number(el('threshold').value),commissionRate:Number(el('commission').value)/100,spreadPct:Number(el('spread').value)});
    const lines=[];for(const r of [report.original,report.newStrategy])lines.push(`${r.label}\n${r.tradeCount} işlem · Net ${fmt(r.netPnl)} TL (%${fmt(r.netPct)}) · Azami düşüş %${fmt(r.maxDrawdownPct)}\nKomisyon ${fmt(r.fees)} TL · Kazanma %${fmt(r.winRate)} · Kâr faktörü ${fmt(r.profitFactor)}\n${r.warnings.join('\n')}`);
    el('result').textContent=lines.join('\n\n');el('report').disabled=false;
  }catch(e){el('result').textContent='Test tamamlanamadı: '+e.message;}finally{el('test').disabled=false;}
};
el('report').onclick=()=>{const url=URL.createObjectURL(new Blob([JSON.stringify(report,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='portfoy-strateji-karsilastirma.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
