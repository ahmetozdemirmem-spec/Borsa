@echo off
setlocal
cd /d "%~dp0"

rem PHP_BIN can point to a custom php.exe. Otherwise use PATH or XAMPP.
set "PORTFOY_PHP="
if defined PHP_BIN set "PORTFOY_PHP=%PHP_BIN%"
if not defined PORTFOY_PHP for %%P in (php.exe) do set "PORTFOY_PHP=%%~$PATH:P"
if not defined PORTFOY_PHP for %%P in ("C:\xampp\php\php.exe" "D:\xampp\php\php.exe" "E:\xampp\php\php.exe" "C:\php\php.exe") do if exist "%%~P" set "PORTFOY_PHP=%%~P"
if not defined PORTFOY_PHP goto missing_php
if not exist "%PORTFOY_PHP%" goto missing_php

"%PORTFOY_PHP%" -r "exit(PHP_VERSION_ID >= 80200 ? 0 : 1);"
if errorlevel 1 goto missing_php
if not defined PORT set "PORT=8080"
"%PORTFOY_PHP%" -r "$p=getenv('PORT'); exit(preg_match('/^[0-9]{4,5}$/D', $p) && (int)$p >= 1024 && (int)$p <= 65535 ? 0 : 1);"
if errorlevel 1 (
  echo PORT 1024 ile 65535 arasinda bir sayi olmali.
  pause
  exit /b 1
)

echo.
echo PORTFOY - Yalniz paper / simulasyon
echo Tarayici adresi: http://localhost:%PORT%/
echo Bu pencere acik kalmali. Durdurmak icin Ctrl+C kullanin.
echo Apache, MySQL, Node.js veya npm baslatmaniz gerekmez.
echo.
rem Open the browser only after this app is listening. No external URLs.
if not defined PORTFOY_NO_BROWSER (
  where powershell.exe >nul 2>nul
  if not errorlevel 1 start "" /b powershell.exe -NoProfile -Command "$u='http://localhost:%PORT%/'; for($i=0;$i -lt 50;$i++){try{$r=Invoke-WebRequest -UseBasicParsing -Uri $u -TimeoutSec 1; if($r.StatusCode -eq 200 -and $r.Content.Contains('PORTFOY')){Start-Process $u; exit}}catch{}; Start-Sleep -Milliseconds 200}"
)
"%PORTFOY_PHP%" -S "127.0.0.1:%PORT%" -t "%~dp0public"
set "PORTFOY_EXIT=%ERRORLEVEL%"
if not "%PORTFOY_EXIT%"=="0" (
  echo.
  echo Sunucu baslatilamadi. Port doluysa ILK_ONCE_OKU.txt dosyasina bakin.
  pause
)
exit /b %PORTFOY_EXIT%

:missing_php
echo.
echo PHP 8.2 veya ustu bulunamadi ya da calistirilamadi.
echo Guncel XAMPP icindeki PHP'yi veya kendi PHP CLI kurulumunuzu kullanin.
echo Ornek ozel yol: set "PHP_BIN=C:\xampp\php\php.exe"
echo Ayrintilar icin ILK_ONCE_OKU.txt dosyasini acin.
echo.
pause
exit /b 1
