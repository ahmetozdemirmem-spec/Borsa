# PORTFOY · Risk Kontrollü Araştırma Botu

Yüklenen `PORTFOY_3COMMAS_RSI_TRAILING.zip` temel alınarak geliştirilen PHP/JavaScript uygulaması. BIST hisse takibi, RSI toparlanma stratejisi, sunucuda tutulan paper portföy, zorunlu risk kontrolleri ve maliyetli geçmiş veri testi içerir.

**Bu sürüm yalnız simülasyon içindir; gerçek emir gönderen bir kod yolu yoktur.** “En risksiz”, “en çok kazandıran” veya gelecekte kârlı olduğu kanıtlanmış bir strateji iddiası yoktur. Gerçek BIST fiyat geçmişiyle performans doğrulaması yapılmadı. Sentetik örnek sonuçları yatırım performansı değildir.

## Başlatma

**Localhost için:** ZIP'i tamamen çıkarın. Windows'ta PHP >=8.2 kuruluysa `BASLAT_WINDOWS.bat` dosyasına çift tıklayın; PATH veya yaygın XAMPP PHP yolları otomatik bulunur. Linux/macOS'ta `sh BASLAT.sh` çalıştırın. Tarayıcı adresi `http://localhost:8080/`. Adım adım açıklama: [ILK_ONCE_OKU.txt](ILK_ONCE_OKU.txt). Windows başlatıcısı bu Linux makinesinde çalıştırılmadı; Windows'a ait çalışma doğrulaması yapılmış sayılmaz.

Uygulamayı açmak için **yalnız PHP >=8.2 CLI** gerekir. Node.js >=20, Python >=3.10 ve Playwright geliştirme/test araçlarıdır; normal kullanımda kurulmaları gerekmez. Uygulamanın ek PHP uzantısı veya veritabanı bağımlılığı yoktur. ZIP PHP çalışma zamanını içermez. Çalışma dizini paketin köküdür; bulut ortamında `/workspace/Borsa`.

```sh
cd /workspace/Borsa
sh scripts/setup-php.sh
sh scripts/start.sh
```

`setup-php.sh` mevcut uygun PHP'yi kullanır; yoksa Debian 13 x86_64 üzerinde imzalı Debian paketlerini `.tools/` içine açar. Sistem dizinlerini değiştirmez, TLS/imza/hash doğrulamasını kapatmaz. Başka dağıtımlarda uygun PHP CLI sisteminizin paket yöneticisiyle kurulmalıdır. Yerel runtime varsa `sh scripts/php.sh -v` ile kontrol edilebilir.

Başlatıcı yalnız loopback arayüzünde 8080 portunu dinler. `PORT=8081 sh scripts/start.sh` ile port değiştirilebilir. Geliştirme sunucusunu internete açmayın; çok kullanıcılı kimlik doğrulama içermez. Web sunucusunun belge kökü **yalnız `public/`** olmalıdır. Depo kökünü yayınlamayın.

Her bulut görevi zaten yalıtılmıştır; mevcut checkout kullanılır, ek Git worktree gerekmez. Bağımlılık dosyaları ve ledger disk üzerinde kalır; çalışan sunucu/fiyat bağlantısı yeni görevde yeniden başlatılmalıdır. Bu geliştirme sırasında ortam yayımlanmadı ve yayımlanmış kurulum taslağı değiştirilmedi.

## İlk kullanım

1. Varsayılan **SENTETİK DEMO** kaynağında “Fiyat Akışını Başlat” seçin. Her saniye yapay bir mum ilerler; gerçek zamanlı BIST performansını temsil etmez. Hesap başlangıcı 100.000 TL'dir.
2. Manuel AL/SAT paper işlemleri teyit ister. Oto-AL her açılışta kapalıdır; kullanıcı açabilir. Manuel alımlar sinyal filtresini atlar, **sunucu risk limitlerini atlamaz**.
3. “Acil Durdur” yeni alımları engeller; veri akışı açıksa stop çıkışları ve manuel satış çalışır. “Alımları Sürdür” günlük kayıp/düşüş kilitlerini kaldırmaz. Akışı durdurmak koruyucu fiyat takibini de durdurur.
4. Ledger otomatik saklanır; sayfa yenilendiğinde portföy, komisyonlar, stop tepe değerleri ve risk kilitleri korunur. “İşlem Kaydı İndir” JSON çıktısı üretir. Eski zipteki kişisel işlem/oturum dosyaları yüklenmez.

**Tarayıcı kapalı, bağlantı kesik veya veri eskiyken stop çalışacağı varsayılamaz.** Bu, aracı kurumda duran bir stop emri değildir. Gerçek stop uygulaması, kesintisiz servis ve gerçekleşme mutabakatı olmadan canlı kullanılamaz.

### Piyasa verisiyle paper araştırma

- Fintables kaynağı için kendi kullanım yetkiniz olan WebSocket anahtarını arayüzde girin. Anahtar sadece sekmenin belleğinde kullanılır; kaynak koduna, sunucuya, ledger'a veya tarayıcı kalıcı depolarına yazılmaz. Yetki/lisans sınırlarına uyun.
- İlk işlem öncesinde kaynak modu değiştirilebilir. Demo ile piyasa geçmişi aynı hesapta karıştırılamaz. Ayrı hesap için `PORTFOY_STATE_DIR=/workspace/scratch/portfoy-market PORT=8081 sh scripts/start.sh` kullanın; mevcut ledger'ı silmeyin.
- Piyasa paper AL işlemleri için `config/risk.json` dosyasındaki `marketSessions` alanına borsadan doğrulanan günleri ekleyin: `"YYYY-MM-DD": {"open": "HH:MM", "close": "HH:MM"}`. Takvim yoksa alımlar kapalıdır. Tatil, yarım gün ve olağanüstü kapanışlar açıkça yönetilmelidir; haftanın günü tek başına yeterli değildir. Satış/stop değerlendirmesi takvim kontrolüyle engellenmez.
- Seans tanımı uygulamanın 10:05–17:50 İstanbul saatleri filtresiyle kesiştirilir. Bunlar temkinli örnek çalışma saatleridir, borsanın tüm emir fazlarının tanımı değildir.
- A/B fiyatları ayrı ayrı 15 saniyelik eskime kontrolüne tabidir. Bu süre **uygulamaya ulaşma zamanı** içindir; sağlayıcı mesajında güvenilir borsa zamanı doğrulanmadığı için upstream gecikmesini kanıtlamaz. Veri sağlayıcısı bağlantısı bu geliştirmede gerçek anahtarla test edilmedi.
- Lisanslı mum geçmişi yoksa gerçek akıştan eksiksiz 60 adet 15 dakikalık Ask mumu birikmelidir. İlk kısmi mum, intraday boşluklar ve uzun tick boşlukları gösterge ısınmasını yeniden başlatır. Sentetik ısınma piyasa moduna aktarılmaz.

## Strateji ve risk

Ask mumlarıyla RSI(14) varsayılan 30 eşiğini **yukarı keser**, kapanış yükselen EMA50'nin üstündedir, ATR yüzdesi uygun aralıktadır ve yükseliş mumu vardır. Hacim mevcutsa düşük hacim filtresi de uygulanır; A/B akışında olmayan hacim uydurulmaz. Bu hipotez optimize edilmiş veya kârlılığı kanıtlanmış değildir.

Risk ayarları `config/risk.json` içindedir. Oranlar kesir olarak yazılır: `0.02 = %2`.

| Denetim | Varsayılan |
| --- | --- |
| İşlem başına hedef azami planlı zarar | Özsermayenin %0,5'i, giriş/çıkış maliyeti dahil |
| Toplam açık stop riski | %2 |
| Tek hisse / toplam brüt pozisyon | %10 / %60 |
| Emir üst limiti / pozisyon sayısı | 9.000 TL / 6 |
| Nakit rezervi | En az %20 |
| Başlangıç stopu | En az %2 veya 2 × ATR; %4'ten genişse işlem yok |
| Trailing | +%2'de aktivasyon, tepeden %0,6; stop gevşetilmez |
| Günlük kayıp / azami özsermaye düşüşü | %2 / %6 sonrasında yeni AL kilidi |
| Ardışık kayıp / bekleme | 3 kayıpta 120 dakika |
| Aynı hisseye yeniden giriş | Satıştan sonra 60 dakika |
| Süre çıkışı | 48 saat sonra ilk geçerli Bid |
| Azami spread / fiyat yaşı | %0,3 / 15 saniye |
| Komisyon / kayma | Her yönde %0,15 / %0,05 |

Bu sınırlar garanti edilmiş azami kayıp değildir: fiyat boşluğu, taban fiyat, yetersiz likidite, veri kesintisi ve masraflar zararı artırabilir. Limit/düşüş kilitleri mevcut pozisyonları topluca tasfiye etmez; yeni risk alımını durdurur. Stoplar ve manuel çıkışlar devam eder. Max drawdown kilidi hesap ömrü boyunca kalır; günlük kilit İstanbul gün değişiminde yenilenir. Başlangıç sermayesi geçmişi olan ledger üzerinde değiştirilemez.

Paper işlemler Ask'tan kayma eklenerek alınır, Bid'den kayma çıkarılarak satılır. İki yön komisyon nakitten düşülür. Pozisyon büyüklüğü risk, toplam stop riski, brüt pozisyon, nakit rezervi ve emir limitinin en küçüğüyle belirlenir. Açık pozisyon değerlemesi tahmini satış maliyeti sonrasıdır.

## Geçmiş veri testi

Arayüzden 15 dakikalık Ask OHLC CSV yükleyin veya CLI kullanın:

```sh
node scripts/backtest.cjs veri.csv rapor.json
node scripts/backtest.cjs --demo sentetik-rapor.json
```

```csv
timestamp,open,high,low,close,volume
2026-10-27T07:00:00Z,100,101,99.5,100.8,120000
2026-10-27T07:15:00Z,100.8,101.5,100.2,101.2,135000
```

Bu iki satır yalnız format örneğidir; stratejiye yeterli değildir. `volume` isteğe bağlıdır. Zaman açık UTC/offset veya epoch milisaniye, ondalık ayırıcı nokta olmalıdır. Mum sırası ve OHLC tutarlılığı doğrulanır; eksik mum doldurulmaz. Bölünme, sermaye artırımı ve temettü düzeltmeleri veri kaynağında doğru yapılmalıdır.

Sinyal kapanmış mumdan gelir, giriş bir sonraki bitişik mumun açılışında yapılır. Sabit spread'den Bid tahmin edilir, iki yön komisyon ve kayma düşülür. Önce mevcut stop, sonra süre çıkışı, en son tepe güncellemesi işlenir. Mum içinde oluşan yeni trailing seviyesi sonraki mumda geçerlidir; OHLC gerçek tick sırasını vermez. Stop altında açılış daha kötü açılış fiyatından modellenir. Son açık pozisyon son mumda maliyetlerle kapatılır.

Net getiri, kâr faktörü, işlem sayısı, kazanma oranı, maliyetler, azami düşüş ve al-tut kıyaslaması raporlanır. Al-tut tam sermaye kullanırken bot tek hisseye en çok %10 ayırır; doğrudan aynı riskte karşılaştırma değildir. Üç dönemli walk-forward parametre aramaz; geçmiş mumlarla ısınıp ayrı test aralıklarını sabit parametreyle ve ayrı sermayeyle ölçer. Dönem getirileri tek portföy getirisi gibi toplanmaz. 30 işlem altı sonuçlarda yetersiz örneklem uyarısı gösterilir; 30 işlem de başarı garantisi değildir.

Tarayıcı sınırı 10.000 mum/8 MB; daha büyük veri CLI ile çalıştırılmalıdır. Testler tek hisselidir; sektör/korelasyon, gerçek emir defteri, kısmi gerçekleşme, fiyat adımı, taban/tavan ve portföy düzeyinde eşzamanlı sinyalleri modellemez. Model bunları doğrulamış gibi kullanılamaz.

## Testler

```sh
sh scripts/check.sh
npm ci --ignore-scripts
npm run test:browser
```

Tarayıcı testi için sistemde Chromium veya `npx playwright install chromium` gerekir; farklı bir yol `CHROMIUM_BIN` ile seçilebilir. Bulut sandbox'ında yerel soket açan HTTP/tarayıcı testleri izinli yürütme bağlamını gerektirir. Testler dış borsaya istek veya gerçek emir göndermez. Test hesapları geçici dizinlerde oluşturulup kaldırılır.

## Yapı ve veri güvenliği

- `app/PaperBroker.php`: kilitli, atomik JSON ledger; idempotent kabul edilmiş emirler; risk kontrolü ve paper gerçekleşme.
- `public/assets/strategy.js`: tarayıcı ve CLI'nin ortak gösterge/sinyal motoru.
- `public/assets/backtest.js`: geleceği görmeyen, maliyetli tek hisse testi ve dönem kontrolleri.
- `var/`: web kökü dışında, Git dışında, 0700 kayıt dizini; ledger 0600. Kayıt bozuksa hesap sessizce sıfırlanmaz, işlem durur.
- Fiyat akışında her tick sırası korunur; batch içindeki geçici stop ihlali son fiyatla gizlenmez. Fiyat yazımı, risk kontrolü ve işlem kaydı aynı dosya kilidi altındadır.
- Durum değiştiren API'lerde POST ve oturuma bağlı CSRF gerekir. Arayüz dış verileri `textContent` ile yazar; CSP uygulanır. Bu önlemler internete açık çok kullanıcılı kimlik doğrulamanın yerini tutmaz.
- Zipteki gömülü veri anahtarı, Ziraat şifre/token/oturum dosyaları ve kişisel işlem geçmişi projeye alınmadı. Paylaşılmış anahtar/oturumlar kaynak sağlayıcınızdan yenilenmelidir.
- Ziraat emir köprüsü bu sürüme taşınmadı. HTTP isteğinin başarıyla gönderilmesi, emrin kabulü ve gerçekleşmesi ayrı olaylardır. Resmî/kurumca desteklenen erişim, emir kimliği, kısmi gerçekleşme, iptal ve portföy mutabakatı doğrulanmadan canlı mod eklenmemelidir.
- Tarihli eski DNA dosyası yalnız `examples/` altında inceleme örneğidir; güncel eğitim modeli/verisi ve nedensel seçim testi bulunmadığından işlem evreni olarak kullanılmaz. Orijinal açıklama `docs/ORIGINAL_README.txt` tarihsel bağlamdır; güncel davranış bu dosyada açıklanır.

Araştırma kaynakları ve tasarım gerekçeleri: [docs/RESEARCH.md](docs/RESEARCH.md). Doğrulama kapsamı: [docs/VALIDATION.md](docs/VALIDATION.md).
