#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if ! sh scripts/php.sh -r 'exit(PHP_VERSION_ID >= 80200 ? 0 : 1);' >/dev/null 2>&1; then
  echo 'PHP >=8.2 CLI gerekli. Debian 13 bulut ortaminda: sh scripts/setup-php.sh' >&2
  echo 'Diger sistemlerde PHP CLI kurun; ayrintilar ILK_ONCE_OKU.txt dosyasinda.' >&2
  exit 1
fi
PORT="${PORT:-8080}"
case "$PORT" in ''|*[!0-9]*) echo 'PORT sayisal olmali.' >&2; exit 1;; esac
if ! [ "$PORT" -ge 1024 ] 2>/dev/null || ! [ "$PORT" -le 65535 ] 2>/dev/null; then
  echo 'PORT 1024..65535 araliginda olmali.' >&2
  exit 1
fi
export PORT
printf '\nPORTFOY - Paper / Simulasyon\nTarayici adresi: http://localhost:%s/\nDurdurmak icin Ctrl+C.\n\n' "$PORT"
exec sh scripts/start.sh
